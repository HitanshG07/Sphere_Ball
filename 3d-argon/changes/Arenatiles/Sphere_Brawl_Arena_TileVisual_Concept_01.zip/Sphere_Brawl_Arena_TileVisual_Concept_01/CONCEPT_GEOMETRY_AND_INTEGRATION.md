# CONCEPT GEOMETRY AND INTEGRATION SPECIFICATION — `SM_Arena_TileVisual_01`

| Property | Specification |
| :--- | :--- |
| **Canonical Asset ID** | `SM_Arena_TileVisual_01` |
| **Base Modular Component** | `COMP_Arena_TileBevelFrame_118` |
| **Scale Convention** | `1 Blender unit = 1.0 Roblox stud` |
| **Proposed Local Origin** | `(0.0000, 0.0000, 0.0000)` at the geometric center of the `11.8000 × 2.0000 × 11.8000` visual tile |
| **Local Bounding Box (`SM_Arena_TileVisual_01`)** | `Local X in [-5.9000, +5.9000]`, `Local Y in [-1.0000, +1.0000]`, `Local Z in [-5.9000, +5.9000]` |
| **Visual Mesh Size (`X × Y × Z`)** | `11.8000 × 2.0000 × 11.8000 studs` |
| **Collision Reference Size (`X × Y × Z`)** | `12.0000 × 2.0000 × 12.0000 studs` (`Local X, Z in [-6.0000, +6.0000]`, `Local Y in [-1.0000, +1.0000]`) |
| **Hazard Overlay Envelope (`X × Y × Z`)** | `11.4000 × 0.0500 × 11.4000 studs` (`Local X, Z in [-5.7000, +5.7000]`, `Local Y in [+1.0000, +1.0500]`, Center `Local Y = +1.0250`) |

## 1. Local Geometry Bounds, Origin & Vertical Alignment

For `SM_Arena_TileVisual_01`, the local coordinate system is centered on the geometric center of the visual tile (`(0.0000, 0.0000, 0.0000)`):

| Layer / Component | Local X Bounds (Studs) | Local Y Bounds (Studs) | Local Z Bounds (Studs) | Overall Dimensions (`X × Y × Z`) | World Y Span (When Tile Center is at `Y = 50.0`) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Authoritative `CollisionTile` (Reference Only)** | `[-6.0000, +6.0000]` | `[-1.0000, +1.0000]` | `[-6.0000, +6.0000]` | `12.0000 × 2.0000 × 12.0000` | `World Y in [49.0000, 51.0000]` (Top = `51.0000`) |
| **Base Visual Tile (`SM_Arena_TileVisual_01`)** | `[-5.9000, +5.9000]` | `[-1.0000, +1.0000]` | `[-5.9000, +5.9000]` | `11.8000 × 2.0000 × 11.8000` | `World Y in [49.0000, 51.0000]` (Top = `51.0000`) |
| **`COMP_Arena_TileBevelFrame_118` (Outer Chamfer)** | `[-5.9000, +5.9000]` | `[-1.0000, +1.0000]` | `[-5.9000, +5.9000]` | `11.8000 × 2.0000 × 11.8000` | Top 45° bevel: `World Y in [50.7500, 51.0000]` |
| **`GEO_Tile_CenterDeckPlate` (Inner Deck)** | `[-4.4200, +4.4200]` | `[+0.9850, +1.0000]` | `[-4.4200, +4.4200]` | `8.8400 × 0.0150 × 8.8400` | Flush top rolling surface at `World Y = 51.0000` |
| **`GEO_Tile_CyanCircuitInlay` (Recessed Conduit)** | `[-5.2500, +5.2500]` | `[+0.9850, +1.0000]` | `[-5.2500, +5.2500]` | `10.5000 × 0.0150 × 10.5000` | Trench at `World Y = 50.9850`; ticks flush at `51.0000` |
| **`GEO_Tile_CornerTrimLock_04` (Corner L-Trim)** | `[-5.1800, +5.1800]` | `[+1.0000, +1.0000]` | `[-5.1800, +5.1800]` | `10.3600 × 0.0000 × 10.3600` | Flush top perimeter detail at `World Y = 51.0000` |
| **`GEO_Tile_UndersideRibs` (Underside Ribs)** | `[-5.8200, +5.8200]` | `[-0.9500, -0.4500]` | `[-5.8200, +5.8200]` | `11.6400 × 0.5000 × 11.6400` | Recessed underside `World Y in [49.0500, 49.5500]` |
| **Modular `HazardOverlay` (`OVL_Arena_*`)** | `[-5.7000, +5.7000]` | `[+1.0000, +1.0500]` | `[-5.7000, +5.7000]` | `11.4000 × 0.0500 × 11.4000` | `World Y in [51.0000, 51.0500]` (Center = `51.0250`) |

### Why Origin `(0, 0, 0)` at the Geometric Center is Optimal
- Because both the `12.0 × 2.0 × 12.0` `CollisionTile` and the `11.8 × 2.0 × 11.8` `SM_Arena_TileVisual_01` have thickness `2.0000 studs` (`Local Y in [-1.0000, +1.0000]`) and geometric center `(0, 0, 0)`, **both parts share the exact same world `Position` and `CFrame`**.
- When placed at `World Y = 50.0000`, the tile's top face (`Local Y = +1.0000`) automatically aligns to **`World Y = 51.0000`** with zero vertical offset math required.

## 2. The 12.0-Stud Pitch and 0.20-Stud Groove Math

For any two horizontally adjacent grid cells $(x, z)$ and $(x+1, z)$:
1. **Center-to-Center Pitch:**
   $$\Delta X = 12.0000 \times (x + 1) - 12.0000 \times x = 12.0000\text{ studs}$$
2. **Authoritative `CollisionTile` Contact (`12.0000 studs` wide, half-width `6.0000 studs`):**
   - Cell $(x, z)$ eastern collision face: $12x + 6.0000$
   - Cell $(x+1, z)$ western collision face: $12(x+1) - 6.0000 = 12x + 6.0000$
   - **Result:** $0.0000\text{-stud}$ physical gap (100% seamless edge-to-edge collision surface across all 81 cells).
3. **Visual Tile Groove (`11.8000 studs` wide, half-width `5.9000 studs`):**
   - Cell $(x, z)$ eastern outer visual edge: $12x + 5.9000$ (inset $0.1000\text{ studs}$ from collision boundary)
   - Cell $(x+1, z)$ western outer visual edge: $12(x+1) - 5.9000 = 12x + 6.1000$ (inset $0.1000\text{ studs}$ from collision boundary)
   - **Result:**
     $$\text{Inter-Tile Visual Groove} = (12x + 6.1000) - (12x + 5.9000) = 0.2000\text{ studs}$$
4. **Top Chamfer Margin (`0.2500 studs` at $45^\circ$):**
   - Each tile's $45^\circ$ top bevel rises from `Local Y = +0.7500` at `±5.9000` to `Local Y = +1.0000` at `±5.6500`.
   - Across a seam, the flat top rims (`±5.6500`) are separated by $0.2000 + 2 \times 0.2500 = 0.7000\text{ studs}$ visually, while the underlying `CollisionTile` remains flat and continuous at `World Y = 51.0000`.

## 3. World Transform & Checkerboard Parity Selection (Luau Reference)

Per `MASTER_IMPLEMENTATION_PLAN.md` Section 6, the grid center is `ArenaCFrame = CFrame.new(0, 50, 0)`. Each cell $(x, z)$ for integer $x, z \in [-4, +4]$ obtains its world center via a single transform application (never adding the center offset twice):

```luau
--!strict
-- Reference Coordinate & Visual Placement Contract (Documentation Only — Not Production Service Code)
local ARENA_CFRAME = CFrame.new(0, 50, 0)
local TILE_PITCH = 12.0
local OVERLAY_LOCAL_OFFSET = CFrame.new(0, 1.025, 0) -- Places 0.05-thick overlay center at World Y = 51.025

local function getCellWorldCFrame(gridX: number, gridZ: number): CFrame
    -- Use ArenaCFrame once; do not add (0, 50, 0) a second time
    return ARENA_CFRAME * CFrame.new(TILE_PITCH * gridX, 0, TILE_PITCH * gridZ)
end

local function isEvenCheckerParity(gridX: number, gridZ: number): boolean
    -- Determines whether cell uses Variant A (MAT_DarkNeutral frame) or Variant B (MAT_AltNeutral frame)
    return ((gridX + gridZ) % 2) == 0
end

local function getOverlayWorldCFrame(gridX: number, gridZ: number, yawDegrees: number): CFrame
    local cellCF = getCellWorldCFrame(gridX, gridZ)
    return cellCF * OVERLAY_LOCAL_OFFSET * CFrame.Angles(0, math.rad(yawDegrees), 0)
end
```

## 4. Hazard Overlay Positioning & Orientation Contract

Every hazard overlay (`OVL_Arena_*`) adheres to the exact `HazardOverlay` specification in `MASTER_IMPLEMENTATION_PLAN.md` Section 6 and the Master 3D Art Bible:
- **Overlay Envelope Dimensions:** `11.4000 × 0.0500 × 11.4000 studs` (`0.2000-stud` inset inside the `11.8000` visual tile outer bounds, leaving the `0.2500-stud` $45^\circ$ outer perimeter bevel of the base tile visible around the overlay).
- **Local Vertical Offset:** When modeled in tile-local coordinates, the overlay spans `Local Y in [+1.0000, +1.0500]` with geometric center at `Local Y = +1.0250`. When placed in world space above a tile at `World Y = 50.0000`, the overlay's bottom face rests flush on `World Y = 51.0000`, its geometric center is at **`World Y = 51.0250`**, and its top graphic face is at **`World Y = 51.0500`**.
- **Directional Rotation (`yawDegrees` around Local `+Y`):**
  - **Ice Corridor (`OVL_Arena_Warn_Ice`, `OVL_Arena_Active_Ice`):** Rotated via `CFrame.Angles(0, math.rad(yaw), 0)` to match the corridor angle (`0°`, `45°`, `90°`, or `135°`). Even at `45°` / `135°`, only the internal snowflake/chevron motif or UV/decal orientation needs to rotate if desired, or the square carrier remains axis-aligned while the inner motif group rotates inside the `r <= 4.55` inscribed circle so the `11.4 × 11.4` border stays parallel to the tile edges.
  - **Magnetic Storm (`OVL_Arena_Warn_Magnetic`, `OVL_Arena_Active_Magnetic`, `OVL_Arena_Active_MagneticField`):** Anchor tile (`_Active_Magnetic`) is radially symmetric (`0°`). Surrounding affected field tiles (`_Active_MagneticField`) orient their inward pull chevron toward the anchor tile.
  - **Boost Runway (`OVL_Arena_Warn_Boost`, `OVL_Arena_Active_Boost`):** Every tile in a runway uses the **same** cardinal yaw (`0°`, `90°`, `180°`, or `270°`) matching the runway's one-way impulse vector.
  - **Ring Collapse (`OVL_Arena_Collapse_Warn`, `OVL_Arena_Collapse_Sink`):** Axis-aligned (`0°`) across all `D=4` (`32` cells) and `D=3` (`24` cells) perimeter ring tiles.

## 5. Supporting 81 Reusable Cells & Visual/Collision Separation Contract

1. **Instancing Across 81 Cells:**
   - The `9 × 9` arena uses **one** shared static mesh asset (`SM_Arena_TileVisual_01`) instanced `81` times (`41` cells with `Variant A` material assignment where `(x + z) % 2 == 0`, and `40` cells with `Variant B` material assignment where `(x + z) % 2 != 0`).
   - Non-colliding hazard overlays (`OVL_Arena_*`) are pooled or toggled from a central visualizer driven by `PulseService` and `GridService` (with a hard maximum of `floor(liveCellCount × 0.35)` active hazard tiles at any time, i.e., `<= 28` overlays on an 81-cell board, `<= 17` on a 49-cell board, and `<= 8` on a 25-cell board).
   - **Zero per-tile scripts or per-tile `Heartbeat` connections** are permitted (`AI_AGENT_GLOBAL_SYSTEM_PROMPT.md` Rule 4).
2. **Mandatory Physics & Collision Properties:**

| Instance | `Anchored` | `CanCollide` | `CanTouch` | `CanQuery` | `Massless` | `Transparency` |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`CollisionTile` (`12 × 2 × 12` Server Part)** | `true` | **`true`** | `true` | `true` | `false` | **`1.0` (Invisible)** |
| **`SM_Arena_TileVisual_01` (`11.8 × 2 × 11.8` Mesh)** | `true` | **`false`** | **`false`** | `false` | `true` | `0.0` (Visible) |
| **`OVL_Arena_*` (`11.4 × 0.05 × 11.4` Overlay)** | `true` | **`false`** | **`false`** | `false` | `true` | `0.0` (Visible when active) |

## 6. Design Decisions Confirmed vs. Items for Owner Confirmation Before Phase 2

All core dimensions (`12.0` pitch, `11.8 × 2.0 × 11.8` visual tile, `0.20` groove, `0.25` 45° bevel, `11.4 × 0.05 × 11.4` overlay at `World Y = 51.025`, and `< 250` triangles) are locked in `MASTER_IMPLEMENTATION_PLAN.md` and the Art Bible. Before generating final Phase 2 production exports, please confirm:
1. **Base Tile Topology (`196 triangles`):** Confirm whether the `196-triangle` octagonal-chamfered blockout (`COMP_Arena_TileBevelFrame_118` + flush `GEO_Tile_CenterDeckPlate` + recessed `GEO_Tile_CyanCircuitInlay` + 4 `MAT_LightTrim` corner brackets + 4 underside ribs) is approved as the exact Phase 2 production topology.
2. **Overlay Delivery Format in Phase 2:** Confirm whether Phase 2 should export the hazard overlays as separate modular low-poly `.obj`/`.glb` overlay meshes (`32–72 triangles` each, resting at `Local Y in [+1.0000, +1.0500]`) so they work out-of-the-box with flat palette colors and zero texture memory, or also include optional `1024 × 1024` PNG decal/texture sheets for `SurfaceGui`/`Decal` fallback.
