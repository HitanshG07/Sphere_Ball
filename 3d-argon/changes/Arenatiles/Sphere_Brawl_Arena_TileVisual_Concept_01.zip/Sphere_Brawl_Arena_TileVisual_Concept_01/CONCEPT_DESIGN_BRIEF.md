# CONCEPT DESIGN BRIEF — `SM_Arena_TileVisual_01` (Modular Arena Tile & Hazard Visual System)

| Document Metadata | Details |
| :--- | :--- |
| **Asset ID** | `SM_Arena_TileVisual_01` (Base Visual Tile) + `OVL_Arena_*` (Modular Non-Colliding Hazard Overlays) |
| **Project & Branch** | *Sphere Brawl: Rolling Rampage* (`HitanshG07/Sphere_Ball`, branch `3d_mesh`) |
| **Phase** | **Phase 1 — Concept & Technical Design Only** |
| **Authoritative Sources** | `MASTER_IMPLEMENTATION_PLAN.md` (§0, §2, §6, §7, §8, §11, §12–16), `TASK-09-ASSETS-VFX-ANIMATION-AUDIO.md`, `specs/DESIGN_CONSTANTS.md`, `DECISION_LOG.md`, `AI_AGENT_GLOBAL_SYSTEM_PROMPT.md`, `3d-argon/sphere_brawl_master_3d_art_bible_and_technical_handoff.md` |

## 1. Visual Design Direction & Kinetic Grid World Cohesion

The floating `9 × 9` battle arena (`108.0 × 108.0 studs` suspended at `World Y = 50.0` above the blue reactor void) is the primary gameplay stage of *Sphere Brawl: Rolling Rampage*. Every visual decision in `SM_Arena_TileVisual_01` balances two requirements from `MASTER_IMPLEMENTATION_PLAN.md` Sections 2, 6, and 7:

1. **Architectural Cohesion with the Kinetic Grid World:** The tile uses heavy dark-alloy armor framing (`MAT_DarkNeutral` `#202636` and `MAT_AltNeutral` `#2A3246`), crisp 45-degree structural chamfers (`COMP_Arena_TileBevelFrame_118`), restrained metallic corner tie-lugs (`MAT_LightTrim` `#AABED7`), and a thin recessed `EMI_Cyan` (`#00C3FF`) energy circuit channel so the `81`-cell board reads as a unified, engineered high-tech combat deck matching the Hub stations.
2. **Instant Gameplay Readability at High Rolling Speeds (42–55 studs/s):** When six `6.0-stud` diameter spheres collide at high speed, players must immediately distinguish **Safe tiles**, **Pre-Hazard Warning telegraphs**, **Active Ice Corridors**, **Active Magnetic Storms**, **Active Boost Runways**, and **Ring-Collapse Warnings** by both **color** and **geometric icon/silhouette**, without visual clutter, surface protrusions, or bloom washing out tile boundaries.

## 2. Base Visual Tile Construction (`SM_Arena_TileVisual_01`)

The base visual tile is a repeatable `11.8000 × 2.0000 × 11.8000 stud` armored deck module (`196 measured triangles` in the Phase 1 blockout, strictly below the `< 250` triangle maximum and `~220` Art Bible target) composed of five clean sub-components:

1. **`COMP_Arena_TileBevelFrame_118` (`86 triangles`):**
   - Forms the outer `11.80 × 2.00 × 11.80` structural armor body spanning `Local X, Z in [-5.9000, +5.9000]` and `Local Y in [-1.0000, +1.0000]`.
   - Implements the Art Bible's standardized **`0.2500-stud` chamfer at 45°** along the top perimeter (`Local Y` from `+0.7500` to `+1.0000`, stepping inward from `±5.9000` to `±5.6500`) and a matching `0.2500-stud` underside chamfer (`Local Y` from `-0.7500` to `-1.0000`), with `0.4500-stud` corner miters that eliminate razor-sharp aliasing on mobile screens.
   - Provides a `1.0000-stud` wide flat top perimeter rim at `Local Y = +1.0000` (`±5.6500` to `±4.6500`) before stepping down `0.0150 studs` (`Local Y = +0.9850`) into the recessed cyan circuit channel.
2. **`GEO_Tile_CenterDeckPlate` (`22 triangles`):**
   - A broad octagonal center rolling plate (`8.7600 × 8.7600 studs`, `Local X, Z in [-4.3800, +4.3800]`) whose top face sits completely flush at `Local Y = +1.0000` (`World Y = 51.0000`).
   - Uses the opposite neutral material from the outer bevel frame to reinforce checkerboard readability while keeping 100% of the top rolling surface flat and protrusion-free.
3. **`GEO_Tile_CyanCircuitInlay` (`24 triangles`):**
   - An octagonal `0.1800-stud` wide recessed `EMI_Cyan` (`#00C3FF`) energy conduit at `Local Y = +0.9850` separating the outer armor rim from the inner deck plate, accented by four cardinal bus ticks flush at `Local Y = +1.0000`.
   - Occupies only **`1.85%`** of total tile surface area, ensuring the safe board remains dark/slate dominant rather than neon-saturated.
4. **`GEO_Tile_CornerTrimLock_04` (`24 triangles`):**
   - Four restrained L-shaped `MAT_LightTrim` (`#AABED7`) corner mounting brackets and inner tie-lugs flush at `Local Y = +1.0000` (`1.35%` of surface area). Every feature width (`>= 0.30 studs`) is sized above the mobile pixel-shimmer threshold at default camera distance.
5. **`GEO_Tile_UndersideRibs` (`40 triangles`):**
   - Four structural cross-ribs recessed into the underside (`Local Y in [-0.9500, -0.4500]`) that give the `2.0-stud`-thick slab authentic industrial mass when viewed at the arena perimeter or when tilting/sinking during ring collapse.

## 3. Checkerboard Surface Treatment (Variant A & Variant B)

To support the `9 × 9` checkerboard pattern without baking world coordinates into the mesh or duplicating geometry:
- **Single Shared Geometry:** `Variant A` and `Variant B` share the exact same vertex coordinates, origin `(0, 0, 0)`, bounding box (`11.80 × 2.00 × 11.80`), and `196-triangle` topology.
- **Parity Material Swap:**
  - **Variant A (Even Grid Parity, `(x + z) % 2 == 0`):** Uses `MAT_DarkNeutral` (`#202636`, `61.65%` area) on `COMP_Arena_TileBevelFrame_118` and `MAT_AltNeutral` (`#2A3246`, `35.15%` area) on `GEO_Tile_CenterDeckPlate` and `GEO_Tile_UndersideRibs`.
  - **Variant B (Odd Grid Parity, `(x + z) % 2 != 0`):** Uses `MAT_AltNeutral` (`#2A3246`, `61.65%` area) on `COMP_Arena_TileBevelFrame_118` and `MAT_DarkNeutral` (`#202636`, `35.15%` area) on `GEO_Tile_CenterDeckPlate` and `GEO_Tile_UndersideRibs`.
- When tiled on the locked `12.0000-stud` pitch, neighboring `11.8000-stud` tiles leave a crisp, uniform **`0.2000-stud` visible inter-tile groove** (`0.1000 stud` per tile edge) flanked by matching `0.2500-stud` 45° chamfers (`Preview 02`).

## 4. Locked Material Palette & Surface Distribution

All materials strictly follow `MASTER_IMPLEMENTATION_PLAN.md` Section 2 and the Master 3D Art Bible:

| Material ID | RGB | Hex | Role in `SM_Arena_TileVisual_01` & Overlays | Base Tile Area % |
| :--- | :--- | :--- | :--- | :--- |
| `MAT_DarkNeutral` | `(32, 38, 54)` | `#202636` | Primary dark armor frame (Variant A), center deck (Variant B), and overlay carrier plate | `61.65%` (Var A) / `35.15%` (Var B) |
| `MAT_AltNeutral` | `(42, 50, 70)` | `#2A3246` | Alternate slate armor frame (Variant B), center deck (Variant A), and Ice overlay carrier | `35.15%` (Var A) / `61.65%` (Var B) |
| `MAT_LightTrim` | `(170, 190, 215)` | `#AABED7` | Restrained corner mounting L-brackets and structural tie-lugs | `1.35%` |
| `EMI_Cyan` | `(0, 195, 255)` | `#00C3FF` | Safe-state recessed technological circuit trench and cardinal bus ticks | `1.85%` |
| `MAT_PrimaryText` | `(245, 248, 255)` | `#F5F8FF` | High-contrast active hazard motifs (pale ice chevrons, snowflake core, magnetic pull arrows, boost intake bar) | Overlay only (`0.85%–3.88%`) |
| `EMI_Amber` | `(255, 170, 0)` | `#FFAA00` | Pre-hazard warning perimeter border, corner alert brackets, and secondary boost chevrons | Overlay only (`6.49%–14.90%`) |
| `EMI_Ice` | `(0, 235, 255)` | `#00EBFF` | Ice Corridor frost perimeter frame, 6-bar snowflake icon, and warning preview motif | Overlay only (`5.95%–14.98%`) |
| `EMI_Magnetic` | `(165, 55, 255)` | `#A537FF` | Magnetic Storm anchor core, concentric 2D pull rings, and field pull vectors | Overlay only (`7.83%–23.22%`) |
| `EMI_Kinetic` | `(255, 125, 0)` | `#FF7D00` | Boost Runway lateral guide rails, one-way propulsion chevrons, and turbine bars | Overlay only (`7.16%–14.61%`) |
| `EMI_DangerRed` | `(255, 40, 40)` | `#FF2828` | Ring-collapse 3.0s warning perimeter flash and asymmetric fracture crack lines | Overlay only (`21.90%–22.74%`) |

## 5. Six Visual States — Modular Hazard & Collapse Identity

### 5.1 State 1 — Safe / Neutral Tile (`Preview 01`, `Preview 02`)
- **Appearance:** Calm dark/slate checkerboard armor panel with a thin recessed `EMI_Cyan` octagonal circuit line and four `MAT_LightTrim` corner brackets.
- **Readability:** Zero central icons, zero directional arrows, and zero outer warning borders. Immediately reads as stable ground.

### 5.2 State 2 — Pre-Hazard Warning Telegraph (`Preview 04`, `Preview 05A`, `Preview 06A`, `Preview 07A`)
- **Timing Context:** Displayed during the locked Board Pulse Warning phase (`3.5s` Opening / `2.5s` MidGame / `2.0s` SuddenDeath) before any physical force or steering modifier activates.
- **Shared Warning Language:** Every pre-hazard warning tile displays a high-visibility **`EMI_Amber` (`#FFAA00`) outer perimeter border** (`0.48 studs` wide) with **four corner triangle alert brackets**, keeping the `11.8 × 11.8` base tile bevels and `0.20-stud` inter-tile grooves completely unobstructed.
- **Hazard-Specific Preview Motifs (Never Generic):**
  - **`OVL_Arena_Warn_Ice` (`38 tris`):** Combines the `EMI_Amber` warning border with a central `EMI_Ice` 6-bar snowflake preview and twin corridor chevrons so players know an **Ice Corridor** is forming and which axis (`0°`, `45°`, `90°`, `135°`) it follows.
  - **`OVL_Arena_Warn_Magnetic` (`56 tris`):** Combines the `EMI_Amber` warning border and center diamond with two concentric `EMI_Magnetic` (`#A537FF`) octagonal preview rings so players can move away from the incoming **Magnetic Anchor** before radial pull begins.
  - **`OVL_Arena_Warn_Boost` (`34 tris`):** Combines the `EMI_Amber` warning border with two large one-way `EMI_Kinetic` / `EMI_Amber` directional preview chevrons and rear turbine bars so players see the exact cardinal travel vector (`0°`, `90°`, `180°`, `270°`) ahead of activation.

### 5.3 State 3 — Ice Corridor Active (`OVL_Arena_Active_Ice`, `38 tris`, `Preview 05`)
- **Visual Identity:** Transitions the carrier plate to cool slate (`MAT_AltNeutral`) framed by a crisp `EMI_Ice` (`#00EBFF`) frost border and `EMI_Cyan` lateral glide rails, centered on a bold **6-bar crystalline snowflake icon** (`EMI_Ice` + `MAT_PrimaryText` diamond hub) flanked by **two wide pale chevrons (`MAT_PrimaryText` `#F5F8FF`)** aligned along the corridor axis.
- **Gameplay Fidelity:** Communicates low friction / reduced steering (`0.45×` steering multiplier and `25%` lateral damping = `1.625`) and momentum persistence. Contains **zero raised ice spikes, zero physical slopes, and zero damage/hazard skull decals** (since Ice Corridor does not deal damage or launch spheres).

### 5.4 State 4 — Magnetic Storm Active (`OVL_Arena_Active_Magnetic`, `72 tris` & `OVL_Arena_Active_MagneticField`, `42 tris`, `Preview 06`)
- **Visual Identity:**
  - **Designated Anchor Tile (`OVL_Arena_Active_Magnetic`):** Features a purple `EMI_Magnetic` (`#A537FF`) containment border, **two flat 2D concentric octagonal pull rings** (`r = 4.55` and `r = 2.85 studs`), a glowing central purple/white anchor core (`r = 1.25 studs`), and **four high-contrast inward-pointing `MAT_PrimaryText` radial pull triangles** pointing directly at the center anchor.
  - **Surrounding Affected Radius Tiles (`OVL_Arena_Active_MagneticField`):** Uses a lighter-weight variant (`42 tris`) with an outer purple ring and inward-pointing directional chevrons oriented toward the anchor cell (`Preview 06C`).
- **Performance & Clarity:** Communicates the radial pull toward the anchor (`up to 22 studs/s²`, capped at `12 studs/s` inward velocity across `2.8` / `2.0` / `1.0` tile radii) using clean 2D surface geometry rather than dense 3D beam meshes or per-player tether geometry.

### 5.5 State 5 — Boost Runway Active (`OVL_Arena_Active_Boost`, `36 tris`, `Preview 07`)
- **Visual Identity:** Features bright `EMI_Kinetic` (`#FF7D00`) and `EMI_Amber` (`#FFAA00`) dual runway guide rails, **three wide sequential one-way directional chevrons** spanning the tile face, and a 3-bar **ascending turbine/propulsion intake grille** (`MAT_PrimaryText` / `EMI_Kinetic` / `EMI_Amber`) at the runway entry edge.
- **No Physical Ramp Contract (`Preview 07D`):** Although the graphic motif evokes a high-speed propulsion runway, the overlay is a **strictly flat `0.0500-stud` non-colliding sheet** (`Local Y in [+1.0000, +1.0500]`). Every tile in a runway is rotated to the **exact same configured cardinal direction** (`0°`, `90°`, `180°`, or `270°`) to visually telegraph the game system's one-time `+18 studs/s` horizontal velocity impulse (clamped at `55 studs/s`).

### 5.6 State 6 — Ring-Collapse Warning & Sinking Presentation (`OVL_Arena_Collapse_Warn` / `_Sink`, `32 tris`, `Preview 08`)
- **3.0s Warning Phase (`T = -3.0s .. 0.0s`):** Displays a thick `0.58-stud` **`EMI_DangerRed` (`#FF2828`) perimeter flash border** and an **asymmetric X-fracture crack pattern** across the tile surface (`OVL_Collapse_CrackDecals`) with a bright white/red center alert diamond. During this 3-second warning, the authoritative `12 × 2 × 12` `CollisionTile` at `World Y = 51.0` remains **physically active and solid**.
- **Collapse Timestamp & Sinking Phase (`T = 0.0s .. +0.8s`):** At the authoritative collapse timestamp (`T = 56.0s` for outer ring `D=4` removing 32 cells to leave 49; `T = 98.0s` for ring `D=3` removing 24 cells to leave 25), `GridService` removes the cell's authoritative collider and the visual tile (`SM_Arena_TileVisual_01` + `OVL_Arena_Collapse_Sink`) sinks and tilts downward over `~0.5–0.8 seconds` into the void (`Preview 08A–E`).
- **Clean Boundaries:** Uses zero large debris clouds or full-screen effects that would obscure neighboring live tile edges (`D=3` or `D=2` perimeter boundaries).

## 6. How the Design Preserves Mobile Performance & Differs from a Collision Part

1. **Strict Separation from `CollisionTile`:**
   - The authoritative `CollisionTile` is an invisible Roblox `Part` (`Size = Vector3.new(12, 2, 12)`, `CanCollide = true`, `Transparency = 1`, zero elasticity) managed by `GridService`.
   - `SM_Arena_TileVisual_01` (`Size = Vector3.new(11.8, 2, 11.8)`) and all `OVL_Arena_*` overlays (`Size = Vector3.new(11.4, 0.05, 11.4)`) are strictly visual (`CanCollide = false`, `CanTouch = false`, `CastShadow = false` on overlays). They never alter tile friction, walk height (`World Y = 51.0000`), sphere mass, or collision seams.
2. **Mobile Readability & Economical Triangle Budget:**
   - Each base tile measures **`196 triangles`** (`54 triangles` below the `< 250` hard ceiling). Across all `81` cells, the base arena totals **`15,876 triangles`**.
   - Even during a maximum-density hazard pulse (`floor(81 × 0.35) = 28` active hazard overlays simultaneously), the entire 81-cell arena plus 28 active overlays totals **`16,828 to 17,892 triangles`** — well below the `20,169` / `20,250` triangle budget for the base tiles alone.
   - Uses flat palette materials (zero textures required, or an optional compact `<= 256 × 256` palette swatch well under the `1024 × 1024` ceiling) and zero dynamic point/surface lights.

## 7. What Remains for Phase 2 (After Owner Approval)

Once the owner approves this Phase 1 concept package, Phase 2 will build and validate:
1. Final production mesh files (`SM_Arena_TileVisual_01.obj`, `SM_Arena_TileVisual_01.mtl`, `SM_Arena_TileVisual_01.glb`) and modular non-colliding overlay meshes (`OVL_Arena_*.obj/.glb`).
2. Deterministic Python/Blender generator script (`generate_arena_tile_visual.py`) and automated geometry/bounds/triangle validation script.
3. Exact Roblox Studio material/Color3 mapping table, `asset-manifest.json` entry, and step-by-step `GridService` / `PulseService` visual attachment handoff guide.
