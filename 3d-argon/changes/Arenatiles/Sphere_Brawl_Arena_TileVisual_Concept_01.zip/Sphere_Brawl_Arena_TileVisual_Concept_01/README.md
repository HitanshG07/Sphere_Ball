# SM_Arena_TileVisual_01 — Phase 1 Concept & Technical Design Package

| Property | Value |
| :--- | :--- |
| **Project** | *Sphere Brawl: Rolling Rampage* |
| **Repository & Branch** | `HitanshG07/Sphere_Ball` (`3d_mesh`) |
| **Canonical Asset ID** | `SM_Arena_TileVisual_01` |
| **Asset Type** | Reusable arena visual floor tile mesh with modular non-colliding hazard-overlay variants |
| **Current Phase** | **Phase 1 — Concept and Technical Design Only (Awaiting Owner Approval)** |
| **Later Phase** | Phase 2 — Final production geometry (`.obj`, `.mtl`, `.glb`), generator script, validation & Studio integration package after explicit owner approval |
| **Target Engine & Code** | Roblox Studio / Luau (`--!strict`) |
| **Scale Convention** | `1 Blender unit = 1.0 Roblox stud` |
| **Locked Grid Dimensions** | `9 × 9 cells` (`81` initial cells), integer coordinates `X, Z in [-4, +4]` |
| **Locked Tile Pitch & Centre** | `12.0000 studs` center-to-center pitch; Grid centre `(0.0000, 50.0000, 0.0000)`; Top surface `World Y = 51.0000` |
| **Authoritative Collision Tile** | `12.0000 × 2.0000 × 12.0000 studs` (`Anchored = true`, `CanCollide = true`, `Transparency = 1`, seamless edge-to-edge; **NOT** part of this visual mesh) |
| **Locked Visual Tile Size** | `11.8000 × 2.0000 × 11.8000 studs` (`Anchored = true`, `CanCollide = false`, `CanTouch = false`, producing a `0.2000-stud` visible inter-tile groove) |
| **Proposed Local Origin** | `(0.0000, 0.0000, 0.0000)` at the geometric center of the `11.8 × 2.0 × 11.8` visual mesh (`Local X in [-5.90, +5.90]`, `Local Y in [-1.00, +1.00]`, `Local Z in [-5.90, +5.90]`) |
| **Locked Hazard Overlay Envelope** | `11.4000 × 0.0500 × 11.4000 studs` (`CanCollide = false`, `CanTouch = false`, centered at `Local Y = +1.0250` / `World Y = 51.0250`, spanning `Local Y in [+1.0000, +1.0500]`) |
| **Visual-Tile Triangle Budget** | Strictly `< 250 triangles` per visual tile (`~220` Art Bible target); **Measured Phase 1 Concept Blockout = `196 triangles` (`588 vertices`) per base tile** |
| **Full 81-Cell Board Triangles** | **`15,876 triangles`** for all 81 base visual tiles (`4,293 triangles` below the `20,169`-triangle ceiling at 249 tris/tile and `4,374` below the `20,250` Art Bible ceiling) |

## 1. Purpose and Scope

`SM_Arena_TileVisual_01` is the reusable modular visual floor tile and non-colliding hazard-overlay family for *Sphere Brawl: Rolling Rampage*'s floating `9 × 9` Kinetic Grid battle arena (`81` initial cells spanning `108.0 × 108.0 studs` around world center `(0, 50, 0)`).

This package fulfills **Phase 1 (Concept and Technical Design Only)**:
- Establishes a single shared, low-poly base visual tile geometry (`11.8000 × 2.0000 × 11.8000 studs`, `196 measured triangles`) with two checkerboard parity material variants (`Variant A: MAT_DarkNeutral dominant` and `Variant B: MAT_AltNeutral dominant`).
- Preserves the **strict visual/collision separation contract** from `MASTER_IMPLEMENTATION_PLAN.md` Section 6: each cell's physical floor is an invisible, seamless `12.0 × 2.0 × 12.0` `CollisionTile` (`CanCollide = true`), while `SM_Arena_TileVisual_01` (`11.8 × 2.0 × 11.8`, `CanCollide = false`, `CanTouch = false`) provides the visible `0.2000-stud` inter-tile grooves and `0.2500-stud` 45-degree perimeter bevels (`COMP_Arena_TileBevelFrame_118`) without introducing physical seams that could snag a rolling `6.0-stud` diameter player sphere.
- Defines the **six required visual state categories** using flat, non-colliding `11.4000 × 0.0500 × 11.4000` modular overlays (`CanCollide = false`, `CanTouch = false`, resting at `Local Y in [+1.0000, +1.0500]` / `World Y = 51.0250` center) so that **Ice Corridor**, **Magnetic Storm**, **Boost Runway**, **Pre-Hazard Warning**, and **Ring-Collapse Warning / Sinking** states are 100% distinct by both silhouette/iconography and emissive color from the high-altitude arena camera and on mobile screens.

## 2. Concept-Only Disclosure

> **CONCEPT-ONLY DISCLOSURE (PHASE 1):**
> - All nine PNG preview sheets in `previews/` are deterministic software-rendered 3D blockout/concept previews generated to verify proportions, bevels, groove math, checkerboard parity, and six-state hazard readability. They are **not** Roblox Studio screenshots.
> - Where the `12.0 × 2.0 × 12.0` authoritative `CollisionTile` is shown in technical diagrams (`Preview 03`, `Preview 07`, `Preview 08`), it is rendered strictly as a translucent wireframe technical reference and is **never** part of the production visual mesh.
> - The sample `9 × 9` multi-hazard arena layout in `Preview 09` is **illustrative only** to prove visual readability and instanced repeatability across 81 cells; runtime hazard selection, timing, and ring collapse remain 100% governed by `GridService` and `PulseService`.
> - **No final production `.obj`, `.mtl`, `.glb`, `.blend`, or Luau gameplay/service scripts are created or modified in this Phase 1 package.**

## 3. Locked Arena Dimensions & Coordinate Convention

| Parameter | Locked Value | Source Authority |
| :--- | :--- | :--- |
| **Grid Dimensions** | `9 × 9 cells` (`81` initial cells) | `MASTER_IMPLEMENTATION_PLAN.md` §6, `DESIGN_CONSTANTS.md` |
| **Grid Coordinates** | Integer `x, z in {-4, -3, -2, -1, 0, +1, +2, +3, +4}` | `MASTER_IMPLEMENTATION_PLAN.md` §6 |
| **Ring Index Formula** | `D = max(abs(x), abs(z))` (`D=4`: 32 cells -> 49 remain; `D=3`: 24 cells -> 25 remain) | `MASTER_IMPLEMENTATION_PLAN.md` §6 |
| **Tile Pitch** | `12.0000 studs` center-to-center | `MASTER_IMPLEMENTATION_PLAN.md` §6, `DESIGN_CONSTANTS.md` |
| **Grid Centre (`ArenaCFrame`)** | `(0.0000, 50.0000, 0.0000)` | `MASTER_IMPLEMENTATION_PLAN.md` §6 |
| **Tile Centre Transform** | `local tileCenter = (ArenaCFrame * CFrame.new(12 * x, 0, 12 * z)).Position` | `MASTER_IMPLEMENTATION_PLAN.md` §6 |
| **Arena Top Rolling Surface** | `World Y = 51.0000` (`Local Y = +1.0000`) | `MASTER_IMPLEMENTATION_PLAN.md` §6, `DESIGN_CONSTANTS.md` |
| **Authoritative Collision Tile** | `12.0000 × 2.0000 × 12.0000 studs` (`CanCollide = true`, invisible, edge-to-edge) | `MASTER_IMPLEMENTATION_PLAN.md` §6 |
| **Base Visual Tile (`SM_Arena_TileVisual_01`)** | `11.8000 × 2.0000 × 11.8000 studs` (`CanCollide = false`, `CanTouch = false`) | `MASTER_IMPLEMENTATION_PLAN.md` §6, Art Bible |
| **Visible Inter-Tile Groove** | `0.2000 studs` (`0.1000 stud` inset per neighboring visual tile edge) | `MASTER_IMPLEMENTATION_PLAN.md` §6, Art Bible |
| **Standardized Outer Top Bevel** | `0.2500 studs` at `45°` (`COMP_Arena_TileBevelFrame_118`) | Art Bible (`SM_Arena_TileVisual_01`) |
| **Hazard Overlay Envelope** | `11.4000 × 0.0500 × 11.4000 studs` centered at `World Y = 51.0250` (`Local Y = +1.0250`) | `MASTER_IMPLEMENTATION_PLAN.md` §6, Art Bible |
| **Per-Tile Triangle Budget** | Strictly `< 250 triangles` (`~220` Art Bible target; `196` measured in Phase 1 blockout) | `MASTER_IMPLEMENTATION_PLAN.md` §11, Art Bible |
| **Maximum Texture Resolution** | `1024 × 1024` maximum (flat materials or compact palette atlas preferred) | `MASTER_IMPLEMENTATION_PLAN.md` §11, `TASK-09` |

## 4. Six Visual State Categories & Modular Overlay Family

All six visual states use the **exact same `196-triangle` base visual tile (`SM_Arena_TileVisual_01`)** combined with material parity or a non-colliding `11.40 × 0.05 × 11.40` overlay at `Local Y in [+1.0000, +1.0500]`:

| State Category | Variant / Overlay Identifier | Primary Palette Roles | Silhouette & Visual Readability Cue (Color-Independent) | Measured Blockout Triangles |
| :--- | :--- | :--- | :--- | :--- |
| **1. Safe / Neutral Tile** | `SM_Arena_TileVisual_01` (`Variant A` Even / `Variant B` Odd) | `MAT_DarkNeutral` (`#202636`), `MAT_AltNeutral` (`#2A3246`), `MAT_LightTrim` (`#AABED7`), `EMI_Cyan` (`#00C3FF`) | Clean octagonal recessed deck plate with 4 corner L-brackets and thin recessed cyan circuit trench; zero central hazard motif | **196 tris** (Base only) |
| **2. Hazard Warning (Telegraph)** | `OVL_Arena_Warn_Ice`, `OVL_Arena_Warn_Magnetic`, `OVL_Arena_Warn_Boost` | `EMI_Amber` (`#FFAA00`) perimeter + localized next-hazard preview motif | Shared **Amber perimeter border + 4 corner triangle brackets**, paired with the incoming hazard's specific center preview icon/arrows so Ice, Magnetic, and Boost warnings are never indistinguishable | **+38 / +56 / +34 tris** (Overlay) |
| **3. Ice Corridor (Active)** | `OVL_Arena_Active_Ice` | `EMI_Ice` (`#00EBFF`), `MAT_PrimaryText` (`#F5F8FF`), `EMI_Cyan` (`#00C3FF`) | **6-bar crystalline snowflake icon** in center + **twin wide pale corridor chevrons** + lateral frost rails; 100% flat (no ice spikes, slopes, or damage decals) | **+38 tris** (Overlay; **234** combined) |
| **4. Magnetic Storm (Active)** | `OVL_Arena_Active_Magnetic` (Anchor) / `OVL_Arena_Active_MagneticField` (Radius) | `EMI_Magnetic` (`#A537FF`), `MAT_PrimaryText` (`#F5F8FF`) | **2D concentric octagonal pull rings + central diamond anchor node + 4 inward-pointing radial pull triangles** (no heavy 3D per-player tether beams) | **+72 tris** (Anchor) / **+42 tris** (Field) |
| **5. Boost Runway (Active)** | `OVL_Arena_Active_Boost` | `EMI_Kinetic` (`#FF7D00`), `EMI_Amber` (`#FFAA00`), `MAT_PrimaryText` (`#F5F8FF`) | **3 sequential wide one-way forward chevrons + rear horizontal ascending turbine intake bars**; strictly flat `0.05-stud` overlay (never a physical ramp) | **+36 tris** (Overlay; **232** combined) |
| **6. Ring-Collapse Warning & Sink** | `OVL_Arena_Collapse_Warn` (3.0s Warning) / `OVL_Arena_Collapse_Sink` (0.5–0.8s Sink) | `EMI_DangerRed` (`#FF2828`), `MAT_PrimaryText` (`#F5F8FF`) | **Thick red perimeter flash border + asymmetric X-fracture crack lines** during 3.0s warning (collider still active), followed by authoritative collider removal and 0.5–0.8s visual sink/tilt without debris clouds | **+32 tris** (Overlay; **228** combined) |

## 5. Preview Index (`previews/`)

| Preview File | Title & Description |
| :--- | :--- |
| `previews/01_Concept_Safe_Tile_ThreeQuarter.png` | **Single Safe Tile Three-Quarter View**: Variant A (`MAT_DarkNeutral` dominant) and Variant B (`MAT_AltNeutral` dominant) beauty renders, Neutral-Clay form verification, underside structural rib wireframe (`196 measured tris`), and locked specification summary. |
| `previews/02_Concept_Safe_3x3_GridPatch.png` | **Safe 3×3 Grid Patch (`36 × 36 studs`)**: Nine repeated tiles on the locked `12.0-stud` pitch at default gameplay camera distance with a `6.0-stud` diameter reference sphere, top-down orthographic groove rhythm, and 4-corner seam roll clearance close-up. |
| `previews/03_Concept_Tile_Orthographic_Dimensions.png` | **Base Tile Orthographic Dimensions & Separation Diagram**: Top, Front (`+Z`), and Side (`+X` wireframe) views plus an annotated two-cell engineering cross-section proving how the `11.8 × 2.0 × 11.8` `VisualTile` and `11.4 × 0.05 × 11.4` `HazardOverlay` relate to the seamless `12.0 × 2.0 × 12.0` `CollisionTile`. |
| `previews/04_Concept_SixState_Overview.png` | **Six-State Visual Overview**: Side-by-side 3/4 beauty and top-down orthographic silhouette cards for all 6 required visual states (Safe, Warning, Ice Corridor, Magnetic Storm, Boost Runway, and Ring-Collapse Warning/Sink). |
| `previews/05_Concept_Ice_Corridor_Warning_Active.png` | **Ice Corridor Detail**: Pre-hazard warning (`EMI_Amber` border + frost preview) vs. active appearance (`EMI_Ice` frost border, 6-bar snowflake, pale chevrons) and a 3-tile corridor in a `3 × 3` arena patch with a rolling `6.0-stud` sphere. |
| `previews/06_Concept_Magnetic_Storm_Warning_Active.png` | **Magnetic Storm Detail**: Pre-hazard warning vs. active purple anchor (`EMI_Magnetic` `#A537FF`, 2D concentric rings, inward pull vectors) and a `3 × 3` cluster showing the anchor tile surrounded by inward-oriented field tiles. |
| `previews/07_Concept_Boost_Runway_Warning_Active.png` | **Boost Runway Detail**: Pre-hazard warning vs. active one-way propulsion chevrons (`EMI_Kinetic` `#FF7D00` + turbine intake grille), a unified 3-tile cardinal runway strip, and a side orthographic profile proving zero physical ramp slope. |
| `previews/08_Concept_RingCollapse_Sequence.png` | **Ring-Collapse 4-Stage Sequence & D=4 / D=3 Ring Map**: Sequential storyboard (`Safe` -> `3.0s Red Warning/Cracks with Collider Active` -> `Collapse Timestamp Collider Removal` -> `0.5–0.8s Visual Sink/Tilt`), perimeter cutaway, and `9 × 9` ring index diagram (`D = max(abs(x), abs(z))`). |
| `previews/09_Concept_Arena_9x9_Overview.png` | **Full 9×9 Arena Mockup (`81 Cells`)**: Perspective and high-altitude top-down views of an 81-cell board with an **illustrative** multi-hazard layout, six `6.0-stud` spheres, and the full-board triangle budget verification table (`15,876` base tris; `17,220` worst-case tris with 28 active overlays). |

## 6. Package Contents

```text
Sphere_Brawl_Arena_TileVisual_Concept_01/
├── README.md
├── CONCEPT_DESIGN_BRIEF.md
├── CONCEPT_GEOMETRY_AND_INTEGRATION.md
├── CONCEPT_VALIDATION_REPORT.md
├── previews/
│   ├── 01_Concept_Safe_Tile_ThreeQuarter.png
│   ├── 02_Concept_Safe_3x3_GridPatch.png
│   ├── 03_Concept_Tile_Orthographic_Dimensions.png
│   ├── 04_Concept_SixState_Overview.png
│   ├── 05_Concept_Ice_Corridor_Warning_Active.png
│   ├── 06_Concept_Magnetic_Storm_Warning_Active.png
│   ├── 07_Concept_Boost_Runway_Warning_Active.png
│   ├── 08_Concept_RingCollapse_Sequence.png
│   └── 09_Concept_Arena_9x9_Overview.png
├── MANIFEST.json
└── SHA256SUMS.txt
```

## 7. Owner Approval Gate (Phase 1 -> Phase 2)

This package completes **Phase 1 (Concept and Technical Design)** for `SM_Arena_TileVisual_01` and stops at the mandatory owner approval gate.
- **No production `.obj` / `.mtl` / `.glb` files, mesh generators, or Luau service changes have been created.**
- Upon explicit owner approval of this concept package, **Phase 2** will proceed in this same dedicated Argon chat to produce the final production mesh exports (`SM_Arena_TileVisual_01.obj`, `.mtl`, `.glb`), modular overlay meshes, deterministic Python/Blender generator source, automated geometry validation scripts, and Roblox Studio integration guide.
