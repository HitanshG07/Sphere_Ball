# Sphere Brawl: Rolling Rampage — Main Kinetic Hub Platform (`SM_Hub_PlazaPlatform_01`)

**Package Path:** `3d-argon/changes/3/Sphere_Brawl_Hub_Platform_01_Package/`  
**Asset ID:** `SM_Hub_PlazaPlatform_01`  
**Asset Type:** Static Environmental Platform / Floating Kinetic Hub Plaza  
**Authoritative References:** `tasks/TASK-03-KINETIC-HUB-ENVIRONMENT.md`, `MASTER_IMPLEMENTATION_PLAN.md` (§2.1–§2.4, §11.1, §11.3), `specs/DESIGN_CONSTANTS.md`, `3d-argon/sphere_brawl_master_3d_art_bible_and_technical_handoff.md`

## 1. Production & Step 1 QA Correction Summary

This package delivers the validated 3D asset for **`SM_Hub_PlazaPlatform_01`**, the 140-stud floating Kinetic Hub platform defined by **TASK-03** and **Master Implementation Plan §2.4**, incorporating all Step 1 QA corrections:

- **Preserved 3D Geometry:** The exported mesh files (`SM_Hub_PlazaPlatform_01.obj`, `SM_Hub_PlazaPlatform_01.mtl`, `SM_Hub_PlazaPlatform_01.glb`), collision proxy (`COL_PlazaPlatform_Deck.*`), and procedural generator (`scripts/generate_hub_plaza_platform_blender.py`) are preserved 100% unchanged (`2,688 triangles`, `8,064 export vertices`).
- **Corrected Roblox Studio Pivot & Placement Guide (`ROBLOX_STUDIO_IMPORT_GUIDE.md`):** Removed the invalid `Instance.new("Pivot")` statement and documented the supported `platform.PrimaryPart = nil`, `platform.WorldPivot = topSurfacePivot`, and `platform:PivotTo(CFrame.new(0, 150, -300))` workflow for an upright imported model, along with recommended top-deck collision setup and native `Enum.Material.Metal` / `Enum.Material.Neon` assignment.
- **Reconciled Per-Component Triangle & Area Counts:** All documentation files (`MODEL_SPECIFICATION.md`, `VALIDATION_REPORT.md`, `README.md`, `config/hub_plaza_platform_parameters.json`, and `MANIFEST.json`) now report the exact re-derived per-component counts from `SM_Hub_PlazaPlatform_01.obj` and `.glb` (`Deck = 408`, `DeckInlays = 360`, `Rim = 224`, `Structure = 448`, `Underside = 224`, `Trim = 840`, `CyanAccents = 184`; total = `2,688 triangles`).
- **Diagnosed & Resolved Top-Preview Triangulation Artifact:** Mathematical inspection confirmed that all `864` triangles on the `Local Y = 0.0000` walking deck have exact upward normals `vn = (0.00000, 1.00000, 0.00000)` and that the triangular pattern in the earlier preview was a software rasterizer wireframe-overlay artifact. All material-shaded previews (`01`–`04`) and neutral clay renders (`05` left panels) have been re-rendered without wireframe overlays to show the true smooth surface appearance.

## 2. Package Contents

| Relative Path | Description |
|---|---|
| `meshes/SM_Hub_PlazaPlatform_01.obj` | Wavefront OBJ export (`2,688 triangles`, `8,064 vertices`, 7 `o GEO_PlazaPlatform_*` objects, UVs, vertex colors) |
| `meshes/SM_Hub_PlazaPlatform_01.mtl` | Wavefront MTL material library (`MAT_DarkNeutral`, `MAT_AltNeutral`, `MAT_LightTrim`, `EMI_Cyan`) |
| `meshes/SM_Hub_PlazaPlatform_01.glb` | Binary glTF 2.0 export (7 child mesh nodes under root `SM_Hub_PlazaPlatform_01`, `COLOR_0`, `TEXCOORD_0`, embedded PNG atlas) |
| `meshes/collision_proxy/COL_PlazaPlatform_Deck.obj` | Optional simplified 32-sided top-deck collision proxy (`128 triangles`, `R = 70.0`, `Y in [-2.0, 0.0]`) |
| `meshes/collision_proxy/COL_PlazaPlatform_Deck.mtl` | Companion MTL for optional collision proxy |
| `meshes/collision_proxy/COL_PlazaPlatform_Deck.glb` | Companion GLB for optional collision proxy |
| `textures/SphereBrawl_HubPlatform_PaletteAtlas.png` | 64×64 2×2 sRGB palette swatch texture used by `.glb` and `.obj`/`.mtl` |
| `scripts/generate_hub_plaza_platform_blender.py` | Deterministic procedural generator (runs in standard Python 3 AND inside Blender 3.6+/4.x `bpy`/`bmesh`) |
| `config/hub_plaza_platform_parameters.json` | Machine-readable dimensional, material, and reconciled per-component parameters |
| `previews/01_Preview_ThreeQuarter_Perspective.png` | Required Preview 1: Clean material-shaded three-quarter perspective views (no wireframe overlay) |
| `previews/02_Preview_Top_140Stud_Layout.png` | Required Preview 2: Clean material-shaded top orthographic view & TASK-03 clearance overlay (no wireframe overlay) |
| `previews/03_Preview_Side_and_Underside_Structure.png` | Required Preview 3: Clean material-shaded side orthographic elevation & underside truss views |
| `previews/04_Preview_Material_and_Rim_CloseUp.png` | Required Preview 4: Clean material-shaded close-up renders of outer rim bevels, inner framing ring, and underside girders |
| `previews/05_Preview_NeutralClay_and_Wireframe.png` | Required Preview 5: Clean neutral studio clay renders (left) and dedicated technical wireframe views (right) |
| `docs/README.md` | Package overview and directory guide (mirrored at package root `README.md`) |
| `docs/MODEL_SPECIFICATION.md` | Detailed architectural, dimensional, pivot, and reconciled per-component specification (mirrored at root) |
| `docs/ROBLOX_STUDIO_IMPORT_GUIDE.md` | Corrected Roblox Studio 3D Importer, `WorldPivot`/`PivotTo`, material, and collision setup guide (mirrored at root) |
| `docs/VALIDATION_REPORT.md` | Reconciled validation report with explicit `PASS` / `NOT RUN` / `REQUIRES OWNER REVIEW` statuses (mirrored at root) |
| `manifest/SM_Hub_PlazaPlatform_01.manifest.json` | Canonical asset-manifest entry conforming to `specs/ASSET_MANIFEST.schema.json` |
| `MANIFEST.json` | Complete package file inventory with byte sizes, reconciled component counts, and SHA-256 digests |
| `SHA256SUMS.txt` | Standard `sha256sum -c` compatible checksum manifest for all package files |

## 3. Reproducible Generation Command

To deterministically regenerate the `.obj`, `.mtl`, `.glb`, and optional collision proxy in standard Python 3:

```bash
python3 scripts/generate_hub_plaza_platform_blender.py --out_dir ./repro_exports
```

To generate inside Blender 3.6+ / 4.x and also save an editable `.blend` file:

```bash
blender --background --python scripts/generate_hub_plaza_platform_blender.py -- --out_dir ./repro_exports
```
