# Roblox Studio Import & Integration Guide — `SM_Hub_PlazaPlatform_01`

> **Important Verification Disclosure:** Because Roblox Studio is not available inside the headless Linux container where this package was built, the live Roblox Studio import, placement, material assignment, and R15 walkability steps below are marked **`NOT RUN`** in the sandbox validation report and must be executed inside Roblox Studio during owner/integration verification.

## 1. Recommended Import File & 3D Importer Settings

Import **`meshes/SM_Hub_PlazaPlatform_01.glb`** (preferred) or **`meshes/SM_Hub_PlazaPlatform_01.obj`** via **Avatar / File -> Import 3D** in Roblox Studio.

| Importer Setting | Required Value | Why It Matters |
|---|---|---|
| **Import As Model** | `Enabled (true)` | Preserves the root `SM_Hub_PlazaPlatform_01` `Model` container |
| **Merge Meshes** | `Disabled (false)` | Preserves the 7 named `GEO_PlazaPlatform_*` child `MeshPart`s (`Deck`, `DeckInlays`, `Rim`, `Structure`, `Underside`, `Trim`, `CyanAccents`) for per-slot material assignment |
| **Scale Unit** | `Studs (1.0 Unit = 1.0 Stud)` | Produces the locked `140.0 × 12.0 × 140.0 stud` dimensions |
| **Up / Forward Axis** | `+Y Up`, `+Z Forward` (upright orientation) | Keeps the walking deck horizontal (`+Y` normal) and aligns the 4 cardinal walkway bridges with `±X` and `±Z` |
| **Anchor All Parts** | `Enabled (true)` | Static lobby environment geometry must remain `Anchored = true` |

## 2. Supported Pivot Calibration & World Placement (`World Y = 150.0000` Top Surface)

### Key Rules for `Model.WorldPivot` in Roblox Studio
1. **`PrimaryPart` Override Rule:** In Roblox, `Model.WorldPivot` controls a `Model`'s pivot **only when `Model.PrimaryPart == nil`**. If the 3D Importer automatically assigns one of the child `MeshPart`s as `PrimaryPart`, setting `Model.WorldPivot` has no effect unless `platform.PrimaryPart = nil` is set first.
2. **Upright Orientation Assumption:** The top-surface pivot calculation `bboxCFrame.Position + Vector3.new(0, bboxSize.Y / 2, 0)` assumes the imported `SM_Hub_PlazaPlatform_01` model is **upright (`+Y Up`) and has not been rotated** prior to calibrating the pivot.
3. **Top-Surface Alignment:** The mesh is authored with its top walking surface at `Local Y = 0.0000` and its lower keel at `Local Y = -12.0000` (`12.0 studs` total vertical thickness). Placing the top-surface pivot at `(0, 150, -300)` positions the bounding-box center at `(0, 144, -300)` and the top walking surface at **`World Y = 150.0000`**.

### Step-by-Step Placement & Dimension Verification Snippet (Command Bar)

Run the following supported Luau snippet in the Roblox Studio Command Bar after importing `SM_Hub_PlazaPlatform_01` into `Workspace` (not yet executed in live Studio; status: `NOT RUN` in headless container):

```luau
local Workspace = game:GetService("Workspace")
local platform = Workspace:WaitForChild("SM_Hub_PlazaPlatform_01")

assert(platform:IsA("Model"), "Expected SM_Hub_PlazaPlatform_01 to be a Model")

-- WorldPivot controls the pivot for a Model without a PrimaryPart.
platform.PrimaryPart = nil

local bboxCFrame, bboxSize = platform:GetBoundingBox()

assert(
    math.abs(bboxSize.X - 140) < 0.05
        and math.abs(bboxSize.Y - 12) < 0.05
        and math.abs(bboxSize.Z - 140) < 0.05,
    "Imported platform dimensions are incorrect"
)

-- The model is upright, so the top surface is half the bounding-box
-- height above the bounding-box centre.
local topSurfacePivot = CFrame.new(
    bboxCFrame.Position + Vector3.new(0, bboxSize.Y / 2, 0)
)

-- Changing WorldPivot does not itself reposition the geometry.
platform.WorldPivot = topSurfacePivot

-- Place the centre of the top walking surface at the locked Hub centre.
platform:PivotTo(CFrame.new(0, 150, -300))

local finalCFrame, finalSize = platform:GetBoundingBox()

assert(math.abs(finalCFrame.Position.Y + finalSize.Y / 2 - 150) < 0.05,
    "Top walking surface is not at world Y = 150")

print("Platform placement and dimensions verified:", finalSize)
```

## 3. Native Roblox Material Assignment & Visual Mesh Configuration

1. **Why `TextureID` Should Be Cleared When Applying Native Materials:**
   - `SM_Hub_PlazaPlatform_01.glb` and `.obj` include baked vertex colors (`COLOR_0`) and an embedded 64×64 PNG swatch texture (`SphereBrawl_HubPlatform_PaletteAtlas.png`) so the asset never imports as default pale grey.
   - However, glTF/OBJ exports do not automatically configure `Enum.Material.Neon` or native Roblox metallic reflectance, and leaving a `TextureID` bound on a `MeshPart` can tint or mute `MeshPart.Color` under `Enum.Material.Metal` / `Enum.Material.Neon`.
   - Clearing `MeshPart.TextureID = ""` (and any child `SurfaceAppearance`) before assigning `MeshPart.Material` and `MeshPart.Color` ensures crisp, unwashed native Roblox `Metal` and `Neon` appearance.
2. **Non-Interfering Visual Mesh Flags:**
   - All 7 visual `GEO_PlazaPlatform_*` child `MeshPart`s must have `Anchored = true`, `CanCollide = false`, `CanTouch = false`, and `CanQuery = false` so decorative panel seams and recessed conduits never interfere with player physics, touch triggers, or raycasts.

| Child `MeshPart` Name | Triangles | `MeshPart.Material` | `MeshPart.Color` (`Color3.fromRGB`) | Hex | Surface Role |
|---|---:|---|---|---|---|
| `GEO_PlazaPlatform_Deck` | `408` | `Enum.Material.Metal` | `Color3.fromRGB(32, 38, 54)` | `#202636` | Primary walkable deck surface |
| `GEO_PlazaPlatform_DeckInlays` | `360` | `Enum.Material.Metal` | `Color3.fromRGB(42, 50, 70)` | `#2A3246` | Flush top-deck sector inlays & channel bevels |
| `GEO_PlazaPlatform_Rim` | `224` | `Enum.Material.Metal` | `Color3.fromRGB(32, 38, 54)` | `#202636` | Outer structural rim & vertical sidewall |
| `GEO_PlazaPlatform_Structure` | `448` | `Enum.Material.Metal` | `Color3.fromRGB(42, 50, 70)` | `#2A3246` | Stepped mid-hull & 8 radial underside box-girders |
| `GEO_PlazaPlatform_Underside` | `224` | `Enum.Material.Metal` | `Color3.fromRGB(32, 38, 54)` | `#202636` | Lower hull & central keel |
| `GEO_PlazaPlatform_Trim` | `840` | `Enum.Material.Metal` | `Color3.fromRGB(170, 190, 215)` | `#AABED7` | Rim bevels, brackets, cleats, and soffit gussets |
| `GEO_PlazaPlatform_CyanAccents` | `184` | `Enum.Material.Neon` | `Color3.fromRGB(0, 195, 255)` | `#00C3FF` | Recessed cyan conduits & perimeter status diodes |

```luau
local Workspace = game:GetService("Workspace")
local platform = Workspace:WaitForChild("SM_Hub_PlazaPlatform_01")

local MATERIAL_MAP = {
    GEO_PlazaPlatform_Deck        = { Mat = Enum.Material.Metal, Color = Color3.fromRGB(32, 38, 54) },
    GEO_PlazaPlatform_DeckInlays  = { Mat = Enum.Material.Metal, Color = Color3.fromRGB(42, 50, 70) },
    GEO_PlazaPlatform_Rim         = { Mat = Enum.Material.Metal, Color = Color3.fromRGB(32, 38, 54) },
    GEO_PlazaPlatform_Structure   = { Mat = Enum.Material.Metal, Color = Color3.fromRGB(42, 50, 70) },
    GEO_PlazaPlatform_Underside   = { Mat = Enum.Material.Metal, Color = Color3.fromRGB(32, 38, 54) },
    GEO_PlazaPlatform_Trim        = { Mat = Enum.Material.Metal, Color = Color3.fromRGB(170, 190, 215) },
    GEO_PlazaPlatform_CyanAccents = { Mat = Enum.Material.Neon,  Color = Color3.fromRGB(0, 195, 255) },
}

for _, desc in ipairs(platform:GetDescendants()) do
    if desc:IsA("MeshPart") and MATERIAL_MAP[desc.Name] then
        local spec = MATERIAL_MAP[desc.Name]
        desc.Anchored = true
        desc.CanCollide = false
        desc.CanTouch = false
        desc.CanQuery = false
        desc.TextureID = ""
        for _, child in ipairs(desc:GetChildren()) do
            if child:IsA("SurfaceAppearance") then
                child:Destroy()
            end
        end
        desc.Material = spec.Mat
        desc.Color = spec.Color
    end
end
```

## 4. Walkable Collision Surface Setup & Recommendation

### Recommended Method: Native Roblox Cylinder Part (Option A — Primary Recommendation)

Between a **native Roblox Cylinder `Part` (Option A)** and the **exported 32-gon collision proxy mesh `COL_PlazaPlatform_Deck.glb` (Option B)**, **Option A (Native Roblox Cylinder `Part`) is recommended** for the authoritative walkable collision surface:
- **Why Option A is recommended:** A single native Roblox `Part` with `Shape = Enum.PartType.Cylinder` (`Size = Vector3.new(2, 140, 140)`, rotated `90°` on Z so its circular faces are horizontal and its top surface lies at exact `World Y = 150.0000`) provides an analytic, zero-seam plane with zero convex-hull decomposition boundaries. R15 avatars walking from Main Spawn `(0, 150, -334)` across the central Queue Pad `(0, 150, -300)` to the peripheral stations cannot snag on internal mesh edges.
- **When to use Option B (`meshes/collision_proxy/COL_PlazaPlatform_Deck.glb`):** Use Option B (`128 triangles`, `140 × 2 × 140 studs`) with `CollisionFidelity = Enum.CollisionFidelity.Hull` only if you want the outer perimeter collision boundary to match the exact 32-gon facet vertices of the visual rim rather than a true circle.

```luau
-- Option A (Recommended): Create an authoritative invisible native Cylinder collider under SM_Hub_PlazaPlatform_01
local Workspace = game:GetService("Workspace")
local platform = Workspace:WaitForChild("SM_Hub_PlazaPlatform_01")

local existingCol = platform:FindFirstChild("COL_PlazaPlatform_Deck")
if existingCol then
    existingCol:Destroy()
end

local colPart = Instance.new("Part")
colPart.Name = "COL_PlazaPlatform_Deck"
colPart.Shape = Enum.PartType.Cylinder
-- Roblox Cylinder axis is local X: X = height (2 studs), Y = diameter (140 studs), Z = diameter (140 studs)
colPart.Size = Vector3.new(2, 140, 140)
-- Center at Y = 149 so the top flat face (149 + 2/2) sits at exact World Y = 150.0000
colPart.CFrame = CFrame.new(0, 149, -300) * CFrame.Angles(0, 0, math.rad(90))
colPart.Anchored = true
colPart.Transparency = 1
colPart.CanCollide = true
colPart.CanTouch = false
colPart.CanQuery = true
pcall(function()
    colPart.CollisionGroup = "LobbyWorld"
end)
colPart.Parent = platform
```

## 5. Practical Roblox Studio Verification Checklist (For Live Studio Execution)

After running the snippets in Sections 2–4 inside Roblox Studio, verify the following 5 practical checks:
1. **Bounding Box & Top Elevation:** Confirm `finalSize` prints approximately `(140, 12, 140)` and `finalCFrame.Position.Y + finalSize.Y / 2 == 150`.
2. **Visual Mesh Non-Interference:** Confirm all 7 `GEO_PlazaPlatform_*` child `MeshPart`s have `Anchored = true`, `CanCollide = false`, `CanTouch = false`, `CanQuery = false`.
3. **Native Material Appearance:** Confirm `GEO_PlazaPlatform_Deck`, `Rim`, and `Underside` read as dark gunmetal slate (`#202636` `Metal`), `DeckInlays` and `Structure` read as secondary slate (`#2A3246` `Metal`), `Trim` reads as light metallic highlights (`#AABED7` `Metal`), and `CyanAccents` glows cleanly (`#00C3FF` `Neon`) without washing out the dark structure.
4. **R15 Avatar Walkability:** Playtest in Solo mode from Main Spawn `(0, 150, -334)` facing `+Z` toward `(0, 150, -300)` and walk across the central area and out to Customize `(-43, 150, -300)`, Shop `(43, 150, -300)`, Mode Board `(35, 150, -326)`, and Leaderboard `(35, 150, -274)` confirming zero snagging, seam drops, or raised decorative obstacles.
5. **Queue Portal Co-Placement:** Import `QueuePortalArch_Prototype.glb` (`SM_Hub_QueuePortalArch_01`) at `(0, 150, -300)` and confirm its `R = 15.20..20.47` floor curbs/pylons sit cleanly inside the platform's recessed inner framing ring (`R = 21.20..23.00`) with zero duplicated rings or geometry overlap.
