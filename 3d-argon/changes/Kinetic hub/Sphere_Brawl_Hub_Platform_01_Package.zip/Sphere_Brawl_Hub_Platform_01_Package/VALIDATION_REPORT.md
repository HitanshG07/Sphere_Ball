# Validation Report — `SM_Hub_PlazaPlatform_01` (Step 1 QA Correction)

**Validation Timestamp:** 2026-10-23  
**Validator Scripts:** `render_and_validate_hub_platform.py`, `qa_correction_step1.py`, `update_docs_and_repackage.py`

## 1. Required Validation Scorecard (Prompt §11 & Step 1 QA Correction §3–§5)

| Check | Expected Result | Measured Evidence / Verification Details | Status |
|---|---|---|---|
| **Asset identity** | `SM_Hub_PlazaPlatform_01` used consistently | Root node in `.glb`, header in `.obj`/`.mtl`, manifest ID, and documentation all use `SM_Hub_PlazaPlatform_01`. | **PASS** |
| **Geometry preservation** | Existing `.obj`, `.mtl`, `.glb` and generator preserved | SHA-256 digests of `SM_Hub_PlazaPlatform_01.obj`, `.mtl`, `.glb`, `COL_PlazaPlatform_Deck.*`, and `generate_hub_plaza_platform_blender.py` verified 100% identical before and after QA correction. | **PASS** |
| **Outer diameter** | Exactly `140 studs` | Measured across all `8,064` export vertices in `.obj` and `.glb`: `2 * max(sqrt(X^2 + Z^2)) = 140.0000 studs` (`R_max = 70.0000 studs`). | **PASS** |
| **XZ footprint** | Does not exceed `140 × 140 studs` | Measured bounding box: `X in [-70.0000, +70.0000]` (`140.0000 studs`), `Z in [-70.0000, +70.0000]` (`140.0000 studs`). | **PASS** |
| **Top-surface elevation** | Local top = `0`; intended world top = `Y 150` | Measured `Y_max = 0.0000 studs`, `Y_min = -12.0000 studs` (`0` vertices with `Y > 0.0000`). At world pivot `(0, 150, -300)`, top surface maps to `World Y = 150.0000`. | **PASS** |
| **Pivot & Placement Guide** | Supported `Model.WorldPivot` & `Model:PivotTo()` workflow | Invalid `WorldPivotData = Instance.new("Pivot")` removed from `ROBLOX_STUDIO_IMPORT_GUIDE.md`; replaced with `platform.PrimaryPart = nil`, `platform.WorldPivot = topSurfacePivot`, and `platform:PivotTo(CFrame.new(0, 150, -300))` with upright assumption documented. | **PASS** |
| **Axis convention** | Verified for Roblox import | Authored and exported with `+Y Up`, `+Z Forward`, `+X Right`, `1.0 unit = 1.0 stud`. Cardinal bridges align with `0°, 90°, 180°, 270°`. | **PASS** |
| **Queue Portal clearance (File-Level 3D Check)** | No conflicting or duplicated portal-pad geometry | Inspected `QueuePortalArch_Prototype.obj` (`R_floor in [15.20, 20.4658]`, queue pad `R = 14.0`). Platform surface in `R <= 21.20` is 100% flat at `Y = 0.0000` (`0` protrusions). Inner framing ring sits at `R in [21.20, 23.00]` (recessed conduit `R in [21.65, 22.55]`, `+0.7342 studs` radial clearance outside portal pylon buttresses). | **PASS** |
| **Mesh integrity** | No detected degenerate faces, inverted normals or unintended holes | `0` degenerate triangles (`min_area = 0.052000 sq. studs`), `0` face-winding/normal mismatches (`dot(n_geom, vn) == 1.0` across all `2,688` faces), `100%` finite coordinates. | **PASS** |
| **Top-Deck Triangulation Diagnosis & Clean Previews** | Determine if triangular pattern is preview artifact or model defect; provide clean material-shaded previews | Verified all `864` triangles at `Local Y = 0.0000` have identical upward normals `vn = (0.00000, 1.00000, 0.00000)`. Confirmed pattern was a software preview wireframe-overlay artifact. Re-rendered `01`–`04` and `05` (clay panels) without wireframe overlays, confirming a smooth, uniform planar top deck. | **PASS** |
| **Visual appearance** | Coherent structural layers, consistent bevels and controlled cyan accents | Verified across all 5 clean material-shaded/clay preview sheets; `MAT_DarkNeutral` = `67.13%` top area (`63.31%` 3D area), `MAT_AltNeutral` = `24.04%` top (`27.92%` 3D), `MAT_LightTrim + EMI_Cyan` = `8.82%` top (`8.77%` 3D). | **REQUIRES OWNER REVIEW** |
| **Material separation & Component Count Reconciliation** | Expected material slots survive export; all reports agree on per-component counts | Re-derived directly from `.obj` and `.glb`: `Deck = 408`, `DeckInlays = 360`, `Rim = 224`, `Structure = 448`, `Underside = 224`, `Trim = 840`, `CyanAccents = 184` (`Total = 2,688 triangles`). Reconciled across `MODEL_SPECIFICATION.md`, `VALIDATION_REPORT.md`, `README.md`, `config/`, and `MANIFEST.json`. | **PASS** |
| **Triangle count** | Measured and recorded | `2,688 triangles` (`8,064 export vertices`) in both `.obj` and `.glb` (below the proposed `6,000` triangle target). Optional collision proxy `COL_PlazaPlatform_Deck` is `128 triangles`. | **PASS** |
| **File consistency** | OBJ, MTL, GLB and source correspond to the same final design | `.obj` and `.glb` match 100% on total and per-component triangle counts, vertex counts, bounding box (`[-70, -12, -70]` to `[70, 0, 70]`), and child node names. | **PASS** |
| **Reproducibility** | Generator runs successfully in the available environment | Executed `python3 scripts/generate_hub_plaza_platform_blender.py --out_dir /tmp/repro_hub_test`; output `.obj`, `.mtl`, and `.glb` produced 100% identical SHA-256 hashes. | **PASS** |
| **Import verification (Local Re-Import Parser)** | Re-opened and parsed exported `.obj`, `.mtl`, and `.glb` locally | Executed independent Python parsers (`parse_and_validate_obj`, `parse_and_validate_mtl`, `parse_and_validate_glb`, `audit_exported_obj_and_glb`) verifying binary glTF chunks, accessors, normals, UVs, and vertex colors. | **PASS** |
| **Practical Studio Check 1: Live 3D Importer & `WorldPivot` Placement** | Import `.glb` (`Import As Model = true`, `Merge Meshes = false`, `1 unit = 1 stud`), run `WorldPivot`/`PivotTo` script, verify `140×12×140` bounds & `World Y = 150` top | Roblox Studio is not installed in this headless Linux container. Supported `WorldPivot`/`PivotTo` verification script is provided in `ROBLOX_STUDIO_IMPORT_GUIDE.md` §2. | **NOT RUN** |
| **Practical Studio Check 2: Visual Mesh Non-Interference & Collision Surface** | Verify visual `MeshPart`s have `Anchored = true, CanCollide = false, CanTouch = false, CanQuery = false` and single collision surface (`COL_PlazaPlatform_Deck`) is active | Roblox Studio is not installed in this headless Linux container. Setup script and primary recommendation (Native Roblox Cylinder `Part` vs. `COL_PlazaPlatform_Deck.glb` proxy) are documented in `ROBLOX_STUDIO_IMPORT_GUIDE.md` §3–§4. | **NOT RUN** |
| **Practical Studio Check 3: Native `Metal` & `Neon` Material Appearance** | Verify native `Enum.Material.Metal` and `Enum.Material.Neon` + `Color3` (with `TextureID = ""` cleared) produce expected look without washing out | Roblox Studio is not installed in this headless Linux container. Setup script clearing `TextureID` and `SurfaceAppearance` before applying `Metal`/`Neon` + `Color3` is provided in `ROBLOX_STUDIO_IMPORT_GUIDE.md` §3. | **NOT RUN** |
| **Practical Studio Check 4: Live R15 Avatar Walkability & Portal Co-Placement** | Walk R15 avatar from `(0, 150, -334)` across central zone and verify `SM_Hub_QueuePortalArch_01` co-placement in Studio | Offline geometry check confirms `0` vertices above `Y = 0.0000` and `+0.7342 studs` radial clearance outside portal pylons (`PASS` offline); live R15 Studio playtest is not executable in headless Linux container. | **NOT RUN** |
| **Blender `.blend` Binary Creation** | Native `.blend` file creation via Blender executable | Blender (`blender` / `bpy`) is not installed in this Linux container. `scripts/generate_hub_plaza_platform_blender.py` includes full `bpy`/`bmesh` code to save `SM_Hub_PlazaPlatform_01.blend` when run in Blender 3.6+/4.x. | **NOT RUN** |
| **Package integrity & Checksums** | ZIP opens cleanly and `SHA256SUMS.txt` matches all final deliverables | Verified with `zipfile.ZipFile.testzip()` (`0` errors) and programmatic SHA-256 verification across all 27 package entries. | **PASS** |

## 2. Reconciled Per-Component Measured Breakdown (`SM_Hub_PlazaPlatform_01.obj` & `.glb`)

All numbers below are re-derived directly from the actual exported `meshes/SM_Hub_PlazaPlatform_01.obj` and `meshes/SM_Hub_PlazaPlatform_01.glb` files and match `MODEL_SPECIFICATION.md` and `MANIFEST.json` 100%:

| Component (`o` / GLB Child Node) | Material Slot | Triangle Count | Export Vertices | 3D Surface Area (`sq. studs` / `%`) | Top-Projected Area (`sq. studs` / `%`) |
|---|---|---:|---:|---:|---:|
| `GEO_PlazaPlatform_Deck` | `MAT_DarkNeutral` | `408` | `1224` | `10,065.16` (`26.33%`) | `10,065.16` (`59.27%`) |
| `GEO_PlazaPlatform_DeckInlays` | `MAT_AltNeutral` | `360` | `1080` | `2,312.46` (`6.05%`) | `2,251.69` (`13.26%`) |
| `GEO_PlazaPlatform_Rim` | `MAT_DarkNeutral` | `224` | `672` | `3,344.81` (`8.75%`) | `1,335.26` (`7.86%`) |
| `GEO_PlazaPlatform_Structure` | `MAT_AltNeutral` | `448` | `1344` | `8,359.66` (`21.87%`) | `1,831.23` (`10.78%`) |
| `GEO_PlazaPlatform_Underside` | `MAT_DarkNeutral` | `224` | `672` | `10,790.92` (`28.23%`) | `0.00` (`0.00%`) |
| `GEO_PlazaPlatform_Trim` | `MAT_LightTrim` | `840` | `2520` | `2,234.77` (`5.85%`) | `981.33` (`5.78%`) |
| `GEO_PlazaPlatform_CyanAccents` | `EMI_Cyan` | `184` | `552` | `1,116.47` (`2.92%`) | `517.03` (`3.04%`) |
| **Total (`SM_Hub_PlazaPlatform_01`)** | **4 Materials** | **`2,688`** | **`8,064`** | **`38,224.24` (`100.00%`)** | **`16,981.69` (`100.00%`)** |
| `COL_PlazaPlatform_Deck` (Optional Collision Proxy) | `MAT_DarkNeutral` | `128` | `384` | `31,633.90` | `15,295.36` |
