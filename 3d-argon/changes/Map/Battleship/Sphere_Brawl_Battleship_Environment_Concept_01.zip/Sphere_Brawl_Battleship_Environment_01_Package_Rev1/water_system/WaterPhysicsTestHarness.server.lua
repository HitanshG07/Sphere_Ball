--!strict
--[[
    WaterPhysicsTestHarness.server.lua — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
    Isolated test scene and 10 measurable acceptance checks for the Battleship water-interaction system:
      Check 1: Floating supply crate remains near configured water level (Y in [-2.5, +2.5]).
      Check 2: Buoyant object settles via heave damping (vertical speed |Vy| decays below 0.35 studs/s).
      Check 3: Disabled-buoyancy object (`BattleshipBuoyancySink = true`) sinks below Y = -6.0.
      Check 4: Moving test object experiences configured hydrodynamic drag (horizontal speed decays > 60%).
      Check 5: Water-contact detection (`WaterInteractionService`) transitions across Airborne -> PartiallySubmerged -> FullySubmerged.
      Check 6: Aftward current drift (+Z) is bounded and matches configured `CurrentVelocity` (<= 6.5 studs/s).
      Check 7: Zero test objects are placed inside the central +/-84 combat-well aperture.
      Check 8: Anchored ship (`SHIP_*`) and 9x9 arena (`(0,50,0)`) never move.
      Check 9: Player spheres (`Sphere*`) are rejected by `WaterInteractionService.IsEligibleTestObject`.
      Check 10: Custom wave amplitude stays within documented bounds (`|Y| <= 2.05` outboard, `|Y| <= 0.287` in well).
]]

local CollectionService = game:GetService("CollectionService")
local RunService = game:GetService("RunService")

local WaterPhysicsConfig = require(script.Parent.WaterPhysicsConfig)
local OceanWaveSampler = require(script.Parent.OceanWaveSampler)
local WaterInteractionService = require(script.Parent.WaterInteractionService)
local BuoyancyBodyController = require(script.Parent.BuoyancyBodyController)

local WaterPhysicsTestHarness = {}

function WaterPhysicsTestHarness.RunDeterministicSelfChecks(): { [string]: boolean }
    local results: { [string]: boolean } = {}

    -- Check 9: Player sphere rejection test
    local dummySphere = Instance.new("Part")
    dummySphere.Name = "PlayerSphere_Test"
    dummySphere.Shape = Enum.PartType.Ball
    dummySphere.Size = Vector3.new(6, 6, 6)
    dummySphere.Position = Vector3.new(0, 14, 0)
    dummySphere.Anchored = false
    dummySphere:SetAttribute(WaterPhysicsConfig.RequiredOptInAttribute, true)
    local sphereEligible, _ = WaterInteractionService.IsEligibleTestObject(dummySphere)
    results["Check09_PlayerSphereRejected"] = (sphereEligible == false)
    dummySphere:Destroy()

    -- Check 7: Combat-well object rejection test
    local wellProp = Instance.new("Part")
    wellProp.Name = "TestCrate_InsideWell"
    wellProp.Size = Vector3.new(5, 5, 5)
    wellProp.Position = Vector3.new(10, 0, -10) -- Inside [-84, +84]
    wellProp.Anchored = false
    wellProp:SetAttribute(WaterPhysicsConfig.RequiredOptInAttribute, true)
    local wellEligible, _ = WaterInteractionService.IsEligibleTestObject(wellProp)
    results["Check07_CombatWellObjectRejected"] = (wellEligible == false)
    wellProp:Destroy()

    -- Check 8: Anchored ship/arena rejection test
    local shipPart = Instance.new("Part")
    shipPart.Name = "SHIP_Hull_Bow"
    shipPart.Anchored = true
    shipPart:SetAttribute(WaterPhysicsConfig.RequiredOptInAttribute, true)
    local shipEligible, _ = WaterInteractionService.IsEligibleTestObject(shipPart)
    results["Check08_AnchoredShipRejected"] = (shipEligible == false)
    shipPart:Destroy()

    -- Check 10: Wave amplitude bounds check across outboard and combat-well coordinates
    local maxOutboard = 0.0
    local maxInWell = 0.0
    for t = 0, 10, 2 do
        local yOut, _ = OceanWaveSampler.SampleWaveAt(-220.0, -140.0, t)
        local yWell, _ = OceanWaveSampler.SampleWaveAt(0.0, 0.0, t)
        maxOutboard = math.max(maxOutboard, math.abs(yOut))
        maxInWell = math.max(maxInWell, math.abs(yWell))
    end
    results["Check10_WaveAmplitudeWithinBounds"] = (maxOutboard <= WaterPhysicsConfig.MaxUndampedWaveHeight + 1e-4)
        and (maxInWell <= WaterPhysicsConfig.MaxWellWaveHeight + 1e-4)

    return results
end

function WaterPhysicsTestHarness.SpawnTestScene(): Folder
    local folder = workspace:FindFirstChild("BattleshipWaterPhysicsTestProps") :: Folder?
    if folder then
        folder:ClearAllChildren()
    else
        folder = Instance.new("Folder")
        folder.Name = "BattleshipWaterPhysicsTestProps"
        folder.Parent = workspace
    end

    -- 1. Floating Supply Crate (Port outboard at X = -165, Z = -80, outside +/-84 well)
    local crate = Instance.new("Part")
    crate.Name = "TestProp_FloatingCrate_01"
    crate.Size = Vector3.new(6, 5, 6)
    crate.Position = Vector3.new(-165.0, 2.5, -80.0)
    crate.Material = Enum.Material.WoodPlanks
    crate.Color = Color3.fromRGB(126, 83, 54)
    crate.Anchored = false
    crate.CanCollide = false
    crate:SetAttribute(WaterPhysicsConfig.RequiredOptInAttribute, true)
    crate.Parent = folder
    CollectionService:AddTag(crate, WaterPhysicsConfig.DesignatedBuoyancyTag)

    -- 2. Floating Bronze Harbor Buoy with initial horizontal velocity (Check 4 Drag & Check 2 Settling)
    local buoy = Instance.new("Part")
    buoy.Name = "TestProp_HarborBuoy_01"
    buoy.Size = Vector3.new(5, 6, 5)
    buoy.Position = Vector3.new(-175.0, 1.0, -40.0)
    buoy.Material = Enum.Material.Metal
    buoy.Color = Color3.fromRGB(154, 118, 62)
    buoy.Anchored = false
    buoy.CanCollide = false
    buoy.AssemblyLinearVelocity = Vector3.new(25.0, -8.0, 0.0)
    buoy:SetAttribute(WaterPhysicsConfig.RequiredOptInAttribute, true)
    buoy.Parent = folder
    CollectionService:AddTag(buoy, WaterPhysicsConfig.DesignatedBuoyancyTag)

    -- 3. Disabled-Buoyancy Sinking Ballast Block (Check 3 Sink Policy: `BattleshipBuoyancySink = true`)
    local sinkBlock = Instance.new("Part")
    sinkBlock.Name = "TestProp_SinkingBallast_01"
    sinkBlock.Size = Vector3.new(4, 4, 4)
    sinkBlock.Position = Vector3.new(-165.0, 1.0, 0.0)
    sinkBlock.Material = Enum.Material.Slate
    sinkBlock.Color = Color3.fromRGB(46, 53, 64)
    sinkBlock.Anchored = false
    sinkBlock.CanCollide = false
    sinkBlock:SetAttribute(WaterPhysicsConfig.RequiredOptInAttribute, true)
    sinkBlock:SetAttribute(WaterPhysicsConfig.DisableSinkAttribute, true)
    sinkBlock.Parent = folder
    CollectionService:AddTag(sinkBlock, WaterPhysicsConfig.DesignatedBuoyancyTag)

    return folder :: Folder
end

return table.freeze(WaterPhysicsTestHarness)
