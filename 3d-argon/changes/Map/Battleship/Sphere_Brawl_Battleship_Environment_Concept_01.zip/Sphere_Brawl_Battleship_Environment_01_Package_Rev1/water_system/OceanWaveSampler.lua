--!strict
--[[
    OceanWaveSampler.lua — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
    Deterministic 3-swell wave height, surface normal, and 8-corner bounding-box wave sampler.
    NOTE: When `SurfaceMode == "CustomMeshAndMultipointSolver"`, this module samples the exact
    3-component directional wave field used to author `OCEAN_Surface_Forward` and `OCEAN_Surface_Aft`.
    It does NOT claim exact correspondence with Roblox's internal `Terrain` shader waves.
]]

local WaterPhysicsConfig = require(script.Parent.WaterPhysicsConfig)

export type PointWaveSample = {
    WorldPoint: Vector3,
    WaterHeightY: number,
    SurfaceNormal: Vector3,
    SubmergedDepth: number,
    IsSubmerged: boolean,
}

export type MultipointFootprintSample = {
    CenterWaveHeightY: number,
    AverageWaterHeightY: number,
    AverageSurfaceNormal: Vector3,
    SubmergedCornerCount: number,
    SubmergedVolumeFraction: number,
    CornerSamples: { PointWaveSample },
}

local OceanWaveSampler = {}

-- Local 8-corner normalized offsets of a BasePart bounding box
local CORNER_OFFSETS = {
    Vector3.new(-0.5, -0.5, -0.5),
    Vector3.new( 0.5, -0.5, -0.5),
    Vector3.new(-0.5, -0.5,  0.5),
    Vector3.new( 0.5, -0.5,  0.5),
    Vector3.new(-0.5,  0.5, -0.5),
    Vector3.new( 0.5,  0.5, -0.5),
    Vector3.new(-0.5,  0.5,  0.5),
    Vector3.new( 0.5,  0.5,  0.5),
}

function OceanWaveSampler.GetEnvelopeDamping(worldX: number, worldZ: number): number
    if math.abs(worldZ) < 245.0 and math.abs(worldX) < 122.0 then
        return WaterPhysicsConfig.CombatWellWaveDampingFactor
    end
    return 1.0
end

function OceanWaveSampler.SampleWaveAt(worldX: number, worldZ: number, timeSec: number): (number, Vector3)
    local totalY = WaterPhysicsConfig.SeaLevelY
    local dYdX = 0.0
    local dYdZ = 0.0
    local damp = OceanWaveSampler.GetEnvelopeDamping(worldX, worldZ)

    for _, w in ipairs(WaterPhysicsConfig.WaveSpectrum) do
        local k = (2.0 * math.pi) / w.Wavelength
        local phase = k * (w.DirectionX * worldX + w.DirectionZ * worldZ) + (w.Speed * k) * timeSec
        local s = math.sin(phase)
        local c = math.cos(phase)
        local amp = w.Amplitude * damp

        totalY += amp * s
        dYdX += amp * k * w.DirectionX * c
        dYdZ += amp * k * w.DirectionZ * c
    end

    local normal = Vector3.new(-dYdX, 1.0, -dYdZ).Unit
    return totalY, normal
end

function OceanWaveSampler.SampleMultipointBox(partCFrame: CFrame, partSize: Vector3, timeSec: number): MultipointFootprintSample
    local centerWaveY, centerNormal = OceanWaveSampler.SampleWaveAt(partCFrame.Position.X, partCFrame.Position.Z, timeSec)
    local cornerSamples: { PointWaveSample } = table.create(8)
    local sumWaterY = 0.0
    local sumNormal = Vector3.zero
    local submergedCorners = 0

    -- We also integrate submergence along the 4 vertical columns of the oriented box
    local columnSubmergenceSum = 0.0
    local halfSize = partSize * 0.5

    for i = 1, 8 do
        local localOff = CORNER_OFFSETS[i] * partSize
        local worldPt = partCFrame:PointToWorldSpace(localOff)
        local wy, wn = OceanWaveSampler.SampleWaveAt(worldPt.X, worldPt.Z, timeSec)
        local depth = math.max(0.0, wy - worldPt.Y)
        local isSub = depth > 0.0
        if isSub then
            submergedCorners += 1
        end
        sumWaterY += wy
        sumNormal += wn
        cornerSamples[i] = {
            WorldPoint = worldPt,
            WaterHeightY = wy,
            SurfaceNormal = wn,
            SubmergedDepth = depth,
            IsSubmerged = isSub,
        }
    end

    -- Compute submerged fraction across the 4 bottom-to-top vertical columns (corners 1..4 bottom, 5..8 top)
    for col = 1, 4 do
        local botSample = cornerSamples[col]
        local topSample = cornerSamples[col + 4]
        local waveY = 0.5 * (botSample.WaterHeightY + topSample.WaterHeightY)
        local minY = math.min(botSample.WorldPoint.Y, topSample.WorldPoint.Y)
        local maxY = math.max(botSample.WorldPoint.Y, topSample.WorldPoint.Y)
        local span = math.max(0.05, maxY - minY)
        local colFrac = math.clamp((waveY - minY) / span, 0.0, 1.0)
        columnSubmergenceSum += colFrac
    end

    local avgSubmergence = math.clamp(columnSubmergenceSum / 4.0, 0.0, 1.0)
    local avgNormal = if sumNormal.Magnitude > 1e-5 then sumNormal.Unit else centerNormal

    return {
        CenterWaveHeightY = centerWaveY,
        AverageWaterHeightY = sumWaterY / 8.0,
        AverageSurfaceNormal = avgNormal,
        SubmergedCornerCount = submergedCorners,
        SubmergedVolumeFraction = avgSubmergence,
        CornerSamples = cornerSamples,
    }
end

return table.freeze(OceanWaveSampler)
