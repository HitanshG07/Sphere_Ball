--!strict
--[[
    WaterInteractionService.lua — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
    Classifies designated-object water contact and submergence states using:
    1. Multipoint 8-corner wave sampling (`OceanWaveSampler.SampleMultipointBox`) when
       `SurfaceMode == "CustomMeshAndMultipointSolver"`.
    2. Native Roblox `BuoyancySensor` (`TouchingSurface` and `FullySubmerged` properties) when
       `SurfaceMode == "RobloxTerrainWater"` and a `BuoyancySensor` child is present on the part.
    Enforces strict opt-in validation so player spheres, arena tiles, and ship parts are NEVER registered.
]]

local WaterPhysicsConfig = require(script.Parent.WaterPhysicsConfig)
local OceanWaveSampler = require(script.Parent.OceanWaveSampler)

export type ContactState = "Airborne" | "SkimmingSurface" | "PartiallySubmerged" | "FullySubmerged" | "SinkingDisabled"

export type WaterInteractionReport = {
    IsEligibleTestProp: boolean,
    RejectionReason: string?,
    ContactState: ContactState,
    SubmergedVolumeFraction: number,
    DisplacedVolumeStuds3: number,
    AverageWaterHeightY: number,
    SurfaceNormal: Vector3,
    SubmergedCornerCount: number,
}

local WaterInteractionService = {}

function WaterInteractionService.IsEligibleTestObject(part: BasePart): (boolean, string?)
    if not part or not part:IsA("BasePart") then
        return false, "Not a BasePart"
    end
    if part.Anchored then
        return false, "Part is Anchored (environment/ship/arena geometry remains fixed)"
    end
    -- Reject any part inside the central 168x168 combat well fall column
    local pos = part.Position
    if math.abs(pos.X) < WaterPhysicsConfig.CombatWellHalfExtent and math.abs(pos.Z) < WaterPhysicsConfig.CombatWellHalfExtent then
        return false, "Part is inside the +/-84 central combat-well aperture"
    end
    -- Reject forbidden gameplay/ship names (Player Spheres, Arena Tiles, Ship modules)
    local nameLower = string.lower(part.Name)
    for _, forbidden in ipairs(WaterPhysicsConfig.ForbiddenNameSubstrings) do
        if string.find(nameLower, string.lower(forbidden), 1, true) then
            return false, string.format("Forbidden gameplay/environment object name (%s)", forbidden)
        end
    end
    -- Require explicit opt-in attribute
    if part:GetAttribute(WaterPhysicsConfig.RequiredOptInAttribute) ~= true then
        return false, "Missing explicit opt-in attribute BattleshipBuoyancyEnabled = true"
    end
    return true, nil
end

function WaterInteractionService.EvaluatePart(part: BasePart, timeSec: number): WaterInteractionReport
    local eligible, reason = WaterInteractionService.IsEligibleTestObject(part)
    if not eligible then
        return {
            IsEligibleTestProp = false,
            RejectionReason = reason,
            ContactState = "Airborne",
            SubmergedVolumeFraction = 0.0,
            DisplacedVolumeStuds3 = 0.0,
            AverageWaterHeightY = WaterPhysicsConfig.SeaLevelY,
            SurfaceNormal = Vector3.yAxis,
            SubmergedCornerCount = 0,
        }
    end

    local totalVolume = part.Size.X * part.Size.Y * part.Size.Z
    local sinkDisabled = (part:GetAttribute(WaterPhysicsConfig.DisableSinkAttribute) == true)

    -- Check if native Roblox Terrain mode + BuoyancySensor is active
    if WaterPhysicsConfig.SurfaceMode == "RobloxTerrainWater" then
        local sensor = part:FindFirstChildOfClass("BuoyancySensor")
        if sensor then
            local state: ContactState = "Airborne"
            local frac = 0.0
            if sensor.FullySubmerged then
                state = if sinkDisabled then "SinkingDisabled" else "FullySubmerged"
                frac = 1.0
            elseif sensor.TouchingSurface then
                state = if sinkDisabled then "SinkingDisabled" else "PartiallySubmerged"
                frac = 0.5
            end
            return {
                IsEligibleTestProp = true,
                RejectionReason = nil,
                ContactState = state,
                SubmergedVolumeFraction = frac,
                DisplacedVolumeStuds3 = totalVolume * frac,
                AverageWaterHeightY = WaterPhysicsConfig.SeaLevelY,
                SurfaceNormal = Vector3.yAxis,
                SubmergedCornerCount = if sensor.FullySubmerged then 8 elseif sensor.TouchingSurface then 4 else 0,
            }
        end
    end

    -- Authoritative Custom Multipoint 8-Corner Wave Evaluation
    local mp = OceanWaveSampler.SampleMultipointBox(part.CFrame, part.Size, timeSec)
    local frac = mp.SubmergedVolumeFraction
    local state: ContactState = "Airborne"

    if frac <= 0.001 and mp.SubmergedCornerCount == 0 then
        state = "Airborne"
    elseif sinkDisabled then
        state = "SinkingDisabled"
    elseif frac >= 0.98 and mp.SubmergedCornerCount == 8 then
        state = "FullySubmerged"
    elseif frac <= 0.12 then
        state = "SkimmingSurface"
    else
        state = "PartiallySubmerged"
    end

    return {
        IsEligibleTestProp = true,
        RejectionReason = nil,
        ContactState = state,
        SubmergedVolumeFraction = frac,
        DisplacedVolumeStuds3 = totalVolume * frac,
        AverageWaterHeightY = mp.AverageWaterHeightY,
        SurfaceNormal = mp.AverageSurfaceNormal,
        SubmergedCornerCount = mp.SubmergedCornerCount,
    }
end

return table.freeze(WaterInteractionService)
