--!strict
--[[
    WaterPhysicsConfig.lua — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
    Project: Sphere Brawl: Rolling Rampage
    Authoritative Water Architecture:
      Custom 3-Swell Ocean Surface (`OCEAN_Surface_Forward` + `OCEAN_Surface_Aft`) +
      Continuous Multi-Zone Wake (`OCEAN_Wake_BowAndHull`) +
      8-Point Multipoint Archimedes Buoyancy & Drag Solver (`BuoyancyBodyController.lua`).

    WHY THIS ARCHITECTURE WAS SELECTED OVER ROBLOX TERRAIN WATER:
    1. Zero Unintended Player Buoyancy: Roblox `Terrain` water (`LiquidOccupancy`) applies native engine
       upward buoyancy and swimming physics to ALL unanchored `BasePart`s indiscriminately. A custom
       mesh + opt-in `VectorForce`/`Torque` solver guarantees that player spheres are NEVER affected by
       water forces and always trigger authoritative server elimination at `World Y < 15.0`.
    2. Exact Curved Hull-Waterline Fit & Combat-Well Wave Damping: `Terrain` water operates on a
       4x4x4-stud voxel grid (`resolution = 4`) that steps jaggedly along the curved Pirate Dreadnought
       hull and cannot selectively damp wave amplitude inside the central `168x168` (`X/Z in [-84, +84]`)
       combat well. Our custom 3-swell field damps wave amplitude to `14%` (`Y in [-0.276, +0.276]`)
       inside the combat well while maintaining full `+/-1.976 stud` open-ocean swells outboard.
    3. Zero Z-Fighting or Double Buoyancy: When `SurfaceMode == "CustomMeshAndMultipointSolver"` (default),
       `OceanVisualController` ensures no competing `Terrain` water is written at `Y = 0`. If a developer
       explicitly switches `SurfaceMode` to `"RobloxTerrainWater"`, `OceanVisualController` hides the
       `OCEAN_Surface_Forward`/`Aft` meshes and `BuoyancyBodyController` disables custom upward lift so
       z-fighting and double-buoyancy never occur.
]]

export type WaveComponent = {
    DirectionX: number,
    DirectionZ: number,
    Wavelength: number,
    Amplitude: number,
    Speed: number,
    Steepness: number,
}

local WaterPhysicsConfig = {
    -- Authoritative Implementation Mode ("CustomMeshAndMultipointSolver" | "RobloxTerrainWater")
    SurfaceMode = "CustomMeshAndMultipointSolver",

    -- Locked Arena & Void-Elimination Safety Constants (NEVER MODIFY)
    ArenaCenter = Vector3.new(0.0, 50.0, 0.0),
    ArenaGridFootprint = Vector2.new(108.0, 108.0),
    ArenaTopSurfaceY = 51.0,
    SphereDiameter = 6.0,
    LockedVoidEliminationY = 15.0,
    CombatWellHalfExtent = 84.0,            -- 168x168 clear aperture (X, Z in [-84, +84])

    -- Ocean Datum & Damping Envelope
    SeaLevelY = 0.0,                        -- Nominal ocean surface height (World Y = 0.0)
    CombatWellWaveDampingFactor = 0.14,     -- Damps wave amplitude inside hull/well footprint (|Z|<245, |X|<122)
    MaxUndampedWaveHeight = 2.05,           -- Theoretical sum of amplitudes (1.15 + 0.62 + 0.28 = 2.05 studs)
    MaxWellWaveHeight = 0.287,              -- 2.05 * 0.14 = 0.287 studs (leaves >14.71 studs below Y = 15.0!)

    -- Explicit Opt-In Registration Contract for Non-Gameplay Floating Test Props
    DesignatedBuoyancyTag = "BattleshipFloatingTestProp",
    RequiredOptInAttribute = "BattleshipBuoyancyEnabled",
    DisableSinkAttribute = "BattleshipBuoyancySink",
    ForbiddenNameSubstrings = { "Sphere", "Player", "Ball", "Tile", "Arena", "SHIP_", "Turret" },
    MaxRegisteredBuoyantBodies = 24,

    -- Physical & Hydrodynamic Constants (Roblox studs & seconds)
    WaterDensity = 1.025,                   -- Saltwater relative density
    BuoyancyDisplacementScale = 2.00,       -- Calibrated so unit-density wood crate floats at ~68% submergence
    Gravity = 196.2,                        -- Standard Roblox workspace gravity (studs/s^2)
    LinearDragCoefficient = 3.10,           -- Hydrodynamic linear velocity resistance
    VerticalHeaveDamping = 4.60,            -- Vertical oscillation settling damper
    AngularDragCoefficient = 3.80,          -- Rotational pitch/roll damping
    RightingTorqueStiffness = 46.0,         -- Surface-normal alignment stiffness
    CurrentVelocity = Vector3.new(0.0, 0.0, 6.5), -- Subtle aftward (+Z) ocean drift

    -- Optional Roblox Terrain Water Settings (used only if SurfaceMode == "RobloxTerrainWater")
    TerrainWaterSettings = {
        WaterColor = Color3.fromRGB(11, 42, 71),
        WaterReflectance = 0.85,
        WaterTransparency = 0.22,
        WaterWaveSize = 0.45,
        WaterWaveSpeed = 16.0,
    },

    -- 3-Component Directional Harmonic Wave Spectrum (Matches `OCEAN_Surface_Forward` & `Aft`)
    WaveSpectrum = {
        {
            DirectionX = 0.848,
            DirectionZ = 0.530,
            Wavelength = 195.0,
            Amplitude = 1.15,
            Speed = 14.0,
            Steepness = 0.32,
        },
        {
            DirectionX = 0.447,
            DirectionZ = -0.894,
            Wavelength = 145.0,
            Amplitude = 0.62,
            Speed = 11.5,
            Steepness = 0.28,
        },
        {
            DirectionX = 0.707,
            DirectionZ = 0.707,
            Wavelength = 78.0,
            Amplitude = 0.28,
            Speed = 8.5,
            Steepness = 0.22,
        },
    } :: { WaveComponent },
}

return table.freeze(WaterPhysicsConfig)
