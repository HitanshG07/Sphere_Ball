# Battleship Open-Ocean Water & Wind System (`water_system/`)

## 1. Module Responsibilities

| Module File | Runtime Scope | Primary Responsibility |
| :--- | :--- | :--- |
| `WaterPhysicsConfig.lua` | Shared (`ReplicatedStorage`) | Authoritative configuration: `SurfaceMode`, locked arena/well constants (`±84.0` well, `Y < 15.0` elimination), 3-swell wave spectrum, saltwater density (`1.025`), drag/damping coefficients, and opt-in safety rules. |
| `OceanWaveSampler.lua` | Shared (`ReplicatedStorage`) | Deterministic 3-swell wave height $Y(x, z, t)$, surface normal $\mathbf{N}(x, z, t)$, combat-well damping (`14%`), and 8-corner oriented bounding-box submergence integration (`SampleMultipointBox`). |
| `WaterInteractionService.lua` | Server / Shared | Evaluates 4-state contact classification (`"Airborne"`, `"SkimmingSurface"`, `"PartiallySubmerged"`, `"FullySubmerged"`, `"SinkingDisabled"`), supports native `BuoyancySensor` when `SurfaceMode == "RobloxTerrainWater"`, and enforces strict opt-in eligibility (`IsEligibleTestObject`). |
| `BuoyancyBodyController.lua` | Server (`ServerScriptService`)| Applies 8-point Archimedes upward buoyancy, vertical heave settling damping, horizontal current-relative linear drag (`VectorForce`), and surface-normal alignment righting torque (`Torque`) to designated test props. |
| `OceanVisualController.lua` | Server / Client | Configures `OCEAN_Surface_Forward`, `OCEAN_Surface_Aft`, and `OCEAN_Wake_BowAndHull` as non-colliding anchored scenery and prevents z-fighting if `RobloxTerrainWater` mode is selected. |
| `FlagWindController.client.lua`| Client (`StarterPlayerScripts`)| Animates the 4-bone skinned mainmast skull curtain flag (`SHIP_SkullFlag_Curtain_Skinned.glb`: `Bone_FlagRoot_Yardarm` -> `Bone_FlagUpper` -> `Bone_FlagMid` -> `Bone_FlagFreeEdge`) via `Bone.Transform` on `RunService.RenderStepped`. |
| `WaterPhysicsTestHarness.server.lua`| Server (Test Harness) | Spawns 3 outboard test objects (`TestProp_FloatingCrate_01`, `TestProp_HarborBuoy_01`, `TestProp_SinkingBallast_01` at `X = -165..-175`) and executes the 10 measurable acceptance checks. |

## 2. Mandatory Gameplay Safety Rules

1. **Fixed Ship & Arena:** Every mesh in `SM_ArenaEnvironment_Battleship_01` and the central `9 × 9` Kinetic Grid at `(0, 50, 0)` remain `Anchored = true`.
2. **Player Spheres Never Float:** `WaterInteractionService.IsEligibleTestObject` explicitly rejects any part without `BattleshipBuoyancyEnabled = true`, any part inside `X, Z ∈ [-84, +84]`, and any part matching `"Sphere"`, `"Player"`, `"Ball"`, `"Tile"`, `"Arena"`, or `"SHIP_"`.
3. **Unchanged Server Void Elimination (`World Y < 15.0`):** Falling player spheres trigger elimination at `World Y < 15.0`—`15.0 studs` above the nominal `World Y = 0.0` ocean surface.
