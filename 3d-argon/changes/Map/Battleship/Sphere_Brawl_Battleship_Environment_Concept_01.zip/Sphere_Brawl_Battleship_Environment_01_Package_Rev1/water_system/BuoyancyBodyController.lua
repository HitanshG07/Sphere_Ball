--!strict
--[[
    BuoyancyBodyController.lua — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
    Multipoint 8-Corner Archimedes Buoyancy, Heave Damping, Linear Drag & Righting Torque Solver.
    Uses supported Roblox `VectorForce` and `Torque` constraints attached to the part's center of mass.

    Features:
    1. Multipoint 8-corner wave sampling via `WaterInteractionService.EvaluatePart`.
    2. Upward buoyant force proportional to submerged displaced volume and configured saltwater density.
    3. Explicit disable/sink policy (`BattleshipBuoyancySink = true` disables upward lift while retaining
       hydrodynamic drag so disabled objects sink smoothly under gravity).
    4. Vertical heave damping + horizontal relative-velocity drag (including ocean current drift).
    5. Surface-normal alignment righting torque + rotational angular velocity damping.
    6. Refuses to register anchored parts, player spheres, arena tiles, or objects inside the +/-84 well.
]]

local WaterPhysicsConfig = require(script.Parent.WaterPhysicsConfig)
local WaterInteractionService = require(script.Parent.WaterInteractionService)

local BuoyancyBodyController = {}
BuoyancyBodyController.__index = BuoyancyBodyController

export type BuoyancyControllerInstance = typeof(setmetatable({} :: {
    Part: BasePart,
    Attachment: Attachment,
    VectorForce: VectorForce,
    Torque: Torque,
    LastReport: WaterInteractionService.WaterInteractionReport?,
}, BuoyancyBodyController))

function BuoyancyBodyController.ComputeForcesPure(
    mass: number,
    linearVel: Vector3,
    angularVel: Vector3,
    partUp: Vector3,
    report: WaterInteractionService.WaterInteractionReport
): (Vector3, Vector3)
    if not report.IsEligibleTestProp or report.SubmergedVolumeFraction <= 0.001 then
        return Vector3.zero, Vector3.zero
    end

    local subFrac = report.SubmergedVolumeFraction
    local isSinking = (report.ContactState == "SinkingDisabled")

    -- In RobloxTerrainWater mode, native Terrain provides upward buoyancy; do not double-count lift!
    local applyCustomLift = (WaterPhysicsConfig.SurfaceMode == "CustomMeshAndMultipointSolver") and (not isSinking)

    local upwardLift = 0.0
    if applyCustomLift then
        local displacedRatio = subFrac * WaterPhysicsConfig.WaterDensity * WaterPhysicsConfig.BuoyancyDisplacementScale
        upwardLift = mass * WaterPhysicsConfig.Gravity * displacedRatio
    end

    -- Relative velocity against ocean current
    local relVel = linearVel - WaterPhysicsConfig.CurrentVelocity
    local dragX = -relVel.X * (mass * WaterPhysicsConfig.LinearDragCoefficient * subFrac)
    local dragZ = -relVel.Z * (mass * WaterPhysicsConfig.LinearDragCoefficient * subFrac)
    local heaveDampY = -linearVel.Y * (mass * WaterPhysicsConfig.VerticalHeaveDamping * subFrac)

    local netForce = Vector3.new(dragX, upwardLift + heaveDampY, dragZ)

    -- Surface-normal alignment righting torque + angular damping
    local alignAxis = partUp:Cross(report.SurfaceNormal)
    local rightingTorque = alignAxis * (mass * WaterPhysicsConfig.RightingTorqueStiffness * subFrac)
    local angularDrag = -angularVel * (mass * WaterPhysicsConfig.AngularDragCoefficient * subFrac)
    local netTorque = rightingTorque + angularDrag

    return netForce, netTorque
end

function BuoyancyBodyController.new(part: BasePart): (BuoyancyControllerInstance?, string?)
    local eligible, reason = WaterInteractionService.IsEligibleTestObject(part)
    if not eligible then
        return nil, reason
    end

    local att = part:FindFirstChild("BuoyancyAttachment") :: Attachment?
    if not att then
        att = Instance.new("Attachment")
        att.Name = "BuoyancyAttachment"
        att.Parent = part
    end

    local vf = part:FindFirstChild("HydroBuoyancyForce") :: VectorForce?
    if not vf then
        vf = Instance.new("VectorForce")
        vf.Name = "HydroBuoyancyForce"
        vf.Attachment0 = att
        vf.RelativeTo = Enum.ActuatorRelativeTo.World
        vf.ApplyAtCenterOfMass = true
        vf.Force = Vector3.zero
        vf.Parent = part
    end

    local tq = part:FindFirstChild("HydroRightingTorque") :: Torque?
    if not tq then
        tq = Instance.new("Torque")
        tq.Name = "HydroRightingTorque"
        tq.Attachment0 = att
        tq.RelativeTo = Enum.ActuatorRelativeTo.World
        tq.Torque = Vector3.zero
        tq.Parent = part
    end

    return setmetatable({
        Part = part,
        Attachment = att :: Attachment,
        VectorForce = vf :: VectorForce,
        Torque = tq :: Torque,
        LastReport = nil,
    }, BuoyancyBodyController), nil
end

function BuoyancyBodyController.Step(self: BuoyancyControllerInstance, timeSec: number): WaterInteractionService.WaterInteractionReport?
    local part = self.Part
    if not part or not part.Parent or part.Anchored then
        self.VectorForce.Force = Vector3.zero
        self.Torque.Torque = Vector3.zero
        return nil
    end

    local report = WaterInteractionService.EvaluatePart(part, timeSec)
    self.LastReport = report

    local force, torque = BuoyancyBodyController.ComputeForcesPure(
        part.AssemblyMass,
        part.AssemblyLinearVelocity,
        part.AssemblyAngularVelocity,
        part.CFrame.UpVector,
        report
    )
    self.VectorForce.Force = force
    self.Torque.Torque = torque
    return report
end

function BuoyancyBodyController.Destroy(self: BuoyancyControllerInstance)
    if self.VectorForce then self.VectorForce:Destroy() end
    if self.Torque then self.Torque:Destroy() end
    if self.Attachment then self.Attachment:Destroy() end
end

return table.freeze(BuoyancyBodyController)
