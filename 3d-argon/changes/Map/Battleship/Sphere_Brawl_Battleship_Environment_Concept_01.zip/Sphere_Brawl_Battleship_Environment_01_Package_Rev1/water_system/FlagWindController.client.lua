--!strict
--[[
    FlagWindController.client.lua — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
    Animates the 4-bone skinned mainmast skull-and-crossbones curtain flag (`SHIP_SkullFlag_Curtain_Skinned.glb`)
    using supported Roblox `Bone.Transform` CFrame offsets on `RunService.RenderStepped`.

    Imported Bone Hierarchy in `SHIP_SkullFlag_Curtain_Skinned.glb`:
      Bone_FlagRoot_Yardarm (Fixed at yardarm Y = 186.5, Z = +92.0 -> Transform = CFrame.identity)
        └── Bone_FlagUpper  (Y = 179.0 -> gentle wind ripple)
              └── Bone_FlagMid (Y = 171.0 -> medium wind wave)
                    └── Bone_FlagFreeEdge (Y = 163.0 -> strongest billow & flutter near bottom free edge)
    Guarantees:
    - Zero detachment from the horizontal signal yardarm (`Bone_FlagRoot_Yardarm.Transform = CFrame.identity`).
    - Stronger local motion near the bottom free edge than near the top yardarm attachment.
    - Never rotates the entire rigid flag and never intersects the mainmast (`Z = +98.0`) or sails.
]]

local RunService = game:GetService("RunService")

local FlagWindController = {}

export type FlagRigBinding = {
    RootBone: Bone,
    UpperBone: Bone,
    MidBone: Bone,
    FreeEdgeBone: Bone,
}

function FlagWindController.ComputeBoneTransformsPure(timeSec: number): (CFrame, CFrame, CFrame, CFrame)
    -- Root yardarm bone remains locked to the horizontal yardarm (zero translation/rotation offset)
    local rootTransform = CFrame.identity

    -- Traveling harmonic wind wave propagating downward from upper cloth to free bottom edge
    local w1 = math.sin(timeSec * 2.8 - 0.6)
    local w2 = math.sin(timeSec * 2.8 - 1.5) + 0.35 * math.cos(timeSec * 5.1 - 0.8)
    local w3 = math.sin(timeSec * 2.8 - 2.4) + 0.45 * math.cos(timeSec * 5.6 - 1.7)

    -- Upper cloth section: small pitch/roll & 0.25-stud aft billow
    local upperTransform = CFrame.new(0.12 * w1, 0.0, -0.25 * math.abs(w1))
        * CFrame.Angles(math.rad(3.2 * w1), math.rad(2.0 * w1), math.rad(1.2 * w1))

    -- Middle cloth section: moderate wave & 0.55-stud billow
    local midTransform = CFrame.new(0.28 * w2, 0.0, -0.55 * math.abs(w2))
        * CFrame.Angles(math.rad(6.5 * w2), math.rad(4.2 * w2), math.rad(2.5 * w2))

    -- Bottom free edge: strongest flutter & 0.95-stud billow
    local freeEdgeTransform = CFrame.new(0.52 * w3, 0.0, -0.95 * math.abs(w3))
        * CFrame.Angles(math.rad(10.8 * w3), math.rad(7.0 * w3), math.rad(4.0 * w3))

    return rootTransform, upperTransform, midTransform, freeEdgeTransform
end

function FlagWindController.BindFlagModel(rootInstance: Instance): FlagRigBinding?
    local bRoot = rootInstance:FindFirstChild("Bone_FlagRoot_Yardarm", true)
    local bUpper = rootInstance:FindFirstChild("Bone_FlagUpper", true)
    local bMid = rootInstance:FindFirstChild("Bone_FlagMid", true)
    local bFree = rootInstance:FindFirstChild("Bone_FlagFreeEdge", true)

    if bRoot and bRoot:IsA("Bone") and bUpper and bUpper:IsA("Bone") and bMid and bMid:IsA("Bone") and bFree and bFree:IsA("Bone") then
        return {
            RootBone = bRoot,
            UpperBone = bUpper,
            MidBone = bMid,
            FreeEdgeBone = bFree,
        }
    end
    return nil
end

function FlagWindController.Start(rootInstance: Instance): RBXScriptConnection?
    local binding = FlagWindController.BindFlagModel(rootInstance)
    if not binding then
        return nil
    end
    local t0 = os.clock()
    return RunService.RenderStepped:Connect(function()
        local t = os.clock() - t0
        local tr0, tr1, tr2, tr3 = FlagWindController.ComputeBoneTransformsPure(t)
        binding.RootBone.Transform = tr0
        binding.UpperBone.Transform = tr1
        binding.MidBone.Transform = tr2
        binding.FreeEdgeBone.Transform = tr3
    end)
end

return table.freeze(FlagWindController)
