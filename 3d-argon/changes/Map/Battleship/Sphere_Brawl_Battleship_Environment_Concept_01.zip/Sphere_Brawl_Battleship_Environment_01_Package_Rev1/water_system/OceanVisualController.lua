--!strict
--[[
    OceanVisualController.lua — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
    Configures and updates the selected ocean visual presentation and wake meshes, ensuring
    there is NEVER z-fighting or double-buoyancy between `OCEAN_Surface_Forward`/`Aft` and
    Roblox `Terrain` water.
]]

local WaterPhysicsConfig = require(script.Parent.WaterPhysicsConfig)

local OceanVisualController = {}

function OceanVisualController.ConfigureEnvironment(environmentModel: Model?)
    local terrain = workspace.Terrain
    if WaterPhysicsConfig.SurfaceMode == "CustomMeshAndMultipointSolver" then
        -- Custom 3-Swell Mesh mode is authoritative: ensure custom ocean & wake meshes are visible
        -- and non-colliding, and do not write competing Terrain water at Y = 0.
        if environmentModel then
            for _, desc in ipairs(environmentModel:GetDescendants()) do
                if desc:IsA("BasePart") and (string.find(desc.Name, "OCEAN_", 1, true) or string.find(desc.Name, "SHIP_", 1, true)) then
                    desc.Anchored = true
                    desc.CanCollide = false
                    desc.CanTouch = false
                    desc.CanQuery = false
                    if string.find(desc.Name, "OCEAN_Surface", 1, true) then
                        desc.Transparency = 0.0
                    end
                end
            end
        end
    elseif WaterPhysicsConfig.SurfaceMode == "RobloxTerrainWater" then
        -- Native Terrain Water mode: apply Terrain water appearance properties and hide the opaque
        -- OCEAN_Surface_Forward/Aft meshes so they never z-fight with Terrain water (while keeping OCEAN_Wake_BowAndHull!).
        local tw = WaterPhysicsConfig.TerrainWaterSettings
        terrain.WaterColor = tw.WaterColor
        terrain.WaterReflectance = tw.WaterReflectance
        terrain.WaterTransparency = tw.WaterTransparency
        terrain.WaterWaveSize = tw.WaterWaveSize
        terrain.WaterWaveSpeed = tw.WaterWaveSpeed

        if environmentModel then
            for _, desc in ipairs(environmentModel:GetDescendants()) do
                if desc:IsA("BasePart") then
                    desc.Anchored = true
                    desc.CanCollide = false
                    desc.CanTouch = false
                    desc.CanQuery = false
                    if desc.Name == "OCEAN_Surface_Forward" or desc.Name == "OCEAN_Surface_Aft" then
                        desc.Transparency = 1.0 -- Hide custom surface mesh to prevent z-fighting with Terrain water
                    end
                end
            end
        end
    end
end

function OceanVisualController.StepVisuals(environmentModel: Model?, timeSec: number)
    if not environmentModel then
        return
    end
    -- Subtle vertical foam pulse on `OCEAN_Wake_BowAndHull` (+0.03 to +0.08 studs) keeping it strictly hugging the hull waterline
    local wakePart = environmentModel:FindFirstChild("OCEAN_Wake_BowAndHull", true)
    if wakePart and wakePart:IsA("BasePart") then
        local baseCFrame = (wakePart:GetAttribute("InitialCFrame") :: CFrame?) or wakePart.CFrame
        if not wakePart:GetAttribute("InitialCFrame") then
            wakePart:SetAttribute("InitialCFrame", baseCFrame)
        end
        local yPulse = 0.04 * math.sin(timeSec * 2.2)
        wakePart.CFrame = baseCFrame + Vector3.new(0.0, yPulse, 0.0)
    end
end

return table.freeze(OceanVisualController)
