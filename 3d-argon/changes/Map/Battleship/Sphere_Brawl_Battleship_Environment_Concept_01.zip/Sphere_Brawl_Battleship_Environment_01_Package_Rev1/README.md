# SM_ArenaEnvironment_Battleship_01 — MAP 02, PHASE 2 PRODUCTION PACKAGE (`Sphere_Brawl_Battleship_Environment_01_Package_Rev1`)

## 1. Asset Identification & Phase 2 Production Status

| Field | Value | Status |
| :--- | :--- | :--- |
| **Project** | Sphere Brawl: Rolling Rampage | LOCKED |
| **Target Repository / Branch** | `HitanshG07/Sphere_Ball` (`3d_mesh`) | LOCKED |
| **Target Engine & Scale** | Roblox Studio (`1 Blender unit = 1 Roblox stud`) | LOCKED |
| **Canonical Asset ID** | `SM_ArenaEnvironment_Battleship_01` | PRODUCTION READY |
| **Map Label** | `BATTLESHIP — OPEN OCEAN` (Map 02) | PRODUCTION READY |
| **Current Phase** | **Phase 2 — Production Assets & Water-System Implementation** | COMPLETE (Awaiting Owner Review) |
| **Approved Input Baseline** | `Sphere_Brawl_Battleship_Environment_Concept_03_GeometryCleanup_Rev2.zip` (`SHA-256: 9f6d50cc...`) | VERIFIED & PRESERVED |
| **Editable `.blend` Status** | `NOT GENERATED — BLENDER UNAVAILABLE` (Deterministic Python generator `source/generate_battleship_environment.py` included) | DOCUMENTED |
| **Live Roblox Studio Execution**| `NOT RUN` (Headless Linux Sandbox; 100% of offline mesh, GLB, UV, skinning, and mathematical water checks `PASS`) | DOCUMENTED |

## 2. Production Package Summary & Sub-20k `MeshPart` Splitting

This package (`Sphere_Brawl_Battleship_Environment_01_Package_Rev1.zip`) converts the approved **Concept 03 Geometry Cleanup Rev 2** Pirate Dreadnought into an import-safe Roblox Studio production environment kit:

- **24 Import-Safe Production `MeshPart` Units (`< 18,000` triangles each, strictly `< 20,000` Roblox Studio limit):**
  - `SHIP_Hull_CurvedHybrid` (`46,848` tris) is cleanly split along naval architectural station boundaries into 4 watertight-adjoining sections: `SHIP_Hull_Bow` (`14,536` tris), `SHIP_Hull_MidshipPort` (`7,360` tris), `SHIP_Hull_MidshipStarboard` (`7,360` tris), and `SHIP_Hull_Stern` (`17,592` tris — largest single `MeshPart` in the package).
  - `SHIP_Decks_And_Forecastle` (`18,512` tris) is split at `Z = 0.0` into `SHIP_Decks_ForwardAndForecastle` (`10,640` tris) and `SHIP_Decks_AftAndWaist` (`7,872` tris).
  - `SHIP_Broadside_Cannons_And_Ports` (`19,136` tris) is split along the centerline `X = 0.0` into `SHIP_Broadside_PortBattery` (`9,568` tris) and `SHIP_Broadside_StarboardBattery` (`9,568` tris).
  - `OCEAN_Surface` (`28,800` tris) is split at `Z = 0.0` into `OCEAN_Surface_Forward` (`14,400` tris) and `OCEAN_Surface_Aft` (`14,400` tris).
- **Complete OBJ/MTL + Self-Contained GLB Delivery (`meshes/`):** Every one of the 24 production units has its own `.obj` (`6`-decimal precision with `v`, `vt`, `vn`, and `f v/vt/vn`), matching `.mtl` (relative `../../textures/` paths), and self-contained `.glb` with embedded `1024×1024` PNG textures, plus the assembled 33-node Master scene `meshes/SM_ArenaEnvironment_Battleship_01_Master.glb`.
- **4-Bone Skinned Skull-and-Crossbones Curtain Flag (`meshes/pirate_flag/SHIP_SkullFlag_Curtain_Skinned.glb` + `FlagWindController.client.lua`):** Includes both the static fallback (`SHIP_SkullFlag_Curtain.obj`/`.mtl`/`.glb`) and the rigged 4-bone skinned `.glb` (`Bone_FlagRoot_Yardarm` -> `Bone_FlagUpper` -> `Bone_FlagMid` -> `Bone_FlagFreeEdge` with `JOINTS_0`, `WEIGHTS_0`, and `inverseBindMatrices`) driven by `water_system/FlagWindController.client.lua` via `Bone.Transform`.
- **Coherent Production Ocean & 8-Point Multipoint Water-Physics System (`water_system/`):** Delivers 7 production Luau modules (`WaterPhysicsConfig.lua`, `OceanWaveSampler.lua`, `WaterInteractionService.lua`, `BuoyancyBodyController.lua`, `OceanVisualController.lua`, `FlagWindController.client.lua`, `WaterPhysicsTestHarness.server.lua`) and `water_system/README.md`.

## 3. Locked Arena Constants vs. Final Production World Bounds

| Parameter | Value | World Coordinate / Bounds | Status |
| :--- | :--- | :--- | :--- |
| **Arena Grid Cells & Pitch** | `9 × 9 cells` (`81 cells`), `12.0-stud pitch` | `ArenaCFrame = CFrame.new(0, 50, 0)` applied once | **LOCKED** |
| **Arena Grid Footprint & Top** | `108.0 × 108.0 studs`, Top `World Y = 51.0` | Visual `11.8×2×11.8`, Collision `12×2×12` | **LOCKED** |
| **Sphere Diameter & Void Threshold**| `6.0 studs` diameter, Elimination `World Y < 15.0` | Authoritative server elimination | **LOCKED** |
| **Central Open Combat Well** | `168.0 × 168.0 studs` (`30.0-stud` border margin) | `X, Z ∈ [-84.0, +84.0]` (`0` ship/wake vertices inside) | **VERIFIED** |
| **Total Ship Length Overall (LOA)** | `556.205 studs` (`480.0` hull length) | `Z ∈ [-302.205, +254.000]` | **MEASURED** |
| **Maximum Beam & Height** | `243.322 studs` beam, `207.100 studs` height | `X ∈ [-121.661, +121.661]`, `Y ∈ [-18.600, +188.500]` | **MEASURED** |
| **Ocean Surface & Wake Bounds** | `1,600.0 × 1,600.0 studs` around `World Y = 0.0` | `X, Z ∈ [-800.0, +800.0]`, `Y ∈ [-1.976, +1.974]` | **MEASURED** |
