# VALIDATION REPORT — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)

## 1. Preserved Input & Concept Archives

| Archive Filename | Byte Size | Verified SHA-256 | Status |
| :--- | ---: | :--- | :--- |
| `Sphere_Brawl_Battleship_Environment_Concept_01.zip` | `12,888,658 B` | `c4d651711a4b22889506a110a7744a676dfd519bff7af9a8f19a307ba77a64f0` | **PRESERVED UNCHANGED** |
| `Sphere_Brawl_Battleship_Environment_Concept_02.zip` | `19,215,814 B` | `9804e3bf7d73db56f74ab03d9288fc218b57594f8de9667f60b360e82478358a` | **PRESERVED UNCHANGED** |
| `Sphere_Brawl_Battleship_Environment_Concept_03_Realism_Rev2.zip` | `25,844,724 B` | `77b7aeece085e14cd097eeffc1c346c984dff0cb5a904804e189f8d2c324e4f0` | **PRESERVED UNCHANGED** |
| `Sphere_Brawl_Battleship_Environment_Concept_03_GeometryCleanup_Rev1.zip` | `39,469,895 B` | `d463630469634509001d2067abee51bc100163e763afb4724519182bad84f4d0` | **PRESERVED UNCHANGED** |
| `Sphere_Brawl_Battleship_Environment_Concept_03_GeometryCleanup_Rev2.zip` | `43,318,984 B` | `9f6d50cc85750aeffc51707b59ae9b13ff22bcc1d4b857dacf7cb2217d4f8718` | **VERIFIED INPUT & PRESERVED** |

## 2. Automated Production Validation Suite Results (`scripts/validate_*.py`)

All four portable validation scripts (`validate_meshes.py`, `validate_glb_materials.py`, `validate_water_config.py`, and `validate_package.py`) were executed against the final production package and verified again after extracting the final `.zip` into a clean temporary directory:

| Validation Check | Target / Criterion | Measured Production Result | Verdict |
| :--- | :--- | :--- | :--- |
| **Per-`MeshPart` Triangle Budget** | Strictly `< 20,000` tris (`<= 18,000` working ceiling) | **Max unit = `17,592` tris (`SHIP_Hull_Stern`); all `24/24` units `< 18,000` tris** | **PASS** |
| **Total Environment Triangles** | Preserves approved `GeometryCleanup_Rev2` geometry | **`220,282` unique env tris / `232,928` instantiated env tris** (`247,184` incl. `9×9` grid proxy) | **PASS** |
| **Degenerate Faces (`OBJ` & `GLB`)** | `Area <= 1e-6 sq studs` or repeated index | **`0` degenerate faces across all `24` OBJs and `26` GLBs** | **PASS** |
| **Duplicate Coplanar Faces (`OBJ` & `GLB`)**| Coordinate match within `1e-3 studs` | **`0` duplicate extra faces across all `24` OBJs and `26` GLBs** | **PASS** |
| **Hull Aspect Ratios & Max Edge** | `0` hull faces `> 150` AR, `0` hull edges `> 50` studs | **`0` hull faces `> 150` AR (`max AR = 85.99`), `0` edges `> 50` (`max = 17.1434 studs`)** | **PASS** |
| **OBJ/MTL `v`/`vt`/`vn` & Texture Paths**| `6`-decimal floats + resolved `../../textures/*.png` | **`100%` valid `v`, `vt`, `vn`, `f v/vt/vn`, and resolved relative texture paths across all `24` OBJs/MTLs** | **PASS** |
| **Embedded GLB PNG Textures** | Valid `\x89PNG\r\n\x1a\n` bufferViews, `0` external URIs | **All `26` GLBs embed valid PNGs; Master GLB embeds all `8/8` `1024×1024` PNGs (`31/31` materials linked)** | **PASS** |
| **4-Bone Skinned Skull Flag GLB** | `Bone_FlagRoot_Yardarm`..`FreeEdge` + `JOINTS_0`/`WEIGHTS_0` | **Verified in `SHIP_SkullFlag_Curtain_Skinned.glb` and `SM_ArenaEnvironment_Battleship_01_Master.glb`** | **PASS** |
| **Central Combat-Well Clearance** | `0` ship/rigging/flag vertices inside `X, Z ∈ (-83.99, +83.99)` | **`0` vertex intrusions across all `145,011` instantiated ship vertices (`30.0-stud` margin around grid)** | **PASS** |
| **Water-System Math & Static Checks** | 10 checks in `scripts/validate_water_config.py` | **`10/10 PASS`** (Floating equilibrium `Y = -1.8775`, settling `0.2694 studs/s`, sink `-118.79`, drag `0.0004`) | **PASS** |
| **Editable `.blend` Source File** | Generate `.blend` if Blender is installed | **`NOT GENERATED — BLENDER UNAVAILABLE`** (`source/generate_battleship_environment.py` included & verified) | **DOCUMENTED** |

## 3. Roblox Studio Live Tests Transparently Marked `NOT RUN`

Because Roblox Studio is not available in this headless Linux environment, the following live engine tests are marked **`NOT RUN`** (with step-by-step manual verification instructions provided in `ROBLOX_STUDIO_IMPORT_GUIDE.md` Section 4):
- Live Studio import of the production `.glb` and `.obj` files.
- Final PBR `SurfaceAppearance` material appearance under Studio lighting.
- Live Studio execution of `FlagWindController.client.lua` on the imported 4-bone `Bone` hierarchy.
- Live Studio runtime water appearance and `OceanVisualController.lua`.
- Live Studio execution of `WaterInteractionService.lua`, `BuoyancyBodyController.lua`, and `WaterPhysicsTestHarness.server.lua`.
- Live Studio frame-time/performance profiling with ship, water, and `9 × 9` grid active together.
- Live Studio falling-sphere playtest across `World Y < 15.0`.
