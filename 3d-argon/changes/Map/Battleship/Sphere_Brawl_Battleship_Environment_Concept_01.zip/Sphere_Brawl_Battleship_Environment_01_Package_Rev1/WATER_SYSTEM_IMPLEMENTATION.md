# WATER SYSTEM IMPLEMENTATION — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)

## 1. Selected Authoritative Water Architecture & Engineering Rationale

After comparing Roblox's native `Terrain` water (`Terrain:WriteVoxelChannels` with `LiquidOccupancy` + `BuoyancySensor`) against our custom multi-swell mesh + multipoint `VectorForce`/`Torque` solver, **Phase 2 Production selects `SurfaceMode = "CustomMeshAndMultipointSolver"` as the authoritative default runtime architecture** (while providing full configurable support for `"RobloxTerrainWater"` in `WaterPhysicsConfig.lua` and `OceanVisualController.lua`):

| Evaluation Criterion | Custom 3-Swell Mesh + Multipoint Solver (Selected Default) | Native Roblox `Terrain` Water (`LiquidOccupancy`) |
| :--- | :--- | :--- |
| **Player Sphere Void-Elimination Safety (`Y < 15.0`)** | **100% Immune:** Only parts with explicit opt-in `BattleshipBuoyancyEnabled = true` and non-forbidden names outside `±84` receive forces. Player spheres never float. | Native `Terrain` water applies engine buoyancy to all unanchored parts that touch water voxels. |
| **Curved Hull-Waterline Fit (`480 × 236` Hull)** | **Exact Smooth Fit:** `OCEAN_Wake_BowAndHull` and `OCEAN_Surface_Forward`/`Aft` conform continuously to `half_beam_at(z, v)`. | `4 × 4 × 4 stud` voxel grid (`resolution = 4`) creates stepped stair-casing along curved diagonal hull lines. |
| **Combat-Well Wave Amplitude Damping** | **Selective Damping (`14%`):** Waves reach `±1.976 studs` outboard (`> 1.0` stud `WaterWaveSize` cap) while staying `<= ±0.278 studs` inside the `±84` combat well. | `Terrain.WaterWaveSize` is globally uniform (`[0, 1]`) and cannot be damped selectively inside the well. |
| **Zero Z-Fighting / Zero Double Buoyancy** | `OceanVisualController` keeps `OCEAN_Surface_Forward`/`Aft` visible and writes zero `Terrain` water. If switched to `"RobloxTerrainWater"`, it hides `OCEAN_Surface_*` and disables custom upward lift. | Guaranteed no overlap in either mode. |

## 2. Separation of Responsibilities Across Visuals, Detection, Buoyancy, Drag & Wake

| Subsystem | Implementation in `water_system/` | Scope & Honest Limitations |
| :--- | :--- | :--- |
| **1. Surface Appearance** | `OCEAN_Surface_Forward.glb` (`14,400` tris) + `OCEAN_Surface_Aft.glb` (`14,400` tris) + `OceanVisualController.lua` | Static high-density 3-swell open-ocean meshes (`1,600 × 1,600 studs`) with PBR roughness/specular shading (`T_Ocean_MultiSwellAndFoam_Albedo_1024.png`). |
| **2. Wake Visuals** | `OCEAN_Wake_BowAndHull.glb` (`10,080` tris) pulsed vertically (`±0.04 studs`) by `OceanVisualController.StepVisuals` | 3-zone continuous foam-to-teal-to-navy wake wrapping the curved bow, hull sides, and stern propeller wash (`0` checkerboard artifacts). |
| **3. Water-Contact Detection** | `WaterInteractionService.EvaluatePart` + `OceanWaveSampler.SampleMultipointBox` (or `BuoyancySensor` in Terrain mode) | Samples all **8 corners** of the oriented bounding box and integrates submergence across the **4 vertical columns** to classify `"Airborne"`, `"SkimmingSurface"`, `"PartiallySubmerged"`, `"FullySubmerged"`, or `"SinkingDisabled"`. |
| **4. Multipoint Buoyant Force** | `BuoyancyBodyController.ComputeForcesPure` (`VectorForce` at center of mass) | Computes upward Archimedes lift $F_y = m g \rho_{\text{water}} c_{\text{disp}} \bar{s}$ from the 4-column integrated submerged volume fraction $\bar{s} \in [0, 1]$. |
| **5. Heave Damping & Drag** | `BuoyancyBodyController.ComputeForcesPure` (`VectorForce` + `Torque`) | Applies vertical heave settling damping ($-m c_{\text{heave}} \bar{s} v_y$), horizontal current-relative linear drag ($-m c_{\text{lin}} \bar{s} (\mathbf{v}_{xz} - \mathbf{v}_{\text{curr}})$), surface-normal alignment torque, and angular damping. |
| **6. Not Implemented (By Design)**| Full Navier-Stokes fluid CFD / dynamic mesh-cutting splashes / ship or arena motion | Ship and `9 × 9` arena remain `Anchored = true` and never bob or roll; player spheres never interact with water physics. |

## 3. Ten Measurable Acceptance Checks (`scripts/validate_water_config.py` & `WaterPhysicsTestHarness.server.lua`)

| Check # | Acceptance Criterion | Measured Numerical / Static Result | Tolerance / Target | Status |
| :- | :--- | :--- | :--- | :--- |
| **1** | Floating crate equilibrium near water level | **`Y = -1.8775 studs`** (at `X = -165, Z = -80`) | `Y ∈ [-2.0, +2.0] studs` | **PASS (Math)** |
| **2** | Buoyant object settles (heave damping) | **`|Vy| = 0.2694 studs/s`** after `10.0 s` | `|Vy| < 0.45 studs/s` | **PASS (Math)** |
| **3** | Disabled-buoyancy object (`BattleshipBuoyancySink`) sinks | **`Y = -118.79 studs`** after `3.0 s` | `Y < -15.0 studs` | **PASS (Math)** |
| **4** | Moving test object experiences linear drag | **`Vx = 0.0004 studs/s`** after `5.0 s` (from `25.0 studs/s`) | `Vx < 0.50 studs/s` (`>98%` decay)| **PASS (Math)** |
| **5** | 8-corner contact classification responds to height | **`s = [0.000, 0.526, 1.000]`** at `Y = [+5.0, 0.0, -4.5]` | `0.0` Air / `0.3..0.8` Part / `1.0` Full | **PASS (Math)** |
| **6** | Aftward ocean current drift (`+Z`) is bounded | **`Vz = 6.4999 studs/s`** | `Vz ∈ [6.0, 6.55] studs/s` | **PASS (Math)** |
| **7** | Zero test props placed inside `±84` combat well | All test props spawned at `X = -165..-175`; well coords rejected | `|X| > 84` or `|Z| > 84` | **PASS (Static)** |
| **8** | Anchored ship (`SHIP_*`) and `9×9` arena never move | `Anchored = true` parts rejected by `IsEligibleTestObject` | `0` forces on anchored parts | **PASS (Static)** |
| **9** | Player spheres never registered for buoyancy | Rejected by missing opt-in attribute & `"Sphere"` name filter | `IsEligibleTestObject == false` | **PASS (Static)** |
| **10**| Custom wave height stays within documented bounds | **Outboard `|Y| <= 1.0535`**, **In-Well `|Y| <= 0.2785`** | Outboard `<= 2.05`, Well `<= 0.287` | **PASS (Math)** |
| **—** | **Live Roblox Studio Engine Playtest** | Headless Linux environment without Roblox Studio binary | Manual steps in Import Guide | **NOT RUN** |
