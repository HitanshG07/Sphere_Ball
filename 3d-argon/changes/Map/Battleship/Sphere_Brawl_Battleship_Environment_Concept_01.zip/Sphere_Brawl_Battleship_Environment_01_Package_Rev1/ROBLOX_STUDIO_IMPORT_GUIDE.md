# ROBLOX STUDIO IMPORT AND INTEGRATION GUIDE — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)

## 1. Recommended Import Route: Self-Contained Master `.glb` or Per-Section `.glb`/`.obj`

Every mesh in this package is strictly below Roblox Studio's **20,000-triangle `MeshPart` limit** (max single unit: `17,592` triangles).

### Route A — Single-Step Master GLB Import (Fastest & Appearance-Authoritative)
1. In Roblox Studio, open **File → Import 3D** (`Ctrl + M`) and select `meshes/SM_ArenaEnvironment_Battleship_01_Master.glb`.
2. In the **3D Importer** settings:
   - **Import Name:** `SM_ArenaEnvironment_Battleship_01`
   - **Scale Unit:** `Studs` (`1 unit = 1 stud`)
   - **Import As Model:** Enabled (`true`)
   - **Upload to Roblox / Import Textures:** Enabled (all 8 `1024×1024` PNG textures are embedded inside the `.glb`).
   - **Rig Type:** `General / Skinned Mesh` (preserves the 4 `Bone` instances `Bone_FlagRoot_Yardarm`, `Bone_FlagUpper`, `Bone_FlagMid`, and `Bone_FlagFreeEdge` under `SHIP_SkullFlag_Curtain`).
3. Click **Import** and set the root model pivot to `CFrame.new(0, 0, 0)`.
4. Delete or hide the `ARENA_Grid9x9_Reference` child `MeshPart` once aligned against the live `GridService` `9 × 9` arena at `(0, 50, 0)`.

### Route B — Modular Per-Section `.glb` or `.obj`/`.mtl` Import
To import individual sections from `meshes/hull/`, `meshes/deck/`, `meshes/superstructure/`, `meshes/turrets/`, `meshes/sails_rigging/`, `meshes/pirate_flag/`, `meshes/arena_well/`, and `meshes/wake/`:
1. Import all 21 world-space modules with **Insert Using Scene Position** enabled (`Pivot = (0, 0, 0)`).
2. Import `meshes/pirate_flag/SHIP_SkullFlag_Curtain_Skinned.glb` with **Import As Skinned Mesh** enabled to preserve its 4 child `Bone` instances.
3. Place 3 clones of `meshes/turrets/SHIP_MainTurret_Triple16.glb` and 8 clones of `meshes/turrets/SHIP_SecondaryTurret_Dual5.glb` using the exact `CFrame` table in `MODEL_SPECIFICATION.md` Section 2.

## 2. Mandatory Collision & Physics Properties on All Environment `MeshPart`s

Run the following setup snippet in the Studio Command Bar (or let `OceanVisualController.ConfigureEnvironment(model)` apply it automatically at runtime) so that **zero ship, flag, or ocean parts ever interfere with falling player spheres**:

```lua
local envModel = workspace:WaitForChild("SM_ArenaEnvironment_Battleship_01")
for _, inst in ipairs(envModel:GetDescendants()) do
    if inst:IsA("BasePart") then
        inst.Anchored = true
        inst.CanCollide = false
        inst.CanTouch = false
        inst.CanQuery = false
        if inst:IsA("MeshPart") then
            inst.CollisionFidelity = Enum.CollisionFidelity.Box
        end
    end
end
```

## 3. Setting Up the Water-Interaction & Skinned Flag Wind Scripts

1. Create a folder `ReplicatedStorage.BattleshipWaterSystem` and place:
   - `water_system/WaterPhysicsConfig.lua`
   - `water_system/OceanWaveSampler.lua`
   - `water_system/WaterInteractionService.lua`
   - `water_system/BuoyancyBodyController.lua`
   - `water_system/OceanVisualController.lua`
2. Place `water_system/FlagWindController.client.lua` inside `StarterPlayer.StarterPlayerScripts` (or require it from your client environment controller and call `FlagWindController.Start(workspace.SM_ArenaEnvironment_Battleship_01)`).
3. To run the isolated 10-check water-physics test scene in Studio, place `water_system/WaterPhysicsTestHarness.server.lua` inside `ServerScriptService`, require it, and call:
   ```lua
   local Harness = require(game.ServerScriptService.WaterPhysicsTestHarness)
   local checkResults = Harness.RunDeterministicSelfChecks()
   print("Self-checks:", checkResults)
   Harness.SpawnTestScene()
   ```

## 4. Manual Studio Verification Steps for Unrun Headless Tests (`NOT RUN` in Linux Sandbox)

Because this package was built and verified in a headless Linux sandbox without live Roblox Studio execution, execute the following manual checks after importing into Roblox Studio:
1. **Mesh & PBR SurfaceAppearance Check:** Confirm all 33 imported `MeshPart` nodes render with their embedded `SurfaceAppearance` textures and zero z-fighting at hull/deck seams.
2. **Skinned Skull Flag Wind Check:** Press **Play** and verify `FlagWindController.client.lua` animates `Bone_FlagUpper`, `Bone_FlagMid`, and `Bone_FlagFreeEdge` while `Bone_FlagRoot_Yardarm` stays locked to the signal yardarm at `(0, 186.5, 92.0)`.
3. **Outboard Buoyancy & Settling Check:** Run `WaterPhysicsTestHarness.SpawnTestScene()` and verify `TestProp_FloatingCrate_01` floats near `Y = 0.0`, `TestProp_HarborBuoy_01` decelerates and settles, and `TestProp_SinkingBallast_01` sinks cleanly.
4. **Central Combat-Well Void-Elimination Check:** Roll a player sphere off all 4 edges (`X/Z = ±54`) and 4 corners of the `9 × 9` grid and verify unimpeded elimination at `World Y < 15.0`.
