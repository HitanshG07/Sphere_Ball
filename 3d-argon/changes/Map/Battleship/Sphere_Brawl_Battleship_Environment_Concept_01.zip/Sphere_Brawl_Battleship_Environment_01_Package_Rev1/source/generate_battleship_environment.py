#!/usr/bin/env python3
"""
Production Environment Generator for SM_ArenaEnvironment_Battleship_01
(Sphere_Brawl_Battleship_Environment_01_Package_Rev1 — Map 02, Phase 2 Production)
Project: Sphere Brawl: Rolling Rampage
Repository: HitanshG07/Sphere_Ball (branch: 3d_mesh)
Scale: 1 Blender unit = 1 Roblox stud

Generates all 24 import-safe production MeshPart units (every mesh strictly < 20,000 triangles,
max mesh = 15,924 triangles), exporting for each unit:
1. Individual Wavefront `.obj` (6-decimal precision, valid `v`, `vt`, `vn`, and `f v/vt/vn`)
2. Matching Wavefront `.mtl` (relative `../../textures/` paths, `map_Kd`, `map_Bump`, `map_Ns`)
3. Self-contained binary glTF 2.0 `.glb` with embedded PNG texture atlases
4. Skinned/rigged 4-bone `.glb` (`SHIP_SkullFlag_Curtain_Skinned.glb`) with `JOINTS_0`, `WEIGHTS_0`,
   `skins`, and `inverseBindMatrices` for `FlagWindController.client.lua`
5. Assembled Master scene `meshes/SM_ArenaEnvironment_Battleship_01_Master.glb` containing all 33
   instantiated production nodes (every node strictly < 20,000 triangles) + embedded textures & flag skin!
"""
import os
import sys
import json
import struct
import math
from pathlib import Path
import numpy as np

PKG_ROOT = str(Path(__file__).resolve().parent.parent)
MESH_ROOT = os.path.join(PKG_ROOT, "meshes")
TEX_DIR = os.path.join(PKG_ROOT, "textures")
INTER_DIR = "/working_dir/c_c02ef7979ca66984/artifacts/file_generation/ttl=63d/intermediate" if os.path.exists("/working_dir/c_c02ef7979ca66984") else os.path.join(PKG_ROOT, "source")

# Load the approved Geometry Cleanup Rev2 builder functions
import importlib.util
_rev2_script = "/working_dir/c_c02ef7979ca66984/artifacts/file_generation/ttl=63d/output/Sphere_Brawl_Battleship_Environment_Concept_03_GeometryCleanup_Rev2/concept_source/build_pirate_dreadnought_concept03_cleanup.py"
if not os.path.exists(_rev2_script):
    _rev2_script = os.path.join(PKG_ROOT, "source/_base_rev2_builder.py")

_spec = importlib.util.spec_from_file_location("rev2", _rev2_script)
rev2 = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rev2)

MATERIALS = rev2.MATERIALS
MeshBuilder = rev2.MeshBuilder
compute_vertex_normals_and_uvs = rev2.compute_vertex_normals_and_uvs
transform_verts = rev2.transform_verts

def split_mesh_by_face_predicate(V, F, M, mat_list, predicate_fn):
    """
    Cleanly splits a mesh `(V, F, M, mat_list)` into two disjoint, watertight-adjoining sub-meshes
    based on `predicate_fn(face_centroids)` without duplicating faces or modifying vertex coordinates/UVs!
    Compacts each sub-mesh's vertex array so only referenced vertices are retained.
    """
    centroids = (V[F[:, 0]] + V[F[:, 1]] + V[F[:, 2]]) / 3.0
    mask_a = predicate_fn(centroids)
    mask_b = ~mask_a

    def extract_submesh(f_mask):
        sub_F_orig = F[f_mask]
        sub_M_orig = M[f_mask]
        if len(sub_F_orig) == 0:
            return np.zeros((0,3), dtype=np.float32), np.zeros((0,3), dtype=np.int32), np.zeros((0,), dtype=np.int32), []
        used_v, inv_idx = np.unique(sub_F_orig, return_inverse=True)
        new_V = V[used_v].astype(np.float32)
        new_F = inv_idx.reshape(sub_F_orig.shape).astype(np.int32)
        # Compact material list
        used_m, m_inv = np.unique(sub_M_orig, return_inverse=True)
        new_mat_list = [mat_list[i] for i in used_m]
        new_M = m_inv.astype(np.int32)
        return new_V, new_F, new_M, new_mat_list

    return extract_submesh(mask_a), extract_submesh(mask_b)

def write_mtl_file(mtl_path, mat_list, tex_rel_prefix="../../textures/"):
    with open(mtl_path, "w", encoding="utf-8") as f:
        f.write("# Sphere Brawl: Rolling Rampage — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production) Material Library\n")
        for mname in mat_list:
            props = MATERIALS[mname]
            r, g, b = props["rgb"]
            f.write(f"\nnewmtl {mname}\n")
            f.write(f"Kd {r:.6f} {g:.6f} {b:.6f}\n")
            f.write(f"Ks {props['metal']*0.5:.6f} {props['metal']*0.5:.6f} {props['metal']*0.5:.6f}\n")
            if props["emit"] > 0:
                f.write(f"Ke {r*props['emit']:.6f} {g*props['emit']:.6f} {b*props['emit']:.6f}\n")
            f.write("d 1.0\nillum 2\n")
            if "tex" in props:
                f.write(f"map_Kd {tex_rel_prefix}{props['tex']}\n")
                if props["tex"] == "T_Pirate_TimberAndBronze_Albedo_1024.png":
                    f.write(f"map_Bump {tex_rel_prefix}T_Pirate_TimberAndBronze_Normal_1024.png\n")
                    f.write(f"map_Ns {tex_rel_prefix}T_Pirate_TimberAndBronze_Roughness_1024.png\n")

def write_obj_file(obj_path, mtl_filename, obj_name, V, F, M, mat_list):
    VN, VT = compute_vertex_normals_and_uvs(V, F, M, mat_list)
    with open(obj_path, "w", encoding="utf-8") as f:
        f.write("# Sphere Brawl: Rolling Rampage — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)\n")
        f.write("# Units: 1 unit = 1 Roblox stud | Precision: 6 decimals | Includes v, vt, vn\n")
        f.write(f"mtllib {mtl_filename}\n")
        f.write(f"\no {obj_name}\n")
        f.writelines([f"v {vx:.6f} {vy:.6f} {vz:.6f}\n" for vx, vy, vz in V])
        f.writelines([f"vt {tu:.6f} {tv:.6f}\n" for tu, tv in VT])
        f.writelines([f"vn {nx:.6f} {ny:.6f} {nz:.6f}\n" for nx, ny, nz in VN])
        for mid, mname in enumerate(mat_list):
            f.write(f"usemtl {mname}\n")
            mask = (M == mid)
            f.writelines([
                f"f {f0+1}/{f0+1}/{f0+1} {f1+1}/{f1+1}/{f1+1} {f2+1}/{f2+1}/{f2+1}\n"
                for f0, f1, f2 in F[mask]
            ])

def compute_flag_skin_joints_and_weights(V):
    """
    Computes 4-bone skeletal skinning attributes `JOINTS_0` (uint16 VEC4) and `WEIGHTS_0` (float32 VEC4)
    for `SHIP_SkullFlag_Curtain` (`Y in [161.898, 188.500]`):
    - Bone 0: `Bone_FlagRoot_Yardarm` at `(0.0, 186.5, 92.0)` (Fixed yardarm mount; top edge & wooden spar have weight 1.0 to Bone 0!)
    - Bone 1: `Bone_FlagUpper`        at `(0.0, 179.0, 92.0)` (Upper curtain cloth section)
    - Bone 2: `Bone_FlagMid`          at `(0.0, 171.0, 92.0)` (Middle curtain cloth section)
    - Bone 3: `Bone_FlagFreeEdge`     at `(0.0, 163.0, 92.0)` (Bottom free-flying edge; strongest wind wave motion)
    Guarantees every vertex weight sum == 1.000000 and the yardarm attachment never detaches!
    """
    N = len(V)
    joints = np.zeros((N, 4), dtype=np.uint16)
    weights = np.zeros((N, 4), dtype=np.float32)

    y_vals = V[:, 1]
    # Normalised distance downward from the yardarm (y = 186.0 -> d = 0.0; y = 162.0 -> d = 1.0)
    d = np.clip((186.0 - y_vals) / 23.0, 0.0, 1.0)

    for i in range(N):
        di = float(d[i])
        if di <= 0.03:
            # Rigidly bound to Bone 0 (Yardarm & grommet ties)
            joints[i] = [0, 1, 2, 3]
            weights[i] = [1.0, 0.0, 0.0, 0.0]
        elif di < 0.35:
            t = (di - 0.03) / 0.32
            joints[i] = [0, 1, 2, 3]
            weights[i] = [1.0 - t, t, 0.0, 0.0]
        elif di < 0.70:
            t = (di - 0.35) / 0.35
            joints[i] = [1, 2, 0, 3]
            weights[i] = [1.0 - t, t, 0.0, 0.0]
        else:
            t = (di - 0.70) / 0.30
            joints[i] = [2, 3, 0, 1]
            weights[i] = [1.0 - t, t, 0.0, 0.0]

    # Normalize weights to sum to 1.0
    w_sum = np.sum(weights, axis=1, keepdims=True)
    weights = weights / np.maximum(w_sum, 1e-7)
    return joints, weights

def write_glb_package(glb_path, objects_list, include_flag_skin_on=None):
    """
    Writes a self-contained glTF 2.0 binary `.glb` containing:
    - Embedded PNG image bufferViews ONLY for the texture atlases actually referenced by `objects_list`
      (or all 8 atlases for the Master GLB)
    - Valid `samplers`, `images`, `textures`, `materials` (`baseColorTexture` + `normalTexture`)
    - `POSITION`, `NORMAL`, `TEXCOORD_0` on every primitive
    - Optional 4-bone skeletal rig (`skins`, `JOINTS_0`, `WEIGHTS_0`, `inverseBindMatrices`, and 4 `Bone_*` nodes)
      when `include_flag_skin_on` matches an object name (e.g. `"SHIP_SkullFlag_Curtain"`).
    """
    used_mat_names = []
    for _, _, _, _, mlist in objects_list:
        for m in mlist:
            if m not in used_mat_names:
                used_mat_names.append(m)
    mat_idx_map = {m: i for i, m in enumerate(used_mat_names)}

    used_tex_files = []
    for mname in used_mat_names:
        p = MATERIALS[mname]
        if "tex" in p and p["tex"] not in used_tex_files:
            used_tex_files.append(p["tex"])
        if p.get("tex") == "T_Pirate_TimberAndBronze_Albedo_1024.png":
            for extra_t in ["T_Pirate_TimberAndBronze_Normal_1024.png", "T_Pirate_TimberAndBronze_Roughness_1024.png"]:
                if extra_t not in used_tex_files:
                    used_tex_files.append(extra_t)

    buffer_bytes = bytearray()
    buffer_views = []
    accessors = []
    meshes = []
    nodes = []
    gltf_images = []
    gltf_textures = []
    gltf_samplers = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}]

    tex_idx_map = {}
    for t_fname in used_tex_files:
        t_path = os.path.join(TEX_DIR, t_fname)
        with open(t_path, "rb") as tf:
            png_bytes = tf.read()
        offset = len(buffer_bytes)
        buffer_bytes.extend(png_bytes)
        while len(buffer_bytes) % 4 != 0:
            buffer_bytes.append(0)
        bv_idx = len(buffer_views)
        buffer_views.append({"buffer": 0, "byteOffset": offset, "byteLength": len(png_bytes)})
        img_idx = len(gltf_images)
        gltf_images.append({"name": os.path.splitext(t_fname)[0], "bufferView": bv_idx, "mimeType": "image/png"})
        tex_idx = len(gltf_textures)
        gltf_textures.append({"name": os.path.splitext(t_fname)[0], "sampler": 0, "source": img_idx})
        tex_idx_map[t_fname] = tex_idx

    gltf_materials = []
    for mname in used_mat_names:
        p = MATERIALS[mname]
        pbr = {
            "baseColorFactor": [p["rgb"][0], p["rgb"][1], p["rgb"][2], 1.0],
            "metallicFactor": float(p["metal"]),
            "roughnessFactor": float(p["rough"]),
        }
        if "tex" in p and p["tex"] in tex_idx_map:
            pbr["baseColorTexture"] = {"index": tex_idx_map[p["tex"]], "texCoord": 0}
        mat_def = {"name": mname, "pbrMetallicRoughness": pbr, "doubleSided": True}
        if p.get("tex") == "T_Pirate_TimberAndBronze_Albedo_1024.png" and "T_Pirate_TimberAndBronze_Normal_1024.png" in tex_idx_map:
            mat_def["normalTexture"] = {"index": tex_idx_map["T_Pirate_TimberAndBronze_Normal_1024.png"], "texCoord": 0, "scale": 1.0}
        if p["emit"] > 0:
            mat_def["emissiveFactor"] = [p["rgb"][0]*p["emit"], p["rgb"][1]*p["emit"], p["rgb"][2]*p["emit"]]
        gltf_materials.append(mat_def)

    def add_accessor(arr, target, comp_type, val_type, include_minmax=False):
        raw = arr.tobytes()
        offset = len(buffer_bytes)
        buffer_bytes.extend(raw)
        while len(buffer_bytes) % 4 != 0:
            buffer_bytes.append(0)
        bv_idx = len(buffer_views)
        bv_entry = {"buffer": 0, "byteOffset": offset, "byteLength": len(raw)}
        if target is not None:
            bv_entry["target"] = target
        buffer_views.append(bv_entry)
        acc = {"bufferView": bv_idx, "byteOffset": 0, "componentType": comp_type, "count": int(len(arr)), "type": val_type}
        if include_minmax:
            acc["min"] = [float(x) for x in arr.min(axis=0).tolist()]
            acc["max"] = [float(x) for x in arr.max(axis=0).tolist()]
        acc_idx = len(accessors)
        accessors.append(acc)
        return acc_idx

    gltf_skins = []
    root_scene_nodes = []

    for obj_name, V, F, M, mat_list in objects_list:
        if len(V) == 0 or len(F) == 0:
            continue
        VN, VT = compute_vertex_normals_and_uvs(V, F, M, mat_list)
        acc_pos = add_accessor(V.astype(np.float32), 34962, 5126, "VEC3", include_minmax=True)
        acc_norm = add_accessor(VN.astype(np.float32), 34962, 5126, "VEC3", include_minmax=False)
        acc_uv = add_accessor(VT.astype(np.float32), 34962, 5126, "VEC2", include_minmax=False)

        is_skinned_flag = (include_flag_skin_on is not None and obj_name == include_flag_skin_on)
        if is_skinned_flag:
            joints_arr, weights_arr = compute_flag_skin_joints_and_weights(V)
            acc_joints = add_accessor(joints_arr, 34962, 5123, "VEC4", include_minmax=False)  # 5123 = UNSIGNED_SHORT
            acc_weights = add_accessor(weights_arr, 34962, 5126, "VEC4", include_minmax=False) # 5126 = FLOAT

        primitives = []
        for local_mid, mname in enumerate(mat_list):
            sub_F = F[M == local_mid].astype(np.uint32).reshape(-1)
            if len(sub_F) == 0:
                continue
            acc_idx = add_accessor(sub_F, 34963, 5125, "SCALAR", include_minmax=False)
            attrs = {"POSITION": acc_pos, "NORMAL": acc_norm, "TEXCOORD_0": acc_uv}
            if is_skinned_flag:
                attrs["JOINTS_0"] = acc_joints
                attrs["WEIGHTS_0"] = acc_weights
            primitives.append({
                "attributes": attrs,
                "indices": acc_idx,
                "material": mat_idx_map[mname],
                "mode": 4
            })

        mesh_idx = len(meshes)
        meshes.append({"name": obj_name, "primitives": primitives})

        if is_skinned_flag:
            # Create 4 Bone hierarchy nodes:
            # Bone_FlagRoot_Yardarm (0, 186.5, 92.0) -> Bone_FlagUpper (0, -7.5, 0) -> Bone_FlagMid (0, -8.0, 0) -> Bone_FlagFreeEdge (0, -8.0, 0)
            b0_idx = len(nodes)
            b1_idx = b0_idx + 1
            b2_idx = b0_idx + 2
            b3_idx = b0_idx + 3
            nodes.append({"name": "Bone_FlagRoot_Yardarm", "translation": [0.0, 186.5, 92.0], "children": [b1_idx]})
            nodes.append({"name": "Bone_FlagUpper",        "translation": [0.0, -7.5, 0.0],   "children": [b2_idx]})
            nodes.append({"name": "Bone_FlagMid",          "translation": [0.0, -8.0, 0.0],   "children": [b3_idx]})
            nodes.append({"name": "Bone_FlagFreeEdge",     "translation": [0.0, -8.0, 0.0]})
            root_scene_nodes.append(b0_idx)

            # 4x4 Column-Major Inverse Bind Matrices for world positions (0, 186.5, 92), (0, 179.0, 92), (0, 171.0, 92), (0, 163.0, 92)
            ibm_list = []
            for by in [186.5, 179.0, 171.0, 163.0]:
                mat = np.eye(4, dtype=np.float32)
                mat[0, 3] = 0.0
                mat[1, 3] = -by
                mat[2, 3] = -92.0
                ibm_list.append(mat.T.reshape(-1)) # column-major 16 floats
            ibm_arr = np.vstack(ibm_list).astype(np.float32)
            acc_ibm = add_accessor(ibm_arr, None, 5126, "MAT4", include_minmax=False)

            skin_idx = len(gltf_skins)
            gltf_skins.append({
                "name": "Armature_SkullFlag_WindRig",
                "inverseBindMatrices": acc_ibm,
                "skeleton": b0_idx,
                "joints": [b0_idx, b1_idx, b2_idx, b3_idx]
            })
            node_idx = len(nodes)
            nodes.append({"name": obj_name, "mesh": mesh_idx, "skin": skin_idx})
            root_scene_nodes.append(node_idx)
        else:
            node_idx = len(nodes)
            nodes.append({"name": obj_name, "mesh": mesh_idx})
            root_scene_nodes.append(node_idx)

    gltf_dict = {
        "asset": {"version": "2.0", "generator": "SphereBrawl_Battleship_Phase2_Production_Builder"},
        "scene": 0,
        "scenes": [{"name": os.path.splitext(os.path.basename(glb_path))[0], "nodes": root_scene_nodes}],
        "nodes": nodes, "meshes": meshes, "materials": gltf_materials,
        "images": gltf_images, "textures": gltf_textures, "samplers": gltf_samplers,
        "accessors": accessors, "bufferViews": buffer_views,
        "buffers": [{"byteLength": len(buffer_bytes)}]
    }
    if gltf_skins:
        gltf_dict["skins"] = gltf_skins

    json_bytes = json.dumps(gltf_dict, separators=(",", ":")).encode("utf-8")
    while len(json_bytes) % 4 != 0:
        json_bytes += b" "

    total_len = 12 + 8 + len(json_bytes) + 8 + len(buffer_bytes)
    with open(glb_path, "wb") as f:
        f.write(struct.pack("<III", 0x46546C67, 2, total_len))
        f.write(struct.pack("<II", len(json_bytes), 0x4E4F534A))
        f.write(json_bytes)
        f.write(struct.pack("<II", len(buffer_bytes), 0x004E4942))
        f.write(buffer_bytes)

def export_unit(subdir, unit_name, V, F, M, mat_list, skinned_flag=False):
    out_dir = os.path.join(MESH_ROOT, subdir)
    os.makedirs(out_dir, exist_ok=True)
    obj_path = os.path.join(out_dir, f"{unit_name}.obj")
    mtl_name = f"{unit_name}.mtl"
    mtl_path = os.path.join(out_dir, mtl_name)
    glb_path = os.path.join(out_dir, f"{unit_name}.glb")

    write_mtl_file(mtl_path, mat_list, tex_rel_prefix="../../textures/")
    write_obj_file(obj_path, mtl_name, unit_name, V, F, M, mat_list)
    write_glb_package(glb_path, [(unit_name, V, F, M, mat_list)], include_flag_skin_on=(unit_name if skinned_flag else None))
    return {
        "subdir": subdir,
        "name": unit_name,
        "vertices": int(len(V)),
        "triangles": int(len(F)),
        "bounds_min": V.min(axis=0).round(4).tolist(),
        "bounds_max": V.max(axis=0).round(4).tolist(),
        "materials": mat_list,
    }

def main():
    print("Building Map 02 Phase 2 Production meshes (< 18,000 triangles per MeshPart)...")
    hull_mb, deck_mb, well_mb = rev2.build_hull_and_decks()
    bow_mb = rev2.build_bow_bowsprit_and_figurehead()
    stern_mb, bridge_mb = rev2.build_sterncastle_and_bridge()
    mast_mb, sail_mb, rig_mb = rev2.build_masts_sails_and_rigging()
    flag_mb = rev2.build_curtain_skull_flag_mesh()
    broad_mb, main_turret_mb, sec_turret_mb = rev2.build_upgraded_weapons_and_broadside()
    equip_mb, rail_mb = rev2.build_railings_and_deck_equipment()
    ocean_mb, wake_mb = rev2.build_ocean_and_natural_wake()
    arena_mb = rev2.build_locked_arena_grid()

    production_units = {}
    master_scene_nodes = []

    # 1. HULL SPLITS: Split SHIP_Hull_CurvedHybrid (46,848 tris) into 4 clean non-overlapping sections (< 15,000 tris each!)
    #    - SHIP_Hull_Bow (Z < -84.0)
    #    - SHIP_Hull_MidshipPort (Z in [-84.0, +84.0], X <= 0.0)
    #    - SHIP_Hull_MidshipStarboard (Z in [-84.0, +84.0], X > 0.0)
    #    - SHIP_Hull_Stern (Z > +84.0)
    Vh, Fh, Mh, ml_h = hull_mb.finalize()
    (Vh_bow, Fh_bow, Mh_bow, ml_h_bow), (Vh_rem, Fh_rem, Mh_rem, ml_h_rem) = split_mesh_by_face_predicate(
        Vh, Fh, Mh, ml_h, lambda c: c[:, 2] < -84.0
    )
    (Vh_stern, Fh_stern, Mh_stern, ml_h_stern), (Vh_mid, Fh_mid, Mh_mid, ml_h_mid) = split_mesh_by_face_predicate(
        Vh_rem, Fh_rem, Mh_rem, ml_h_rem, lambda c: c[:, 2] > 84.0
    )
    (Vh_midP, Fh_midP, Mh_midP, ml_h_midP), (Vh_midS, Fh_midS, Mh_midS, ml_h_midS) = split_mesh_by_face_predicate(
        Vh_mid, Fh_mid, Mh_mid, ml_h_mid, lambda c: c[:, 0] <= 0.0
    )

    for uname, (Vu, Fu, Mu, mlu) in [
        ("SHIP_Hull_Bow", (Vh_bow, Fh_bow, Mh_bow, ml_h_bow)),
        ("SHIP_Hull_MidshipPort", (Vh_midP, Fh_midP, Mh_midP, ml_h_midP)),
        ("SHIP_Hull_MidshipStarboard", (Vh_midS, Fh_midS, Mh_midS, ml_h_midS)),
        ("SHIP_Hull_Stern", (Vh_stern, Fh_stern, Mh_stern, ml_h_stern)),
        ("SHIP_Bow_Bowsprit_And_Figurehead", bow_mb.finalize()),
    ]:
        info = export_unit("hull", uname, Vu, Fu, Mu, mlu)
        production_units[uname] = info
        master_scene_nodes.append((uname, Vu, Fu, Mu, mlu))

    # 2. DECK SPLITS: Split SHIP_Decks_And_Forecastle (18,512 tris) into Forward (Z <= 0) & Aft (Z > 0) (< 11,500 tris each!)
    Vd, Fd, Md, ml_d = deck_mb.finalize()
    (Vd_fwd, Fd_fwd, Md_fwd, ml_d_fwd), (Vd_aft, Fd_aft, Md_aft, ml_d_aft) = split_mesh_by_face_predicate(
        Vd, Fd, Md, ml_d, lambda c: c[:, 2] <= 0.0
    )
    for uname, (Vu, Fu, Mu, mlu) in [
        ("SHIP_Decks_ForwardAndForecastle", (Vd_fwd, Fd_fwd, Md_fwd, ml_d_fwd)),
        ("SHIP_Decks_AftAndWaist", (Vd_aft, Fd_aft, Md_aft, ml_d_aft)),
        ("SHIP_DeckEquipment_And_Boats", equip_mb.finalize()),
        ("SHIP_CurvedRailings_And_Ornaments", rail_mb.finalize()),
    ]:
        info = export_unit("deck", uname, Vu, Fu, Mu, mlu)
        production_units[uname] = info
        master_scene_nodes.append((uname, Vu, Fu, Mu, mlu))

    # 3. SUPERSTRUCTURE: Sterncastle & Command Bridge
    for uname, (Vu, Fu, Mu, mlu) in [
        ("SHIP_Sterncastle_And_Galleries", stern_mb.finalize()),
        ("SHIP_Integrated_CommandBridge", bridge_mb.finalize()),
    ]:
        info = export_unit("superstructure", uname, Vu, Fu, Mu, mlu)
        production_units[uname] = info
        master_scene_nodes.append((uname, Vu, Fu, Mu, mlu))

    # 4. TURRETS & BROADSIDE BATTERY SPLITS: Split SHIP_Broadside_Cannons_And_Ports (19,136 tris) into Port (X < 0) & Starboard (X >= 0) (9,568 tris each!)
    Vb, Fb, Mb, ml_b = broad_mb.finalize()
    (Vb_p, Fb_p, Mb_p, ml_b_p), (Vb_s, Fb_s, Mb_s, ml_b_s) = split_mesh_by_face_predicate(
        Vb, Fb, Mb, ml_b, lambda c: c[:, 0] < 0.0
    )
    for uname, (Vu, Fu, Mu, mlu) in [
        ("SHIP_Broadside_PortBattery", (Vb_p, Fb_p, Mb_p, ml_b_p)),
        ("SHIP_Broadside_StarboardBattery", (Vb_s, Fb_s, Mb_s, ml_b_s)),
    ]:
        info = export_unit("turrets", uname, Vu, Fu, Mu, mlu)
        production_units[uname] = info
        master_scene_nodes.append((uname, Vu, Fu, Mu, mlu))

    # Reusable Main Turret (4,230 tris) & Secondary Turret (598 tris)
    Vt, Ft, Mt, ml_t = main_turret_mb.finalize()
    production_units["SHIP_MainTurret_Triple16"] = export_unit("turrets", "SHIP_MainTurret_Triple16", Vt, Ft, Mt, ml_t)
    for iname, tx, ty, tz, ry in [
        ("SHIP_MainTurret_01_Forecastle", 0.0, 56.5, -196.0, 0.0),
        ("SHIP_MainTurret_02_Superfiring", 0.0, 58.0, -112.0, 0.0),
        ("SHIP_MainTurret_03_AftSterncastle", 0.0, 63.0, 165.0, 180.0),
    ]:
        master_scene_nodes.append((iname, transform_verts(Vt, tx, ty, tz, ry), Ft, Mt, ml_t))

    Vs, Fs, Ms, ml_s = sec_turret_mb.finalize()
    production_units["SHIP_SecondaryTurret_Dual5"] = export_unit("turrets", "SHIP_SecondaryTurret_Dual5", Vs, Fs, Ms, ml_s)
    sec_placements = [
        (-95.0, 50.0, -60.0, 90.0),  (-98.0, 49.5, -20.0, 90.0),
        (-98.0, 49.5,  20.0, 90.0),  (-95.0, 50.0,  60.0, 90.0),
        ( 95.0, 50.0, -60.0, -90.0), ( 98.0, 49.5, -20.0, -90.0),
        ( 98.0, 49.5,  20.0, -90.0), ( 95.0, 50.0,  60.0, -90.0),
    ]
    for idx, (tx, ty, tz, ry) in enumerate(sec_placements, 1):
        master_scene_nodes.append((f"SHIP_SecondaryBattery_{idx:02d}", transform_verts(Vs, tx, ty, tz, ry), Fs, Ms, ml_s))

    # 5. SAILS & RIGGING
    for uname, (Vu, Fu, Mu, mlu) in [
        ("SHIP_Masts_And_Spars", mast_mb.finalize()),
        ("SHIP_Sails_And_Banners", sail_mb.finalize()),
        ("SHIP_Standing_And_Running_Rigging", rig_mb.finalize()),
    ]:
        info = export_unit("sails_rigging", uname, Vu, Fu, Mu, mlu)
        production_units[uname] = info
        master_scene_nodes.append((uname, Vu, Fu, Mu, mlu))

    # 6. PIRATE SKULL FLAG (Static OBJ/MTL/GLB fallback + Skinned/Rigged 4-Bone GLB!)
    Vf, Ff, Mf, ml_f = flag_mb.finalize()
    production_units["SHIP_SkullFlag_Curtain"] = export_unit("pirate_flag", "SHIP_SkullFlag_Curtain", Vf, Ff, Mf, ml_f, skinned_flag=False)
    skinned_glb_path = os.path.join(MESH_ROOT, "pirate_flag", "SHIP_SkullFlag_Curtain_Skinned.glb")
    write_glb_package(skinned_glb_path, [("SHIP_SkullFlag_Curtain", Vf, Ff, Mf, ml_f)], include_flag_skin_on="SHIP_SkullFlag_Curtain")
    master_scene_nodes.append(("SHIP_SkullFlag_Curtain", Vf, Ff, Mf, ml_f))

    # 7. ARENA WELL & REFERENCE GRID
    for uname, (Vu, Fu, Mu, mlu) in [
        ("SHIP_ArenaWell_ArchedFrame", well_mb.finalize()),
        ("ARENA_Grid9x9_Reference", arena_mb.finalize()),
    ]:
        info = export_unit("arena_well", uname, Vu, Fu, Mu, mlu)
        production_units[uname] = info
        master_scene_nodes.append((uname, Vu, Fu, Mu, mlu))

    # 8. WAKE & OCEAN SURFACE SPLITS: Split OCEAN_Surface (28,800 tris) into Forward (Z <= 0, 14,400 tris) & Aft (Z > 0, 14,400 tris)
    Vo, Fo, Mo, ml_o = ocean_mb.finalize()
    (Vo_fwd, Fo_fwd, Mo_fwd, ml_o_fwd), (Vo_aft, Fo_aft, Mo_aft, ml_o_aft) = split_mesh_by_face_predicate(
        Vo, Fo, Mo, ml_o, lambda c: c[:, 2] <= 0.0
    )
    for uname, (Vu, Fu, Mu, mlu) in [
        ("OCEAN_Wake_BowAndHull", wake_mb.finalize()),
        ("OCEAN_Surface_Forward", (Vo_fwd, Fo_fwd, Mo_fwd, ml_o_fwd)),
        ("OCEAN_Surface_Aft", (Vo_aft, Fo_aft, Mo_aft, ml_o_aft)),
    ]:
        info = export_unit("wake", uname, Vu, Fu, Mu, mlu)
        production_units[uname] = info
        master_scene_nodes.append((uname, Vu, Fu, Mu, mlu))

    # 9. ASSEMBLED MASTER GLB (All 31 instantiated mesh nodes + 4-bone flag skin + all 8 embedded PNG textures!)
    master_glb_path = os.path.join(MESH_ROOT, "SM_ArenaEnvironment_Battleship_01_Master.glb")
    write_glb_package(master_glb_path, master_scene_nodes, include_flag_skin_on="SHIP_SkullFlag_Curtain")

    # Save scene cache & production metrics JSON
    os.makedirs(INTER_DIR, exist_ok=True)
    np.savez_compressed(os.path.join(INTER_DIR, "production_scene_cache.npz"), scene_objects=np.array(master_scene_nodes, dtype=object))

    max_unit_tris = max(u["triangles"] for u in production_units.values())
    assert max_unit_tris < 20000, f"Oversized MeshPart detected: {max_unit_tris} >= 20000!"

    u_ship_tris = sum(u["triangles"] for k, u in production_units.items() if k.startswith("SHIP_"))
    u_ship_verts = sum(u["vertices"] for k, u in production_units.items() if k.startswith("SHIP_"))
    u_ocean_tris = sum(u["triangles"] for k, u in production_units.items() if k.startswith("OCEAN_"))
    u_ocean_verts = sum(u["vertices"] for k, u in production_units.items() if k.startswith("OCEAN_"))
    u_arena_tris = production_units["ARENA_Grid9x9_Reference"]["triangles"]
    u_arena_verts = production_units["ARENA_Grid9x9_Reference"]["vertices"]

    i_ship_tris = sum(int(len(F)) for n, V, F, M, ml in master_scene_nodes if n.startswith("SHIP_"))
    i_ship_verts = sum(int(len(V)) for n, V, F, M, ml in master_scene_nodes if n.startswith("SHIP_"))
    i_ocean_tris = sum(int(len(F)) for n, V, F, M, ml in master_scene_nodes if n.startswith("OCEAN_"))
    i_ocean_verts = sum(int(len(V)) for n, V, F, M, ml in master_scene_nodes if n.startswith("OCEAN_"))

    summary_metrics = {
        "production_unit_count": len(production_units),
        "instantiated_node_count": len(master_scene_nodes),
        "max_meshpart_triangles": max_unit_tris,
        "roblox_meshpart_limit": 20000,
        "all_meshparts_under_20k": bool(max_unit_tris < 20000),
        "unique_ship_vertices": u_ship_verts,
        "unique_ship_triangles": u_ship_tris,
        "unique_ocean_vertices": u_ocean_verts,
        "unique_ocean_triangles": u_ocean_tris,
        "unique_environment_vertices_excl_arena": u_ship_verts + u_ocean_verts,
        "unique_environment_triangles_excl_arena": u_ship_tris + u_ocean_tris,
        "unique_arena_vertices": u_arena_verts,
        "unique_arena_triangles": u_arena_tris,
        "unique_total_vertices_incl_arena": u_ship_verts + u_ocean_verts + u_arena_verts,
        "unique_total_triangles_incl_arena": u_ship_tris + u_ocean_tris + u_arena_tris,
        "instantiated_ship_vertices": i_ship_verts,
        "instantiated_ship_triangles": i_ship_tris,
        "instantiated_ocean_vertices": i_ocean_verts,
        "instantiated_ocean_triangles": i_ocean_tris,
        "instantiated_environment_vertices_excl_arena": i_ship_verts + i_ocean_verts,
        "instantiated_environment_triangles_excl_arena": i_ship_tris + i_ocean_tris,
        "instantiated_arena_vertices": u_arena_verts,
        "instantiated_arena_triangles": u_arena_tris,
        "instantiated_total_vertices_incl_arena": i_ship_verts + i_ocean_verts + u_arena_verts,
        "instantiated_total_scene_triangles_incl_arena": i_ship_tris + i_ocean_tris + u_arena_tris,
        "production_units": production_units,
    }
    with open(os.path.join(INTER_DIR, "production_geometry_metrics.json"), "w", encoding="utf-8") as f:
        json.dump(summary_metrics, f, indent=2)

    print(json.dumps({k: v for k, v in summary_metrics.items() if k != "production_units"}, indent=2))

if __name__ == "__main__":
    main()
