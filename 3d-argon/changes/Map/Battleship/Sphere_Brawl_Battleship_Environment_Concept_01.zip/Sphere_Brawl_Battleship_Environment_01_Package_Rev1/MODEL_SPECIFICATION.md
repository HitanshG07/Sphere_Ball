# MODEL SPECIFICATION — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)

## 1. Production Component Hierarchy & Per-`MeshPart` Triangle Budgets

Every individual production mesh is strictly below the **20,000-triangle Roblox Studio `MeshPart` limit** (and within the **18,000-triangle working ceiling**, with the largest single `MeshPart` at **`17,592` triangles**):

| Category Folder | Production `MeshPart` Name | Unique Vertices | Unique Triangles | Scene Instances | Instantiated Triangles | World Bounds Min `(X, Y, Z)` | World Bounds Max `(X, Y, Z)` |
| :--- | :--- | ---: | ---: | ---: | ---: | :--- | :--- |
| `meshes/hull/` | `SHIP_Hull_Bow` | `10,157` | `14,536` | `1` | `14,536` | `(-109.166, -18.600, -240.000)` | `(109.166, 62.500, -84.000)` |
| `meshes/hull/` | `SHIP_Hull_MidshipPort` | `5,306` | `7,360` | `1` | `7,360` | `(-121.661, -18.000, -84.000)` | `(-85.200, 51.318, 84.000)` |
| `meshes/hull/` | `SHIP_Hull_MidshipStarboard` | `5,306` | `7,360` | `1` | `7,360` | `(85.200, -18.000, -84.000)` | `(121.661, 51.318, 84.000)` |
| `meshes/hull/` | `SHIP_Hull_Stern` | `12,262` | `17,592` | `1` | `17,592` | `(-116.519, -18.600, 84.000)` | `(116.519, 72.500, 240.000)` |
| `meshes/hull/` | `SHIP_Bow_Bowsprit_And_Figurehead` | `6,013` | `8,430` | `1` | `8,430` | `(-22.286, 15.166, -302.205)` | `(22.286, 86.606, -207.750)` |
| `meshes/deck/` | `SHIP_Decks_ForwardAndForecastle` | `5,860` | `10,640` | `1` | `10,640` | `(-109.386, 46.100, -238.000)` | `(109.386, 60.869, 0.000)` |
| `meshes/deck/` | `SHIP_Decks_AftAndWaist` | `4,250` | `7,872` | `1` | `7,872` | `(-108.938, 46.100, 0.000)` | `(108.938, 71.804, 238.000)` |
| `meshes/deck/` | `SHIP_DeckEquipment_And_Boats` | `4,152` | `3,648` | `1` | `3,648` | `(-105.786, 48.295, -152.400)` | `(105.786, 56.787, 126.400)` |
| `meshes/deck/` | `SHIP_CurvedRailings_And_Ornaments` | `8,736` | `8,736` | `1` | `8,736` | `(-109.595, 49.101, -236.280)` | `(109.595, 75.126, 236.117)` |
| `meshes/superstructure/`| `SHIP_Sterncastle_And_Galleries` | `10,959` | `15,924` | `1` | `15,924` | `(-85.439, 47.010, 88.000)` | `(85.439, 96.700, 254.000)` |
| `meshes/superstructure/`| `SHIP_Integrated_CommandBridge` | `5,170` | `6,104` | `1` | `6,104` | `(-44.000, 62.000, 86.900)` | `(44.000, 116.827, 156.083)` |
| `meshes/turrets/` | `SHIP_Broadside_PortBattery` | `8,050` | `9,568` | `1` | `9,568` | `(-120.856, 16.692, -156.710)` | `(-89.314, 36.821, 156.710)` |
| `meshes/turrets/` | `SHIP_Broadside_StarboardBattery` | `8,050` | `9,568` | `1` | `9,568` | `(89.314, 16.692, -156.710)` | `(120.856, 36.821, 156.710)` |
| `meshes/turrets/` | `SHIP_MainTurret_Triple16` | `3,099` | `4,230` | `3` | `12,690` | Local: `(-18.264, -5.0, -37.263)` | Local: `(18.264, 15.275, 14.800)`|
| `meshes/turrets/` | `SHIP_SecondaryTurret_Dual5` | `450` | `598` | `8` | `4,784` | Local: `(-5.444, -2.0, -13.076)` | Local: `(5.444, 9.000, 5.500)` |
| `meshes/sails_rigging/` | `SHIP_Masts_And_Spars` | `4,665` | `7,596` | `1` | `7,596` | `(-95.868, 49.263, -146.450)` | `(95.868, 172.000, 246.016)` |
| `meshes/sails_rigging/` | `SHIP_Sails_And_Banners` | `8,500` | `14,356` | `1` | `14,356` | `(-46.000, 62.000, -300.000)` | `(46.000, 173.500, 244.000)` |
| `meshes/sails_rigging/` | `SHIP_Standing_And_Running_Rigging` | `4,056` | `6,412` | `1` | `6,412` | `(-96.250, 51.586, -300.093)` | `(96.250, 172.147, 248.190)` |
| `meshes/pirate_flag/` | `SHIP_SkullFlag_Curtain` (+`Skinned`) | `10,002` | `7,224` | `1` | `7,224` | `(-24.054, 161.898, 88.927)` | `(24.037, 188.500, 96.450)` |
| `meshes/arena_well/` | `SHIP_ArenaWell_ArchedFrame` | `10,620` | `13,648` | `1` | `13,648` | `(-92.200, 32.750, -92.200)` | `(92.200, 61.500, 92.200)` |
| `meshes/wake/` | `OCEAN_Wake_BowAndHull` | `14,892` | `10,080` | `1` | `10,080` | `(-161.103, 0.030, -246.000)` | `(161.103, 1.714, 410.000)` |
| `meshes/wake/` | `OCEAN_Surface_Forward` | `7,381` | `14,400` | `1` | `14,400` | `(-800.000, -1.976, -800.000)` | `(800.000, 1.974, 0.000)` |
| `meshes/wake/` | `OCEAN_Surface_Aft` | `7,381` | `14,400` | `1` | `14,400` | `(-800.000, -1.974, 0.000)` | `(800.000, 1.974, 800.000)` |
| **Subtotal Environment**| **23 Production Environment Units** | **`165,317`**| **`220,282`**| **`32` nodes**| **`232,928`** | **Max Single Unit: `17,592` Tris**| **`< 20,000` Limit (`PASS`)** |
| `meshes/arena_well/` | `ARENA_Grid9x9_Reference` (`81` tiles)| `20,736` | `14,256` | `1` | `14,256` | `(-53.900, 49.000, -53.900)` | `(53.900, 51.055, 53.900)` |
| **Total Master Scene** | **24 Production Units (+Skinned Flag)**| **`186,053`**| **`234,538`**| **`33` nodes**| **`247,184`** | **All 33 Nodes `< 18,000` Tris** | **100% Import-Safe** |

## 2. Reusable Turret Instance Placement Transforms

All 21 non-turret environment modules are exported in world coordinates with their pivot at `(0.0, 0.0, 0.0)`. The two reusable turret modules (`SHIP_MainTurret_Triple16` and `SHIP_SecondaryTurret_Dual5`) are exported centered at their local origin `(0, 0, 0)` and instantiated in `SM_ArenaEnvironment_Battleship_01_Master.glb` at the following exact world `CFrame` transforms:

| Instance Node Name | Module Archetype | World Position `(X, Y, Z)` | Yaw Rotation `RY` (Deg) | Roblox Studio `CFrame` Expression |
| :--- | :--- | :--- | ---: | :--- |
| `SHIP_MainTurret_01_Forecastle` | `SHIP_MainTurret_Triple16` | `(0.0, 56.5, -196.0)` | `0.0°` | `CFrame.new(0, 56.5, -196)` |
| `SHIP_MainTurret_02_Superfiring` | `SHIP_MainTurret_Triple16` | `(0.0, 58.0, -112.0)` | `0.0°` | `CFrame.new(0, 58.0, -112)` |
| `SHIP_MainTurret_03_AftSterncastle`| `SHIP_MainTurret_Triple16` | `(0.0, 63.0, 165.0)` | `180.0°` | `CFrame.new(0, 63.0, 165) * CFrame.Angles(0, math.pi, 0)` |
| `SHIP_SecondaryBattery_01..04` (Port)| `SHIP_SecondaryTurret_Dual5`| `(-95..-98, 49.5..50, ±20, ±60)`| `+90.0°` | `CFrame.new(x, y, z) * CFrame.Angles(0, math.rad(90), 0)` |
| `SHIP_SecondaryBattery_05..08` (Stbd)| `SHIP_SecondaryTurret_Dual5`| `(+95..+98, 49.5..50, ±20, ±60)`| `-90.0°` | `CFrame.new(x, y, z) * CFrame.Angles(0, math.rad(-90), 0)` |

## 3. 4-Bone Skinned Skull Flag Rig (`SHIP_SkullFlag_Curtain_Skinned.glb`)

- **Armature / Skin Name:** `Armature_SkullFlag_WindRig`
- **Bone Hierarchy (`4` `Bone` nodes):**
  1. `Bone_FlagRoot_Yardarm` — World Bind Position: `(0.0, 186.5, 92.0)` (Root bone attached to the signal yardarm; `Transform` remains `CFrame.identity` so the top edge and rope grommet ties never detach).
  2. `Bone_FlagUpper` — Child of `Bone_FlagRoot_Yardarm`, Local Translation: `(0.0, -7.5, 0.0)` (`World Y = 179.0`).
  3. `Bone_FlagMid` — Child of `Bone_FlagUpper`, Local Translation: `(0.0, -8.0, 0.0)` (`World Y = 171.0`).
  4. `Bone_FlagFreeEdge` — Child of `Bone_FlagMid`, Local Translation: `(0.0, -8.0, 0.0)` (`World Y = 163.0`, bottom free edge with strongest wind flutter).
- **Skinning Attributes:** `JOINTS_0` (`UNSIGNED_SHORT` `VEC4`) and `WEIGHTS_0` (`FLOAT` `VEC4`, normalized so $\sum_{k=1}^4 w_k = 1.000000$ on all `10,002` vertices) + `inverseBindMatrices` (`4 × MAT4`).

## 4. Production Texture Atlases (`textures/`)

All 8 textures are `1024 × 1024` PNGs (`<= 1024×1024` cap) and are embedded directly inside the `.glb` files and linked via relative `../../textures/` paths in all `.mtl` files:
1. `T_Pirate_TimberAndBronze_Albedo_1024.png` (`505,301 B`)
2. `T_Pirate_TimberAndBronze_Normal_1024.png` (`1,843,170 B`)
3. `T_Pirate_TimberAndBronze_Roughness_1024.png` (`547,593 B`)
4. `T_Pirate_SkullFlag_Albedo_1024.png` (`117,402 B`)
5. `T_Pirate_SailsAndRope_Albedo_1024.png` (`161,366 B`)
6. `T_Naval_SteelAndArmor_Albedo_1024.png` (`721,220 B`)
7. `T_Ocean_MultiSwellAndFoam_Albedo_1024.png` (`290,652 B`)
8. `T_ArenaGrid_TileStates_Atlas_1024.png` (`5,150 B`)
