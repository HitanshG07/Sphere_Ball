#!/usr/bin/env python3
"""
Portable GLB Material, Embedded Texture & Skinned Flag Validator (`scripts/validate_glb_materials.py`)
Project: Sphere Brawl: Rolling Rampage — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)

Validates all 26 binary `.glb` files in the production package:
- 24 individual component `.glb` files across `meshes/<category>/<Unit>.glb`
- 1 skinned 4-bone flag `.glb` (`meshes/pirate_flag/SHIP_SkullFlag_Curtain_Skinned.glb`)
- 1 assembled Master scene `.glb` (`meshes/SM_ArenaEnvironment_Battleship_01_Master.glb`)
Verifies:
- Every GLB mesh node is strictly < 20,000 triangles
- Every primitive has `POSITION`, `NORMAL`, and `TEXCOORD_0`
- Every material's `baseColorTexture` (and `normalTexture` where used) resolves to an embedded `image/png`
  bufferView with a valid `\x89PNG\r\n\x1a\n` signature and zero external URI dependencies
- `SHIP_SkullFlag_Curtain_Skinned.glb` and `SM_ArenaEnvironment_Battleship_01_Master.glb` contain
  the 4-bone skeletal rig (`Bone_FlagRoot_Yardarm`, `Bone_FlagUpper`, `Bone_FlagMid`, `Bone_FlagFreeEdge`),
  `skins`, `inverseBindMatrices`, `JOINTS_0`, and normalized `WEIGHTS_0` (`sum == 1.0`).
"""
import os
import sys
import json
import struct
import argparse
from pathlib import Path
import numpy as np

from validate_meshes import PRODUCTION_UNITS

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
REQUIRED_FLAG_BONES = ["Bone_FlagRoot_Yardarm", "Bone_FlagUpper", "Bone_FlagMid", "Bone_FlagFreeEdge"]

def inspect_glb(glb_path, expect_skin=False):
    with open(glb_path, "rb") as f:
        magic, version, total_len = struct.unpack("<III", f.read(12))
        assert magic == 0x46546C67 and version == 2, f"Invalid GLB header: {glb_path}"
        j_len, j_type = struct.unpack("<II", f.read(8))
        gltf = json.loads(f.read(j_len).decode("utf-8"))
        b_len, b_type = struct.unpack("<II", f.read(8))
        bin_data = f.read(b_len)

    bvs = gltf.get("bufferViews", [])
    accs = gltf.get("accessors", [])
    images = gltf.get("images", [])
    textures = gltf.get("textures", [])
    materials = gltf.get("materials", [])
    meshes = gltf.get("meshes", [])
    nodes = gltf.get("nodes", [])
    skins = gltf.get("skins", [])

    # 1. Verify all images are embedded PNGs in bufferViews (no external URIs)
    valid_pngs = 0
    for img in images:
        if "uri" in img:
            return {"valid": False, "reason": f"External image URI found: {img['uri']}"}
        bv = bvs[img["bufferView"]]
        raw = bin_data[bv.get("byteOffset", 0) : bv.get("byteOffset", 0) + bv["byteLength"]]
        if raw.startswith(PNG_MAGIC) and len(raw) == bv["byteLength"]:
            valid_pngs += 1

    if valid_pngs != len(images) or len(images) == 0:
        return {"valid": False, "reason": f"Invalid embedded PNG count: {valid_pngs}/{len(images)}"}

    # 2. Verify all materials resolve their baseColorTexture
    for mat in materials:
        pbr = mat.get("pbrMetallicRoughness", {})
        if "baseColorTexture" not in pbr:
            return {"valid": False, "reason": f"Material {mat.get('name')} missing baseColorTexture"}
        t_idx = pbr["baseColorTexture"]["index"]
        if not (0 <= t_idx < len(textures)):
            return {"valid": False, "reason": f"Invalid texture index {t_idx}"}

    # 3. Verify every mesh node is < 20,000 triangles and has POSITION, NORMAL, TEXCOORD_0
    max_mesh_tris = 0
    total_glb_tris = 0
    has_skinned_prim = False
    for m in meshes:
        m_tris = 0
        for prim in m["primitives"]:
            attrs = prim["attributes"]
            for req_a in ("POSITION", "NORMAL", "TEXCOORD_0"):
                if req_a not in attrs:
                    return {"valid": False, "reason": f"Mesh {m['name']} missing {req_a}"}
            if "JOINTS_0" in attrs and "WEIGHTS_0" in attrs:
                has_skinned_prim = True
            idx_acc = accs[prim["indices"]]
            n_tris = idx_acc["count"] // 3
            m_tris += n_tris
            total_glb_tris += n_tris
        if m_tris >= 20000:
            return {"valid": False, "reason": f"Mesh {m['name']} exceeds 20k limit ({m_tris} tris)"}
        max_mesh_tris = max(max_mesh_tris, m_tris)

    # 4. If expect_skin is True, verify the 4-bone flag rig and skin
    if expect_skin:
        if len(skins) == 0 or not has_skinned_prim:
            return {"valid": False, "reason": "Expected 4-bone skin and JOINTS_0/WEIGHTS_0 not found"}
        node_names = {n.get("name") for n in nodes}
        for bname in REQUIRED_FLAG_BONES:
            if bname not in node_names:
                return {"valid": False, "reason": f"Missing required flag bone node: {bname}"}

    return {
        "valid": True,
        "mesh_node_count": len(meshes),
        "max_mesh_triangles": max_mesh_tris,
        "total_triangles": total_glb_tris,
        "material_count": len(materials),
        "embedded_png_count": valid_pngs,
        "has_4bone_flag_skin": bool(len(skins) > 0 and has_skinned_prim),
    }

def validate_all_glbs(pkg_root):
    mesh_root = os.path.join(pkg_root, "meshes")
    glb_reports = {}
    all_ok = True

    for subdir, uname in PRODUCTION_UNITS:
        gp = os.path.join(mesh_root, subdir, f"{uname}.glb")
        res = inspect_glb(gp, expect_skin=False)
        glb_reports[f"{subdir}/{uname}.glb"] = res
        if not res["valid"]:
            all_ok = False

    skin_gp = os.path.join(mesh_root, "pirate_flag", "SHIP_SkullFlag_Curtain_Skinned.glb")
    res_skin = inspect_glb(skin_gp, expect_skin=True)
    glb_reports["pirate_flag/SHIP_SkullFlag_Curtain_Skinned.glb"] = res_skin
    if not res_skin["valid"]:
        all_ok = False

    master_gp = os.path.join(mesh_root, "SM_ArenaEnvironment_Battleship_01_Master.glb")
    res_master = inspect_glb(master_gp, expect_skin=True)
    glb_reports["SM_ArenaEnvironment_Battleship_01_Master.glb"] = res_master
    if not res_master["valid"]:
        all_ok = False

    return {
        "status": "PASS" if all_ok else "FAIL",
        "validated_glb_count": len(glb_reports),
        "master_glb_summary": res_master,
        "skinned_flag_glb_summary": res_skin,
        "glbs": glb_reports,
    }

def main():
    parser = argparse.ArgumentParser(description="Validate all 26 production GLB files and embedded textures")
    default_pkg = str(Path(__file__).resolve().parent.parent)
    parser.add_argument("--package-dir", default=default_pkg)
    args = parser.parse_args()
    summary = validate_all_glbs(args.package_dir)
    print(json.dumps({k: v for k, v in summary.items() if k != "glbs"}, indent=2))
    if summary["status"] != "PASS":
        sys.exit(1)

if __name__ == "__main__":
    main()
