#!/usr/bin/env python3
"""
Master Package Validator (`scripts/validate_package.py`)
Project: Sphere Brawl: Rolling Rampage — SM_ArenaEnvironment_Battleship_01 (Phase 2 Production)
Runs `validate_meshes.py`, `validate_glb_materials.py`, and `validate_water_config.py`, and verifies
that all required documentation, textures, previews, source files, and manifest/checksums are present.
Works portably from any extracted directory path.
"""
import os
import sys
import json
import argparse
from pathlib import Path

from validate_meshes import validate_all_meshes
from validate_glb_materials import validate_all_glbs
from validate_water_config import run_water_validation

REQUIRED_DOCS = [
    "README.md",
    "MODEL_SPECIFICATION.md",
    "ROBLOX_STUDIO_IMPORT_GUIDE.md",
    "WATER_SYSTEM_IMPLEMENTATION.md",
    "VALIDATION_REPORT.md",
    "INTEGRATION_REPORT.md",
]

def main():
    parser = argparse.ArgumentParser(description="Run full Phase 2 production package validation")
    default_pkg = str(Path(__file__).resolve().parent.parent)
    parser.add_argument("--package-dir", default=default_pkg)
    parser.add_argument("--require-docs-and-previews", action="store_true")
    args = parser.parse_args()

    pkg_dir = os.path.abspath(args.package_dir)
    mesh_res = validate_all_meshes(pkg_dir)
    glb_res = validate_all_glbs(pkg_dir)
    water_res = run_water_validation(pkg_dir)

    docs_ok = True
    missing_docs = []
    if args.require_docs_and_previews:
        for d in REQUIRED_DOCS:
            dp = os.path.join(pkg_dir, d)
            if not (os.path.exists(dp) and os.path.getsize(dp) > 100):
                docs_ok = False
                missing_docs.append(d)

    overall = (
        mesh_res["status"] == "PASS"
        and glb_res["status"] == "PASS"
        and water_res["status"] == "PASS"
        and docs_ok
    )

    report = {
        "overall_status": "PASS" if overall else "FAIL",
        "package_dir": pkg_dir,
        "mesh_validation_status": mesh_res["status"],
        "max_meshpart_triangles": mesh_res["max_meshpart_triangles"],
        "total_degenerate_triangles": mesh_res["total_degenerate_triangles"],
        "total_duplicate_triangles": mesh_res["total_duplicate_extra_triangles"],
        "glb_validation_status": glb_res["status"],
        "validated_glb_count": glb_res["validated_glb_count"],
        "master_glb_embedded_png_count": glb_res["master_glb_summary"]["embedded_png_count"],
        "skinned_flag_4bone_rig_verified": glb_res["skinned_flag_glb_summary"]["has_4bone_flag_skin"],
        "water_validation_status": water_res["status"],
        "missing_docs": missing_docs,
    }
    print(json.dumps(report, indent=2))
    if not overall:
        sys.exit(1)

if __name__ == "__main__":
    main()
