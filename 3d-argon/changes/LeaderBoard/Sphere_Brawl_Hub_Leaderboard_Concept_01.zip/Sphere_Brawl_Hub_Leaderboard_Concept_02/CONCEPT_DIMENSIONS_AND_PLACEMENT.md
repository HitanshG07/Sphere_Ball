# Revised Concept Dimensions, Orientation & Recalculated Clearance Report — `SM_Hub_Leaderboard_01` (`Concept 02`)

- **Canonical Asset ID:** `SM_Hub_Leaderboard_01`
- **Deliverable Stage:** Step 6, Phase 1 Revision — Wide Multi-Leaderboard Array (`CONCEPT ONLY — NOT FINAL PRODUCTION MESH`)
- **Authoritative World Center (`LOCKED`):** **`(35.0000, 150.0000, -274.0000)`** (`MASTER_IMPLEMENTATION_PLAN.md` §2.4 & `tasks/TASK-03-KINETIC-HUB-ENVIRONMENT.md`)
- **Authoritative Hub Center (`LOCKED`):** **`(0.0000, 150.0000, -300.0000)`**
- **Authoritative Walking Surface (`LOCKED`):** **`World Y = 150.0000`** (`Local Y = 0.0000`)

## 1. Proposed Overall Envelope & Per-Panel Dimensions (`Concept 02` vs. `Concept 01`)

| Dimensional Parameter | Superseded `Concept 01` (Single Pylon) | Revised `Concept 02` (Wide 3-Board Array) | Status | Notes / Verification |
|---|---|---|---|---|
| **Overall Station Width (`Local X`)** | `6.5000 studs` (`[-3.25, +3.25]`) | **`24.0000 studs`** (`[-12.0000, +12.0000]`) | **PROPOSED** | **`3.69×` wider**; extends tangentially along `Local X` |
| **Overall Station Height (`Local Y`)** | `16.0000 studs` (`[0.00, +16.00]`) | **`10.5000 studs`** (`[0.0000, +10.5000]`) | **PROPOSED** | Center crown `10.50 studs`; wing canopies `9.82 studs` (`34.4%` shorter) |
| **Overall Station Depth (`Local Z`)** | `4.5000 studs` (`[-2.25, +2.25]`) | **`4.5000 studs`** (`[-2.2500, +2.2500]`) | **PROPOSED** | Unchanged compact radial depth |
| **Number of Display Modules** | `1` narrow portrait board | **`3` distinct landscape/balanced boards** | **REQUIRED** | Display A (`KOs`), Display B (`WINS`), Display C (`STANDINGS`) |
| **Outer Module Width (Each)** | `6.5000 studs` (entire station) | **`7.2000 studs` each** (`3 × 7.20 = 21.60 studs`) | **PROPOSED** | Each individual module is **`+0.70 studs` wider** than the old entire pylon |
| **Structural Pier Width & Spacing** | N/A | **`4` piers × `0.6000 studs` width** (`2.40 studs` total) | **PROPOSED** | `[-12.0,-11.4]`, `[-4.2,-3.6]`, `[+3.6,+4.2]`, `[+11.4,+12.0]` (`21.60 + 2.40 = 24.00`) |
| **Visible UI Surface Width (Each)** | `3.9600 studs` (`1` surface) | **`6.4000 studs` each** (`19.20 studs` total UI width) | **PROPOSED** | **`+61.6%` wider** per panel than Concept 01 (`4.85×` total UI width) |
| **Main UI Surface Height (Each)** | `9.4400 studs` | **`5.3000 studs` (A & C)** / **`5.6000 studs` (B)** | **PROPOSED** | `Local Y in [2.15, 7.45]` (A & C) and `[2.15, 7.75]` (B) |
| **Header UI Surface Height (Each)** | `1.3800 studs` | **`1.2000 studs` (A & C)** / **`1.2400 studs` (B)** | **PROPOSED** | `Local Y in [7.62, 8.82]` (A & C) and `[7.92, 9.16]` (B) |
| **Display Plane Orientation & Tilt** | `0°` vertical (`+Z` normal) | **`0°` vertical (`Local +Z` normal)** | **PROPOSED** | `Local Z = +1.0200` (A & C) and `+1.1400` (B hero step) |
| **Concept Blockout Triangles** | `1,130 triangles` (`17` comps) | **`1,886 triangles`** (`25` named components) | **MEASURED** | Strictly below the `< 2,000-triangle` Leaderboard budget |

### Per-Module Coordinate Table (Local Space, `1 Blender Unit = 1 Roblox Stud`)
| Module & Theme | Outer Housing `Local X` | Visible UI `Local X` | Header UI `Local Y` | Main Table UI `Local Y` | UI Plane `Local Z` | Replaceable Component Names |
|---|---|---|---|---|---|---|
| **Display A — `SESSION KOs` (`EMI_Cyan` `#00C3FF`)** | `[-11.4000, -4.2000]` (`7.20 W`) | `[-11.0000, -4.6000]` (`6.40 W`) | `[7.6200, 8.8200]` (`1.20 H`) | `[2.1500, 7.4500]` (`5.30 H`) | `+1.0200` | `GEO_Leaderboard_UIHeader_A_SessionKOs`, `GEO_Leaderboard_UIMain_A_SessionKOs` |
| **Display B — `SESSION WINS` (`EMI_Amber` `#FFAA00`)** | `[-3.6000, +3.6000]` (`7.20 W`) | `[-3.2000, +3.2000]` (`6.40 W`) | `[7.9200, 9.1600]` (`1.24 H`) | `[2.1500, 7.7500]` (`5.60 H`) | `+1.1400` | `GEO_Leaderboard_UIHeader_B_SessionWins`, `GEO_Leaderboard_UIMain_B_SessionWins` |
| **Display C — `SESSION STANDINGS` (`EMI_Magnetic` `#A537FF`)** | `[+4.2000, +11.4000]` (`7.20 W`) | `[+4.6000, +11.0000]` (`6.40 W`) | `[7.6200, 8.8200]` (`1.20 H`) | `[2.1500, 7.4500]` (`5.30 H`) | `+1.0200` | `GEO_Leaderboard_UIHeader_C_SessionStandings`, `GEO_Leaderboard_UIMain_C_SessionStandings` |

## 2. Local Coordinate Convention, Locked Anchor & Verified Orientation Transform

- **Local Pivot `(0.0000, 0.0000, 0.0000)`:** Bottom-center floor reference of the `24.00 × 4.50 stud` base plinth (`Local Y = 0.0000` rests flush on `World Y = 150.0000`).
- **Local Axes:** `Local +Y` = Up (`[0.0, +10.5]`), `Local +Z` = Front/Display-facing (`[-2.25, +2.25]`), `Local +X` = Right across the 3-display array (`[-12.0, +12.0]`, tangential to the Hub radius).
- **Horizontal Vector from `(35, 150, -274)` to Hub Center `(0, 150, -300)` (`CALCULATED`):**
  ```text
  ΔV = (0 - 35, 150 - 150, -300 - (-274)) = (-35.0000, 0.0000, -26.0000)
  ||ΔV|| = sqrt(1225 + 676) = sqrt(1901) = 43.60045871 studs
  N_front = (-35 / sqrt(1901), 0, -26 / sqrt(1901)) = (-0.80274385, 0.00000000, -0.59632400)
  ```
- **Starting Yaw Around World `Y` (`CALCULATED / PROPOSED`):**
  ```text
  θ_yaw = atan2(-35.0, -26.0) = -2.20971031 radians = -126.60707939°
  ```
- **Proposed Roblox Placement Transform:**
  ```luau
  local targetCFrame =
      CFrame.new(35, 150, -274)
      * CFrame.Angles(0, math.rad(-126.60707939), 0)
  ```
- **Orthonormal Basis Vectors (`RightVector`, `UpVector`, `ZVector`):**
  - `RightVector (Local +X, Tangential Array Axis)` = `(-0.59632400, 0.00000000, +0.80274385)`
  - `UpVector (Local +Y, Vertical)` = `(0.00000000, +1.00000000, 0.00000000)`
  - `ZVector (Local +Z, Inward Front Normal)` = `(-0.80274385, 0.00000000, -0.59632400)`

## 3. Recalculated World Bounds & Radial Band Fit for the `24.0 × 10.5 × 4.5` Array

### 3.1 Exact Oriented Bounding Box (OBB) Base Corners & Midpoints (`CALCULATED`)
| Reference Point on `24.0 × 4.5` Footprint | Local `(x, y, z)` | Transformed World `(X, Y, Z)` | Radial Distance `R_xz` from Hub Center `(0, 150, -300)` |
|---|---|---|---|
| **Front-Left Corner (Display A / Shop Bar Side)** | `(-12.0000, 0.0000, +2.2500)` | **`(40.3497, 150.0000, -284.9747)`** | `43.0565 studs` |
| **Front-Center Midpoint (Display B Step)** | `(0.0000, 0.0000, +2.2500)` | **`(33.1938, 150.0000, -275.3417)`** | **`41.3505 studs` (`R_min`)** |
| **Front-Right Corner (Display C / North Side)** | `(+12.0000, 0.0000, +2.2500)` | **`(26.0379, 150.0000, -265.7088)`** | `43.0565 studs` |
| **Rear-Left Corner (Display A Rear)** | `(-12.0000, 0.0000, -2.2500)` | **`(43.9621, 150.0000, -282.2912)`** | **`47.3948 studs` (`R_max`)** |
| **Rear-Center Midpoint (Display B Rear)** | `(0.0000, 0.0000, -2.2500)` | **`(36.8062, 150.0000, -272.6583)`** | `45.8505 studs` |
| **Rear-Right Corner (Display C Rear)** | `(+12.0000, 0.0000, -2.2500)` | **`(29.6503, 150.0000, -263.0253)`** | **`47.3948 studs` (`R_max`)** |

### 3.2 Analytical OBB World AABB vs. Measured Concept 02 Vertex World AABB
| World Metric | Analytical Unchamfered OBB (`24.0 × 10.5 × 4.5` — `CALCULATED`) | Concept 02 Blockout Mesh (`5,658` Vertices, `0.55` Plinth Chamfer — `MEASURED`) |
|---|---|---|
| **`World X` Range** | **`[26.0379, 43.9621]`** (`17.9241 studs` span) | **`[26.3659, 43.8701]`** (`17.5042 studs` span) |
| **`World Y` Range** | **`[150.0000, 160.5000]`** (`10.5000 studs` span) | **`[150.0000, 160.5000]`** (`10.5000 studs` span) |
| **`World Z` Range** | **`[-284.9747, -263.0253]`** (`21.9493 studs` span) | **`[-284.6467, -263.1153]`** (`21.5314 studs` span) |
| **Radial Span `R_xz` from `(0, 150, -300)`** | **`[41.3505, 47.3948] studs`** (`6.0443-stud` radial thickness) | **`[41.4789, 47.3119] studs`** (`5.8330-stud` radial thickness) |
| **Fit Inside `R = [37.00, 52.50]` Station Band** | **`100% INSIDE`** (`+4.3505` inner margin / `+5.1052` outer margin) | **`100% INSIDE`** (`+4.4789` inner margin / `+5.1881` outer margin) |
| **Clearance to `R = 63.20` Plaza Outer Curb** | **`15.8052 studs`** (`63.2000 - 47.3948`) | **`15.8881 studs`** (`63.2000 - 47.3119`) |

## 4. Recalculated Clearances to Neighbouring Stations & Circulation Routes

| Neighbouring Station / Feature | Authoritative World Bounds | Label | Center-to-Center | Recalculated OBB Clearance (`CALCULATED`) | Recalculated Mesh Vertex Clearance (`MEASURED`) | Spatial & Circulation Evaluation |
|---|---|---|---|---|---|---|
| **`SM_Hub_ShopKiosk_01` (Shop Bar)** | Anchor `(43, 150, -300)`; bounds `X [39.0000, 47.0000]`, `Y [150.0, 157.6]`, `Z [-310.0000, -290.0000]` | **MEASURED** | `27.2029 studs` | **`5.0253 studs` 2D & Z-gap** (from Front-Left OBB corner `(40.3497, -284.9747)` to Shop north edge `Z = -290.0`) | **`5.5231 studs` 2D Euclidean** / **`5.3533 studs` Z-gap** (with `0.55-stud` plinth corner chamfer) | **PASS WITH DOCUMENTED PINCH POINT** — See detailed walkway analysis in §5 below. |
| **`SM_Hub_ModeBoard_01` (Mode Board)** | Anchor `(35, 150, -326)`; bounds `X [29.3702, 40.6298]`, `Y [150.0, 158.8]`, `Z [-332.6738, -319.3320]` | **MEASURED** | `52.0000 studs` | **`34.3573 studs` Z-gap** (`-284.9747 - (-319.3320)`) | **`34.8108 studs` 2D Euclidean** / **`34.6853 studs` Z-gap** | **PASS** — Over `34.3 studs` of open separation across the East sector. |
| **`SM_Hub_QueuePadRing_01` (Queue Pad)** | Anchor `(0, 150, -300)`; outer radius `R_outer = 14.0000 studs` | **MEASURED** | `43.6005 studs` | **`27.3505 studs` radial gap** (`41.3505 - 14.0000`) | **`27.4789 studs` radial gap** (`41.4789 - 14.0000`) | **PASS** — Radial depth was not increased (`4.50 studs`), preserving the full `27.35-stud` radial plaza buffer. |
| **`SM_Hub_QueuePortalArch_01` (Portal Arch)** | Anchor `(0, 150, -300)`; East Pylon `X [+15.05, +20.40]`, `Z [-304.80, -295.20]` | **MEASURED** | `43.6005 studs` | **`23.9966 studs` 2D Euclidean** | **`23.9967 studs` 2D Euclidean** | **PASS** — Completely clear of the Queue Portal Arch. |
| **Main Spawn-to-Portal Sightline** | Spawn `(0, 150, -334)` looking `+Z` to `(0, 150, -300)` (`D-015`) | **CALCULATED** | `69.4622 studs` | **`26.0379 studs` lateral X-clearance** (`X_min = 26.0379` vs. `X = 0`) | **`26.3659 studs` lateral X-clearance** | **PASS** — Sits `> 26 studs` East and North of the spawn-to-portal axis. |
| **`SM_Hub_CustomizeKiosk_01` (Customize)** | Anchor `(-43, 150, -300)`; bounds `X [-47.0, -39.0]`, `Z [-305.0, -295.0]` | **MEASURED** | `82.2192 studs` | **`71.5450 studs` 2D Euclidean** (`65.0379 studs` X-gap) | **`71.8746 studs` 2D Euclidean** | **PASS** — Opposite West side of the Hub. |
| **Optional Reward Display** | Anchor `(-38, 150, -326)` (`MASTER_IMPLEMENTATION_PLAN.md` §2.4) | **UNVERIFIED (Bounds)** | `89.6270 studs` | **UNVERIFIED** (`~75+ studs` estimated) | **UNVERIFIED** (`~75+ studs` estimated) | **PASS** — Diagonal opposite South-West quadrant. |

## 5. Walk-Up Space & Honest Analysis of the Shop Bar Walkway Pinch Point

### 5.1 Player Walk-Up & Standing Apron (`24.0 W × 6.0 D studs`)
Directly in front of the three displays (`Local X in [-12.0, +12.0]`, `Local Z in [+2.25, +8.25]`), players have a **`24.0-stud` wide by `6.0-stud` deep (`144 sq. studs`)** flat viewing apron spanning `R_xz = 35.35 to 43.06 studs` (`Preview 05C`). Even at the inner edge of this viewing apron (`R = 35.35 studs`), **`21.35 studs`** of open plaza floor remain before the `R = 14.0` Queue Pad Ring.

### 5.2 Shop Bar North Wing Walkway Analysis & Optional `22.8-Stud` Trade-Off
- **Where the Pinch Occurs:** Because the Leaderboard (`(35, 150, -274)`) is rotated at `Yaw = -126.6071°`, its Left Wing (`Local -X`, Display A) extends South-East toward `(40.3497, 150, -284.9747)`, approaching the North Wing of `SM_Hub_ShopKiosk_01` (`World X in [39.0, 47.0]`, `World Z = -290.0000`).
- **Measured Gap at `24.00 Studs` Width:**
  - **Analytical Unchamfered OBB-to-AABB Z-Gap:** **`5.0253 studs`** (`-284.9747 - (-290.0000)`).
  - **Chamfered Blockout Mesh-to-Shop-Mesh 2D Clearance:** **`5.5231 studs`** (`5.3533 studs` Z-gap).
- **Walkability Assessment in the Hub:** In the Kinetic Hub (`MASTER_IMPLEMENTATION_PLAN.md` §3.1 & §5.4), players walk as **R15 avatars** (`~2.0 studs` shoulder width; spheres exist only in the Arena). A **`5.03 to 5.52 stud` gap** is **`2.5× to 2.75×` wider than an R15 avatar**, allowing two R15 players to pass each other comfortably between the Shop Bar and Display A (`Preview 06C`), while a `15.89-stud` outer perimeter walkway (`R = 47.31..63.20`) and a `27.35-stud` inner plaza expanse (`R = 14.00..41.35`) remain completely open on either side.
- **Documented Alternative If a Wider Pinch Gap Is Desired (`PROPOSED OPTION`):**
  - If you prefer a minimum **`~6.0-stud`** mesh clearance at the Shop Bar corner without moving either station, reducing the overall array width slightly from **`24.00 studs` to `22.80 studs`** (`3` modules of `6.80 studs` outer width / `6.00 studs` visible UI width + `4 × 0.60 stud` piers) increases the OBB Z-gap to **`5.5070 studs`** and the chamfered mesh-to-mesh 2D clearance to **`6.00+ studs`** while keeping every visible UI surface at **`6.00 studs` wide**.
