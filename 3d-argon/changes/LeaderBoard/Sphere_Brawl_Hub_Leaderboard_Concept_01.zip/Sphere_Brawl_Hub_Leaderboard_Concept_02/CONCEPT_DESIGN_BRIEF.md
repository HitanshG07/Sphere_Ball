# Revised Concept Design Brief — `SM_Hub_Leaderboard_01` (Wide Multi-Leaderboard Array — Concept 02)

- **Canonical Asset ID:** `SM_Hub_Leaderboard_01`
- **Deliverable Stage:** Step 6, Phase 1 Revision — Concept, Visual Layout, Spatial Checks & Owner Review (`CONCEPT ONLY — NOT FINAL PRODUCTION MESH`)
- **Superseded Concept Reference:** `Sphere_Brawl_Hub_Leaderboard_Concept_01.zip` (SHA-256: `5047fd853bc008457e3427fb4be7755cab328ec611b96b256eb22886875a96bb` — single `6.5 W × 16.0 H × 4.5 D` pylon, preserved untouched)
- **Authoritative World Anchor (`LOCKED`):** **`(35.0000, 150.0000, -274.0000)`** (`MASTER_IMPLEMENTATION_PLAN.md` §2.4 & `tasks/TASK-03-KINETIC-HUB-ENVIRONMENT.md`)
- **Revised Proposed Envelope (`PROPOSED`):** **`24.0000 W × 10.5000 H × 4.5000 D studs`** (`3` coordinated display modules of `7.2000 studs` outer width and `6.4000 studs` visible UI width each)

## 1. Why the Single Narrow Pylon (`Concept 01`) Was Replaced

The initial Phase 1 concept (`Concept 01`) followed the Art Bible's single-pylon table entry (`6.5 W × 16.0 H × 4.5 D studs`) with one `3.96-stud` wide vertical display. Owner review identified two core limitations of that narrow tower:
1. **Constrained Horizontal Readability & Single-Table Crowding:** A single `3.96-stud` wide screen forced rank badges, pilot names, KOs, and Wins into one narrow portrait column (`3.96 W × 9.44 H`), limiting horizontal breathing room and preventing players from scanning dedicated category leaderboards at a glance.
2. **Lack of Multi-Category Visual Destination:** In a spacious `140-stud` arena plaza where neighboring stations span `10.0 to 20.0 studs` in width, a single `6.5-stud` wide tower lacked horizontal presence along the North-East perimeter arc.

To resolve this substantively—without merely stretching the old screen or squeezing three tiny screens into a narrow tower—**`Concept 02`** replaces the single obelisk with a **broad, architectural `24.0 W × 10.5 H × 4.5 D stud` Three-Board Leaderboard Array** (`Preview 04C`). Every one of its three individual display modules (`7.20 studs` outer width) is wider than the entire previous `6.50-stud` pylon, and every visible UI surface (`6.40 studs` wide) is **`61.6%` wider** than the previous `3.96-stud` screen.

## 2. The Three Leaderboard Displays, Categories & Colour Themes

The station is organized into three side-by-side display modules housed within a unified dark-metallic structural gantry. Each module features its own dedicated category, column layout, and Kinetic Grid accent colour (`Preview 02` & `Preview 07`):

| Display Slot | Local `X` Module Span (`7.20 W` Each) | Local `X` Visible UI Span (`6.40 W` Each) | Category Header & Context | Primary Accent Material & Colour | Mockup Table Columns (`6` Placeholder Rows) | Purpose & Alpha Scope |
|---|---|---|---|---|---|---|
| **Display A (Left Wing)** | `[-11.40, -4.20]` | `[-11.00, -4.60]` (`6.40 W × 5.30 H` main + `6.40 W × 1.20 H` header) | **`SESSION KOs`** / `CURRENT SERVER • ALPHA SESSION ONLY` | **`EMI_Cyan`** `RGB(0, 195, 255)` `#00C3FF` | `RANK` \| `PILOT NAME` \| `KOs` | Dedicated server session Knockouts leaderboard. Cyan header banner, recessed vertical flank channels, and threshold guide strip. |
| **Display B (Center Hero)** | `[-3.60, +3.60]` | `[-3.20, +3.20]` (`6.40 W × 5.60 H` main + `6.40 W × 1.24 H` header) | **`SESSION WINS`** / `CURRENT SERVER • ALPHA SESSION ONLY` | **`EMI_Amber`** `RGB(255, 170, 0)` `#FFAA00` | `RANK` \| `PILOT NAME` \| `WINS` | Dedicated server session Match Wins leaderboard. Restrained amber header, recessed perimeter channels, and elevated center podium crest (`Y = 10.50`). |
| **Display C (Right Wing)** | `[+4.20, +11.40]` | `[+4.60, +11.00]` (`6.40 W × 5.30 H` main + `6.40 W × 1.20 H` header) | **`SESSION STANDINGS`** / `CURRENT SERVER • COMBINED OVERVIEW` | **`EMI_Magnetic`** `RGB(165, 55, 255)` `#A537FF` | `RANK` \| `PILOT NAME` \| `KOs` \| `WINS` | Combined session overview showing pilot names, session KOs, and session Wins together. Accented with Magnetic Purple header and recessed channels. |

### 2.1 Important Engineering Note on Display C Combined Standings Sort Order
In `MASTER_IMPLEMENTATION_PLAN.md` §4.2 and `DECISION_LOG.md` `D-022`, match-end tiebreakers are defined for a single match (`alive > elimination time > valid KOs > survival time`), but the canonical documents do **not** lock a specific multi-match session sorting formula when combining session Wins and session KOs on an overall standings board (e.g., `Wins primary, KOs secondary` vs. `KOs primary, Wins secondary`).
- **Compliance:** In accordance with Section 4 of the task prompt, **no unapproved scoring formula or weighting is invented in this art package**. Display C presents clean placeholder rows (`PLAYER 01`..`PLAYER 06`, `—`) and explicitly records the runtime ordering rule for `SESSION STANDINGS` as an **integration decision** for the gameplay/UI engineering phase (`TASK-08`).

## 3. Shared Physical Structure & Wider, Shorter Silhouette

### 3.1 Architectural Cohesiveness Across the `24.0 × 10.5 × 4.5` Monument
1. **Grounded Stepped Base Plinth (`Local X in [-12.00, +12.00]`, `Y in [0.00, 1.42]`, `Z in [-2.25, +2.25]`):** A continuous `24.00-stud` wide dark-alloy foundation with `0.55-stud` corner chamfers, an upper `MAT_AltNeutral` pedestal deck (`Y = 0.44..1.05`), eight `MAT_LightTrim` floor tie-down cleats, and **three dedicated walk-up threshold steps** (`5.90 studs` wide each at `X = -7.80, 0.00, +7.80`) inlaid with Cyan, Amber, and Purple floor guide strips.
2. **Four Vertical Support Piers & Collar Clamps (`Local X = [-12.0,-11.4]`, `[-4.2,-3.6]`, `[+3.6,+4.2]`, `[+11.4,+12.0]`):** Four `0.60-stud` wide vertical piers frame the three `7.20-stud` display modules, creating deliberate structural separation between Display A, Display B, and Display C. Each pier carries two standardized `MAT_LightTrim` collar clamps at **`Y = 3.20 and 7.10 studs`** and is tied together by continuous upper (`Y = 8.65..9.18`) and lower (`Y = 1.35..1.82`) `MAT_AltNeutral` structural cross-beams.
3. **Stepped Canopy Visor & Center Podium Crest (`Local Y = 9.15..10.50`):** Left and right wing canopies reach **`Y = 9.82 studs`**, while the center canopy over Display B steps up to **`Y = 10.50 studs`** (`+0.12 studs` proud in `+Z`) and carries a 3-pillar metallic podium relief emblem (`MAT_LightTrim`). This stepped roofline gives the wide station a noble, balanced monument silhouette in neutral clay (`Preview 04A` & `04B`).
4. **Finished Rear Structural Spine & Four A-Frame Stabilizers (`Local Z in [-2.25, -1.24]`):** Four diagonal rear stabilizer fins anchor the piers to the rear plinth (`Y = 0.44..6.80`), while the back of each `7.20-stud` module features a beveled `MAT_AltNeutral` rear spine, three cooling louvers, a lower service panel, and a theme-coloured rear indicator bar (`Preview 03C` & `Preview 08C`).

### 3.2 How the Wide 3-Board Array Differs from the Shop Bar, Mode Board & Customize Kiosk
As shown at 1:1 scale in **`previews/04_Concept_Neutral_Clay_Silhouette.png` (Panel D)**:
- **Not a Shop Counter (`SM_Hub_ShopKiosk_01`, `20.0 W × 7.6 H × 8.0 D`):** The Shop Bar is a low, waist-high horizontal counter (`Y = 2.92`) with an open viewing window and 4 countertop item pods. The Leaderboard Array has **zero counter surface, zero merchandise pods, and zero open pass-through window**; it is a solid, full-height (`10.50 H`) architectural wall of three vertical standings boards.
- **Not a Mode Selection Gantry (`SM_Hub_ModeBoard_01`, `14.4 W × 8.8 H × 3.8 D`):** The Mode Board is an asymmetric `14.0°` tilted command board split into **1 large left active bay + 3 small stacked right locked bays** with physical lockdown clamps. The Leaderboard Array is **`9.60 studs` wider (`24.0` vs. `14.4 studs`)**, symmetrically organized into **three equal-width (`7.20 W`) vertical display modules** (`0°` vertical tilt) with no lockdown clamps or stacked small sub-bays.
- **Not a Sphere Pedestal Kiosk (`SM_Hub_CustomizeKiosk_01`, `10.0 W × 9.5 H × 8.0 D`):** Contains zero spherical preview hulls or circular floor pedestals.

## 4. Shared Palette & 70 / 20 / 10 Visual Hierarchy Verification

Programmatic surface-area measurement across all `1,886` triangles of the Concept 02 blockout confirms strict adherence to the locked Kinetic Grid palette and the Art Bible's **70 / 20 / 10** hierarchy:

| Material Slot | Locked RGB | Hex Code | Concept 02 Area (`sq. studs`) | Area Share (`%`) | Role Across the Three-Board Station |
|---|---|---|---:|---:|---|
| **`MAT_DarkNeutral`** | `(32, 38, 54)` | `#202636` | `1,576.2673` | **`58.90%`** | Lower foundation plinth, 4 vertical support piers, 4 rear stabilizer fins, 3 module housings, canopy hoods, rear service panels, and 6 UI target planes |
| **`MAT_AltNeutral`** | `(42, 50, 70)` | `#2A3246` | `898.3819` | **`33.57%`** | Upper stepped pedestal, 3 walk-up threshold steps, upper/lower cross-beams, 3 module bezels, outer cheek plates, center crown step, and 3 rear spines |
| **`MAT_LightTrim`** | `(170, 190, 215)` | `#AABED7` | `163.7208` | **`6.12%`** | 8 floor tie-down cleats, 8 pier collar clamps, 3 module perimeter bezels, canopy brow bars, 3-tier center podium emblem, and rear louver trim |
| **`EMI_Cyan`** | `(0, 195, 255)` | `#00C3FF` | `12.4324` | **`0.46%`** | **Display A (`SESSION KOs`)** recessed flank channels, header/footer divider bars, crown beacon, threshold strip, and rear bay indicator |
| **`EMI_Amber`** | `(255, 170, 0)` | `#FFAA00` | `12.8944` | **`0.48%`** | **Display B (`SESSION WINS`)** recessed flank channels, header/footer divider bars, center crown beacon, threshold strip, and rear bay indicator |
| **`EMI_Magnetic`** | `(165, 55, 255)` | `#A537FF` | `12.4324` | **`0.46%`** | **Display C (`SESSION STANDINGS`)** recessed flank channels, header/footer divider bars, crown beacon, threshold strip, and rear bay indicator |
| **`MAT_PrimaryText`** | `(245, 248, 255)` | `#F5F8FF` | *(UI Mockup)* | *(UI Layer)* | High-contrast headings, column labels, and placeholder rows inside the replaceable `SurfaceGui` mockups |

## 5. Summary of Design Proposals Awaiting Owner Sign-Off

1. **Overall Station Envelope (`24.00 W × 10.50 H × 4.50 D studs` — `PROPOSED`):** Matches the prompt's starting proposal (`3 × 7.20 W` modules, `6.40 W` visible UI per panel). See `CONCEPT_DIMENSIONS_AND_PLACEMENT.md` §5.2 for a comparison with an optional `22.80 W` refinement if a wider walkway gap to the Shop Bar is desired.
2. **Six-Row Visible Table Layout (`PROPOSED`):** Displays 6 high-contrast rows per board (`~0.75 studs` row pitch across `6.40 W × 5.30–5.60 H` UI planes), matching the 4–6 player Alpha match size and expandable to a scrolling `SurfaceGui` list in `TASK-08`.
3. **Display C Combined Standings Ordering Rule (`DEFERRED TO INTEGRATION`):** Left uninvented in Phase 1 art so server/UI code (`TASK-07`/`TASK-08`) defines the authoritative sort key.
