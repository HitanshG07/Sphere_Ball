# Sphere Brawl: Rolling Rampage — Wide Multi-Leaderboard Array Concept Package (`SM_Hub_Leaderboard_01` — Concept 02 Revision)

- **Canonical Asset ID:** `SM_Hub_Leaderboard_01`
- **Descriptive Name:** Kinetic Hub Wide Three-Panel Session Leaderboard Array (`WIDE MULTI-LEADERBOARD ARRAY — STEP 6, PHASE 1 REVISION`)
- **Revision Status:** **Phase 1 Revision (`Concept 02`)** — Supersedes the single narrow `6.5 × 16.0 × 4.5 stud` pylon (`Sphere_Brawl_Hub_Leaderboard_Concept_01.zip`, SHA-256 `5047fd853bc008457e3427fb4be7755cab328ec611b96b256eb22886875a96bb`, which remains preserved and untouched).
- **Package Directory:** `Sphere_Brawl_Hub_Leaderboard_Concept_02/`
- **Outer Archive:** `Sphere_Brawl_Hub_Leaderboard_Concept_02.zip`
- **Current Stage:** **Step 6, Phase 1 Revision — Concept, Visual Layout, Recalculated Spatial Checks & Owner Review (`CONCEPT ONLY — NOT FINAL PRODUCTION MESH`)**
- **Next Phase Gate:** Phase 2 (Final production mesh `.obj`/`.mtl`/`.glb`, collision proxy, generator script, and Studio import guide) begins **only after explicit owner approval** of this revised three-board concept.

## 1. Executive Summary of the Revised Wide Three-Board Concept

In response to owner review of the initial narrow tower (`6.5 W × 16.0 H × 4.5 D studs` with a single `3.96-stud` UI surface), **`SM_Hub_Leaderboard_01` (`Concept 02`)** has been redesigned from the ground up into a **broad, horizontally balanced `24.00 W × 10.50 H × 4.50 D stud` three-display leaderboard monument** at the locked station coordinate **`(35, 150, -274)`**:

1. **Three Coordinated `7.20-Stud` Display Modules (Each Wider Than the Old `6.50-Stud` Pylon):**
   - **Display A (Left Module — `Local X in [-11.40, -4.20]`, `7.20 W × 9.82 H`):** **`SESSION KOs`** (`CURRENT SERVER • ALPHA SESSION ONLY`, columns `RANK | PILOT NAME | KOs`), accented by **`EMI_Cyan` (`#00C3FF`)**.
   - **Display B (Center Hero Module — `Local X in [-3.60, +3.60]`, `7.20 W × 10.50 H`):** **`SESSION WINS`** (`CURRENT SERVER • ALPHA SESSION ONLY`, columns `RANK | PILOT NAME | WINS`), accented by **`EMI_Amber` (`#FFAA00`)** and crowned by a slightly elevated (`10.50 H`, `+0.12 stud` forward step) hero canopy and 3-tier metallic podium emblem.
   - **Display C (Right Module — `Local X in [+4.20, +11.40]`, `7.20 W × 9.82 H`):** **`SESSION STANDINGS`** (`CURRENT SERVER • COMBINED OVERVIEW`, columns `RANK | PILOT NAME | KOs | WINS`), accented by **`EMI_Magnetic` (`#A537FF`)**.
2. **Substantially Wider Replaceable `SurfaceGui` Target Planes (`6.40 Studs` Wide Each vs. `3.96 Studs` Previously):**
   - Every panel provides a **`6.40-stud` wide** visible UI surface (`61.6%` wider per board than the old `3.96-stud` screen, and **`19.20 studs`** of combined horizontal UI width across all three boards).
   - Authored as **6 separate, flat, zero-text replaceable `SurfaceGui` target quads** (`3` Header planes + `3` Main Table planes) with outward normal `Local +Z = (0, 0, +1)` at `0°` vertical tilt (`Preview 02C`).
3. **Strict Alpha Scope Compliance (`MASTER_IMPLEMENTATION_PLAN.md` §2.4, §3.2 & `TASK-03`):**
   - Shows **session-only KOs and Wins** for the current server. Does not imply persistent cross-server rankings, career totals, or invented scoring formulas (the runtime sort order for Display C's combined view is explicitly recorded as a runtime integration decision rather than invented in art).

## 2. Locked World Location, Revised Proposed Envelope & Recalculated Bounds

| Parameter | Value | Status | Source / Verification |
|---|---|---|---|
| **World Station Center** | **`(35.0000, 150.0000, -274.0000)`** | **LOCKED** | `MASTER_IMPLEMENTATION_PLAN.md` §2.4 & `TASK-03` |
| **Hub Center & Top Deck** | **`(0.0000, 150.0000, -300.0000)`** (`World Y = 150.0`) | **LOCKED** | `TASK-03` & `SM_Hub_PlazaPlatform_01` |
| **Local Pivot Contract** | **Bottom-center floor pivot `(0.0000, 0.0000, 0.0000)`** | **PROPOSED** | Base underside (`Local Y = 0.0`) rests flush at `World Y = 150.0` |
| **Revised Overall Width (`Local X`)** | **`24.0000 studs`** (`Local X in [-12.0000, +12.0000]`) | **PROPOSED** | `3.69×` wider than Concept 01 (`6.50 studs`); extends tangentially |
| **Revised Overall Height (`Local Y`)** | **`10.5000 studs`** (`Local Y in [0.0000, +10.5000]`) | **PROPOSED** | Shorter, balanced architectural monument (`10.50` center / `9.82` wings vs. `16.0` tower) |
| **Revised Overall Depth (`Local Z`)** | **`4.5000 studs`** (`Local Z in [-2.2500, +2.2500]`) | **PROPOSED** | Preserves compact radial depth (`4.50 studs`) |
| **Outer Width per Display Module** | **`7.2000 studs` each** (`3` modules) | **PROPOSED** | Separated by `0.60-stud` structural piers (`[-11.4,-4.2]`, `[-3.6,+3.6]`, `[+4.2,+11.4]`) |
| **Visible UI Width per Panel** | **`6.4000 studs` each** (`19.20 studs` total UI width) | **PROPOSED** | Exceeds `6.0–6.5 stud` target (`+61.6%` wider than old `3.96-stud` UI) |
| **Radial Inward Yaw (`θ_yaw`)** | **`-126.60707939°`** (`-2.20971031 rad`, `atan2(-35, -26)`) | **CALCULATED / PROPOSED** | `CFrame.new(35, 150, -274) * CFrame.Angles(0, math.rad(-126.60707939), 0)` |
| **World Front Unit Vector** | **`(-0.80274385, 0.00000000, -0.59632400)`** | **CALCULATED** | Points `Local +Z` directly at Hub Center `(0, 150, -300)` |
| **Recalculated OBB World Bounds** | `X [26.0379, 43.9621]`, `Y [150.0, 160.5]`, `Z [-284.9747, -263.0253]` | **CALCULATED** | Analytical unchamfered `24.0 × 10.5 × 4.5` footprint |
| **Recalculated Vertex World Bounds** | `X [26.3659, 43.8701]`, `Y [150.0, 160.5]`, `Z [-284.6467, -263.1153]` | **MEASURED** | Measured across all `5,658` blockout vertices (`0.55-stud` base corner chamfers) |
| **Recalculated Radial Span (`R_xz`)** | **`[41.3505, 47.3948] studs` (OBB)** / **`[41.4789, 47.3119] studs` (Vertices)** | **CALCULATED / MEASURED** | Fits **100%** inside the `R = [37.00, 52.50] stud` Peripheral Station Band |
| **Concept 02 Blockout Triangles** | **`1,886 triangles`** (`5,658 vertices` across `25` components) | **MEASURED** | Strictly below the `< 2,000-triangle` Leaderboard budget |

## 3. Package Inventory & Revised Preview Index (`Sphere_Brawl_Hub_Leaderboard_Concept_02/`)

The `Sphere_Brawl_Hub_Leaderboard_Concept_02/` directory and `Sphere_Brawl_Hub_Leaderboard_Concept_02.zip` archive contain **14 total files** (`12` payload files described in `MANIFEST.json` + `MANIFEST.json` + `SHA256SUMS.txt`):

| # | Relative Path in Package | Type | Description |
|---:|---|---|---|
| 1 | `README.md` | Documentation | Package overview, asset ID, Concept 02 revision summary, preview index, proposed dimensions, and explicit owner approval gate |
| 2 | `CONCEPT_DESIGN_BRIEF.md` | Documentation | Rationale for replacing the narrow pylon, 3 display categories & colour themes (Cyan/Amber/Purple), shared structure, UI layout, and Shop/Mode Board distinction |
| 3 | `CONCEPT_DIMENSIONS_AND_PLACEMENT.md` | Documentation | Proposed `24.0 × 10.5 × 4.5` envelope, per-panel dimensions, yaw verification, recalculated world bounds, radial span, and Shop Bar walkway bottleneck analysis |
| 4 | `CONCEPT_VALIDATION_REPORT.md` | Documentation | Sources & packages inspected, changes from Concept 01, 3-theme & panel-width confirmations, session-only compliance, checksums, and `NOT RUN` Studio status |
| 5 | `previews/01_Concept_Player_Approach_ThreeQuarter.png` | Preview 01 (Required) | Player-height (`Y = 4.8–5.6 studs`) 3/4 and walk-up views showing the entire `24.0-stud` 3-panel station, base, and Cyan/Amber/Purple identities |
| 6 | `previews/02_Concept_Direct_Front_Elevation.png` | Preview 02 (Required) | Direct front orthographic & perspective elevations of all 3 boards side-by-side + Panel C proving 6 blank replaceable `SurfaceGui` target planes |
| 7 | `previews/03_Concept_Side_Orthographic.png` | Preview 03 (Required) | Left/right side orthographic profiles (`4.50-stud` depth, `10.50-stud` height), rear 3/4 structural view, and 1:1 engineering profile diagram |
| 8 | `previews/04_Concept_Neutral_Clay_Silhouette.png` | Preview 04 (Required) | Neutral-clay 3/4 & front views + 1:1 scale neutral-clay comparisons against Concept 01 (`6.5×16.0`) and Customize Kiosk, Shop Bar & Mode Board |
| 9 | `previews/05_Concept_TopDown_Footprint_Clearance.png` | Preview 05 (Required) | Top-down 3D orthographic footprint (`24.0 × 4.5 studs`) and recalculated Hub radial band fit & East sector clearance blueprint |
| 10 | `previews/06_Concept_Hub_Integration_Overview.png` | Preview 06 (Required) | Full Kinetic Hub integration views at `(35, 150, -274)` alongside real Plaza, Queue Portal, Shop Bar, and Mode Board meshes + Shop Bar walkway view |
| 11 | `previews/07_Concept_Three_Board_UI_Detail.png` | Preview 07 (Required) | Dedicated side-by-side close-up of Display A (`SESSION KOs`), Display B (`SESSION WINS`), and Display C (`SESSION STANDINGS`) UI layouts and specs |
| 12 | `previews/08_Concept_Technical_Wireframe_And_Rear.png` | Preview 08 (Bonus) | Isolated technical wireframe topology sheet (`1,886` triangles) and direct rear orthographic elevation (`-Z` structural face) |
| 13 | `MANIFEST.json` | Package Manifest | Machine-readable inventory of all 12 payload files with exact byte sizes, SHA-256 hashes, and recalculated spatial/material metadata |
| 14 | `SHA256SUMS.txt` | Checksums | Standard `sha256sum -c` verification file covering all 12 payload files and `MANIFEST.json` (`13` lines total) |

## 4. Explicit Owner Approval Gate (Phase 1 Stop Condition)

This deliverable is **strictly a Phase 1 concept revision (`Concept 02`)**.
- **No final production geometry** (`SM_Hub_Leaderboard_01.obj`, `.mtl`, `.glb`, or collision proxies) has been exported.
- **No live UI, statistics collection, remotes, or Luau scripts** have been created or modified.
- **Action Required:** Please review the revised 8 preview sheets and recalculated clearance report (including the `24.0-stud` primary proposal vs. the optional `22.8-stud` wider-walkway refinement). Phase 2 production will begin **only after your explicit approval**.
